Shark's Level Pack 3 for Sapphire Yours
**********************************************************************
Contains 242 levels!
Simple-MAD, unrated, and even some 2-player challenges!
Be sure to play the Center of the Earth level...good luck!

I've been making levels since 1999...now it's 2005...that's a long time! This new pack has over 100 new levels, jam-packed with original ideas, yamyams, unexpected use of explosions, grape jelly, and hilarious level descriptions!
**********************************************************************
Instructions:
 - Remove Shark's Level Pack 1 and 2 if you have them installed! This pack has all the original levels, updated, plus tons more!
 - Place all levels in the LEVELS directory (I recommend making a "Shark" folder first)
 - Place the Illusion zip file in the MOVIE directory
 - Place MIDI files in the SONGS directory
 - Destroy this readme, before the government sees it!
**********************************************************************
Notes:
 - Every level has a demo, so if you can't figure something else, you can see how it's done.
 - There's a suspended game you can use to solve the "Sheer Luck" level -- just press the Down key after you start it.
 - Be sure to put in the Illusion.zip movie set before playing any Illusi0ns level, or...just make sure it's in ;-)
 - Let me know if you find an alternative way to solve a level using less resources/gems/movement/etc. so I can edit it for the future, and I'll give you credit under "First Finished".
 - Have fun!
**********************************************************************
Contact Info:
Email - sharkxvd@hotmail.com
Forums - http://supershark.proboards1.com
Website - http://shark.nickj.elixant.com
AIM Name - Shark5157