This directory is the location where Sapphire Yours
stores all user defined levels.
