Shark's Level Pack

Unfortunately I lost half the 196 levels I had made on a hard drive error, so here are the 97 I still have. Place the "Illusions.zip" file in the MOVIE folder and the rest in a /LEVELS/Shark folder.

I'll try to restore some of the losses, including an improved demo to the Everything Deluxe level (this one's too easy =D) and a Suspended Animation level (really cool trick I found). Look in the next version if any.

Oh yeah, I can try to make customized levels, like if you want to make weird things but don't know how, like a Lorry Machine (use Yam Yams for that one) or a ...bomb machine. Drop me a line, just don't hit me on the head with it (foot is all right).

--- TRICK OF THE YEAR: CLONE GUYS ---
See Moderate level Crash Dummies for example!
You can create copies of you that don't move or collect stuff and don't need to exit the level. They act like you; they attract robots (and can be killed by them) and also can be killed by Lorries, Yammers, and Swamp. They will also die if you drop stuff on their heads. The way to make these guys is to create Yam Yams that automatically explode (put swamp next to 'em) and have a miner guy as one of their contents. Try it! You can get rid of as many as you want; they're just minor miners.
---      TRICK OF THE YEAR!       ---

DID YOU KNOW?
 - The minimum moves required to solve a level is two.
 - The largest value of gems you could need to collect is 15624. Create a 126 x 126 level with a miner, an exit, and rubies everywhere else.
 - It really is possible to solve No Fate and Blast Me Too! without the VCR, but it would take a lot of luck.
 - Bombs dissolve in acid.
 - Objects bounce off cushions faster than they bounce off any other round object.
 - You can't make a laser infinitely reflect in a circle with a bomb and ruby.

Thanks for downloading and look for more levels in: 200 months. (That's less than 201 months!)

- Shark XVD
sharkxvd@hotmail.com			Email
http://meowmix.web1000.com		Website
http://supershark.proboards.com		Forum
Shark5157				AOL Instant Messenger

If you appreciate my levels, please send a small LARGE LATENESS FEE of five HUNDRED DOLLARS in a few NOW. Send everything to this address:

Antarctica
