#include "types.h"

class DataReader;

class ZipFile;
class ZipContent;
class ZipDecoder;

// -------------------- object factory ----------------------------

DataReader* openDataReader(charstring& fname);
void closeZipFiles();

// --------------------- exported access objects --------------------

class DataReader
{
public:
	DataReader();
	virtual ~DataReader();

	virtual int readBytes(unsigned char* buffer, int bufferlength) = 0;

	void skipBytes(int length);
	unsigned long readInt32();
	unsigned long readInt16();
};

class FileReader : public DataReader
{
private:
	FILE *file;

public:
	FileReader(FILE* f);
	virtual ~FileReader();

	virtual int readBytes(unsigned char* buffer, int bufferlength);
};

class ZipReader : public DataReader
{
private:
	ZipFile* zipfile;

public:
	ZipReader(ZipFile* zip);
	virtual ~ZipReader();

	virtual int readBytes(unsigned char* buffer, int bufferlength);
};




// ----------------- internal zipfile operations ------------------

class HuffmanTree {
public:
	HuffmanTree();
	~HuffmanTree();

	void clear();

	void addBitLength(int codebitsize);
	int  numberOfBitLengths() { return numvalues; }
	void constructTree();

	void startRetrieval();
	int	 continueRetrieval(int bit);

private:
	int buildTree(int level);
	void findNextValue();

	enum {MAXIMUMVALUES=300};
	int bitlength[MAXIMUMVALUES];
	int numvalues;
	int highestbitlength;

	enum {MAXIMUMSTATES=MAXIMUMVALUES};
	int follower[MAXIMUMSTATES][2];
	int numstates;

	int currentbitlength;
	int currentvalue;

	int currentstate;
};

class ZipFile {
public:
	ZipFile();
	virtual ~ZipFile();

	bool open(charstring& _filename);

	bool startRead(charstring& _contentname);
	void stopRead();
	int readBytes(unsigned char* buffer, int bufferlength);

	std::list<ZipContent*> contents;
	ZipDecoder *current;

	std::string filename;
	FILE* file;
	int currentoffset;
};

class ZipContent {
public:
	ZipContent(ZipFile* _owner);
	virtual ~ZipContent();

	bool readHeader();

	ZipFile* owner;
	std::string contentname;

	int compressionmethod;
	int compressedsize;
	int offset;
};

class ZipDecoder {
public:
	ZipDecoder(ZipContent* _content);
	virtual ~ZipDecoder();
	virtual int readBytes(unsigned char *buffer, int bufferlength) = 0;

	void readRawBytes(unsigned char* buffer, int bufferlength);
	int  readRawBit();
	int  readRawBits(int numberofbits); 
	void skipRawBitsToAlign();

	ZipContent* content;

	unsigned char bitbuffer;
	int bitbufferlength;
};

class ZipDecoderStored : public ZipDecoder {
public:
	ZipDecoderStored(ZipContent* _content);
	virtual ~ZipDecoderStored();

	virtual int readBytes(unsigned char *buffer, int bufferlength);

	int bytesleft;
};

class ZipDecoderDeflated: public ZipDecoder {
public:
	ZipDecoderDeflated(ZipContent* _content);
	virtual ~ZipDecoderDeflated();

	virtual int readBytes(unsigned char *buffer, int bufferlength);

private:
	enum {DICTIONARYSIZE=32768};
	unsigned char dictionary[DICTIONARYSIZE];
	int dictionarypointer;

	bool endoffile;
	
	void readBlockStart();
	void readHuffmanTrees();
	void readHuffmanTree(HuffmanTree* tree,int codenum);
	int  readHuffmanValue (HuffmanTree* tree);
	bool readOneByte(unsigned char* buffer);

	bool lastblock;
	bool uncompressed;
	unsigned int uncompressedbytesleft;
	int lookuplength;
	int lookupposition;

	HuffmanTree bitlengthcodes;
	HuffmanTree literalcodes;
	HuffmanTree distancecodes;
};
