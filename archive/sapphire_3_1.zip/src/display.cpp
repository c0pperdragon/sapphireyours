#include "framework.h"
#include "display.h"

static vector<Image*> imagecache;

enum {lastpriority=10 };
enum {basetilesize=60 };

static struct {char* name; int prio; bool movie; } imagename [img_end] = {
{ "bag",       3,    false },
{ "bagexpl",   8,    false },
{ "bomb",      3,    false },
{ "bomb10",    5,    false },
{ "box",       5,    false },
{ "bugdwn",    7,    false },
{ "buglft",    7,    false },
{ "bugrgt",    7,    false },
{ "bugtdr",    8,    false },
{ "bugtld",    8,    false },
{ "bugtru",    8,    false },
{ "bugtul",    8,    false },
{ "bugup",     7,    false },
{ "convert",   6,    false },
{ "cushion",   5,    false },
{ "dispen1",   8,    false },
{ "dispen2",   8,    false },
{ "doorblue",  6,    false },
{ "doorgree", 6,    false },
{ "dooropen", 9,    false },
{ "doorred",  6,    false },
{ "doorylow", 6,    false },
{ "drop",     5,    false },
{ "dropdwn",  7,    false },
{ "drophit",  7,    false },
{ "droplft",  7,    false },
{ "droprgt",  7,    false },
{ "dropup",   7,    false },
{ "earth",    0,    false },
{ "earthdwn", 9,    false },
{ "earthlft", 9,    false },
{ "earthrgt", 9,    false },
{ "earthup",  9,    false },
{ "sand",     9,    false },
{ "elevator", 8,    false },
{ "pushlft",  8,    false },
{ "pushrgt",  8,    false },
{ "emerald",  1,    false },
{ "emeraway", 9,    false },
{ "emglitt",  6,    false },
{ "explode",  2,    false },
{ "glaswall", 5,    false },
{ "invisi",   9,    false },
{ "keyblue",  6,    false },
{ "keyellow", 6,    false },
{ "keygreen", 6,    false },
{ "keyred",   6,    false },
{ "laserbl",  3,    false },
{ "laserbr",  3,    false },
{ "laserh",   2,    false },
{ "lasertl",  3,    false },
{ "lasertr",  3,    false },
{ "laserv",   2,    false },
{ "lorrydwn", 5,    false },
{ "lorrylft", 5,    false },
{ "lorryrgt", 5,    false },
{ "lorrytdl", 6,    false },
{ "lorrytlu", 6,    false },
{ "lorrytrd", 6,    false },
{ "lorrytur", 6,    false },
{ "lorryup",  5,    false },
{ "rndwall",  4,    false },
{ "ruby",     3,    false },
{ "rubyaway", 9,    false },
{ "saphaway", 9,    false },
{ "saphbrk",  9,    false },
{ "sapphire", 1,    false },
{ "stone",    1,    false },
{ "stonewll", 2,    false },
{ "swamp",    5,    false },
{ "timebomb", 5,    false },
{ "tickbomb", 9,    false },
{ "wall",     1,    false },
{ "wallemer", 7,    false },
{ "yamyam",   7,    false },
{ "yamyamdn", 7,    false },
{ "yamyamrt", 7,    false },
{ "yamyamlt", 7,    false },
{ "yamyamup", 7,    false },
{ "robot",    7,    false },
{ "wheel",	  9,    false },
{ "acid",     5,    false },
{ "acidalne", 6,    false },
{ "acidleft", 6,    false },
{ "acidrgt",  6,    false },
{ "1digdwn",  9,    false },
{ "1digrgt",  9,    false },
{ "1diglft",  9,    false },
{"1digup",    9,    false },
{"1man",      9,    false },
{"1pushrgt",  9,    false },
{"1pushlft",  9,    false },
{"1walkdwn",  9,    false },
{"1walkrgt",  9,    false },
{"1walklft",  9,    false },
{"1walkup",   9,    false },
{"2digdwn",  10,    false },
{"2digrgt",  10,    false },
{"2diglft",  10,    false },
{"2digup",   10,    false },
{"2man",     10,    false },
{"2pushrgt", 10,    false },
{"2pushlft", 10,    false },
{"2walkdwn", 10,    false },
{"2walkrgt", 10,    false },
{"2walklft", 10,    false },
{"2walkup",  10,    false },

{"movie0",   5,     true },
{"movie1",   5,     true },
{"movie2",   5,     true },
{"movie3",   5,     true },
{"movie4",   5,     true },
{"movie5",   5,     true },
{"movie6",   5,     true },
{"movie7",   5,     true },
{"movie8",   5,     true },
{"movie9",   5,     true },
{"movie10",  5,     true },
{"movie11",  5,     true },
{"movie12",  5,     true },
{"movie13",  5,     true },
{"movie14",  5,     true },
{"movie15",  5,     true },
{"movie16",  5,     true },
{"movie17",  5,     true },
{"movie18",  5,     true },
{"movie19",  5,     true },

};




void releaseImageCache()
{
	for (int i=0; i<imagecache.size(); i++) {
		delete imagecache[i];
	}
	imagecache.resize(0);
}


inline Image* Artwork::sequenceRest (Image* img, int &x1) 
{
	x1=0;
	return img;
}

inline Image* Artwork::sequenceForward (Image* img, int step, int totalsteps, int &x1) 
{
	if (!img) return NULL;
	if (step<0 || step>=totalsteps) { x1=0; return img; }

	int pics = img->width / tilesize;
	int pic = pics - 1 - (step * pics) / totalsteps;

	x1 = pic*tilesize;
	return img;
}

inline Image* Artwork::sequenceBackward (Image* img, int step, int totalsteps, int &x1) 
{
	if (!img) return NULL;
	if (step<=0 || step>=totalsteps) { x1=0; return img; }

	int pics = img->width / tilesize;
	int pic = (step * pics) / totalsteps;

	x1 = pic*tilesize;
	return img;
}

inline Image* Artwork::nthMoviePicture (Image* img, int step, int totalsteps, int &x1) 
{
	if (!img) {
		x1=0;
		return image[img_invisi];
	}
	return sequenceForward (img,step,totalsteps,x1);
}

inline Image* Artwork::nthMovieSequenceOfm (Image* img, int n, int m, int step, int totalsteps, int& x1)
{
	if (!img) {
		x1=0;
		return image[img_invisi];
	}
	return sequenceForward (img, n*totalsteps+step, totalsteps*m, x1);
}

inline Image* Artwork::nthSequenceOf5 (Image* img, int n, int step, int totalsteps, int& x1)
{
	return sequenceForward (img, n*totalsteps+step, totalsteps*5, x1);
}

inline Image* Artwork::nthOf5 (Image* img, int n, int& x1)
{
	return sequenceForward (img, n, 5, x1);
}


inline Image* Artwork::nthPicture (Image* img, int n, int& x1)
{
	if (!img) return NULL;

	int pics = img->width / tilesize;
	if (n>=pics) {
		n=pics-1;
		if (n<0) return NULL;
	}
	x1 = n*tilesize;
	return img;
}

inline Image* Artwork::lastPicture (Image* img, int& x1)
{
	if (!img) return NULL;
	int pics = img->width / tilesize;
	if (pics<=0) return NULL;
	x1 = (pics-1)*tilesize;
	return img;
}

Image* Artwork::getImageForTile (tiletype tile, int &x1)
{
	x1=0;
	switch (tile) {

	case tile_earth:		return nthPicture(image[img_earth],0,x1);
	case tile_earthu:		return nthPicture(image[img_earth],1,x1);
	case tile_earthd:		return nthPicture(image[img_earth],2,x1);
	case tile_earthl:		return nthPicture(image[img_earth],3,x1);
	case tile_earthr:		return nthPicture(image[img_earth],4,x1);
	case tile_earthud:		return nthPicture(image[img_earth],5,x1);
	case tile_earthul:		return nthPicture(image[img_earth],6,x1);
	case tile_earthur:		return nthPicture(image[img_earth],7,x1);
	case tile_earthdl:		return nthPicture(image[img_earth],8,x1);
	case tile_earthdr:		return nthPicture(image[img_earth],9,x1);
	case tile_earthlr:		return nthPicture(image[img_earth],10,x1);
	case tile_earthudl:		return nthPicture(image[img_earth],11,x1);
	case tile_earthudr:		return nthPicture(image[img_earth],12,x1);
	case tile_earthulr:		return nthPicture(image[img_earth],13,x1);
	case tile_earthdlr:		return nthPicture(image[img_earth],14,x1);
	case tile_earthudlr:	return nthPicture(image[img_earth],15,x1);

	case tile_air:			return NULL;
	case tile_wall:			return image[img_wall];
	case tile_stonewall:	return image[img_stonewll];
	case tile_glasswall:	return image[img_glaswall];
	case tile_invisiblewall:return image[img_invisi];
	case tile_wallemerald:	return image[img_wallemer];
	case tile_sand:			return image[img_sand];
	case tile_sandfull:		return image[img_stone];
	case tile_stone:		return image[img_stone];
	case tile_bag:			return image[img_bag];
	case tile_bomb:			return image[img_bomb];
	case tile_roundwall:	return image[img_rndwall];
    case tile_door:			return lastPicture(image[img_dooropen],x1);
	case tile_door_opened:  return image[img_dooropen];
    case tile_doorblue:     return image[img_doorblue];
	case tile_doorred:      return image[img_doorred];
	case tile_doorgreen:    return image[img_doorgree];
	case tile_dooryellow:	return image[img_doorylow];
    case tile_emerald:      return image[img_emerald];
	case tile_sapphire:     return image[img_sapphire];
	case tile_ruby:         return image[img_ruby];
	case tile_timebomb:     return image[img_timebomb];
	case tile_timebomb10:	return image[img_bomb10];
	case tile_tickbomb:     return image[img_tickbomb];

	case tile_keyblue1:     return nthOf5 (image[img_keyblue], 0, x1);
	case tile_keyblue2:     return nthOf5 (image[img_keyblue], 1, x1);
	case tile_keyblue3:     return nthOf5 (image[img_keyblue], 2, x1);
	case tile_keyblue4:     return nthOf5 (image[img_keyblue], 3, x1);
	case tile_keyblue5:     return nthOf5 (image[img_keyblue], 4, x1);
	case tile_keyred1:     return nthOf5 (image[img_keyred], 0, x1);
	case tile_keyred2:     return nthOf5 (image[img_keyred], 1, x1);
	case tile_keyred3:     return nthOf5 (image[img_keyred], 2, x1);
	case tile_keyred4:     return nthOf5 (image[img_keyred], 3, x1);
	case tile_keyred5:     return nthOf5 (image[img_keyred], 4, x1);
	case tile_keygreen1:     return nthOf5 (image[img_keygreen], 0, x1);
	case tile_keygreen2:     return nthOf5 (image[img_keygreen], 1, x1);
	case tile_keygreen3:     return nthOf5 (image[img_keygreen], 2, x1);
	case tile_keygreen4:     return nthOf5 (image[img_keygreen], 3, x1);
	case tile_keygreen5:     return nthOf5 (image[img_keygreen], 4, x1);
	case tile_keyyellow1:     return nthOf5 (image[img_keyellow], 0, x1);
	case tile_keyyellow2:     return nthOf5 (image[img_keyellow], 1, x1);
	case tile_keyyellow3:     return nthOf5 (image[img_keyellow], 2, x1);
	case tile_keyyellow4:     return nthOf5 (image[img_keyellow], 3, x1);
	case tile_keyyellow5:     return nthOf5 (image[img_keyellow], 4, x1);

    case tile_box:			return image[img_box];
	case tile_cushion:		return image[img_cushion];
	case tile_elevator:		return image[img_elevator];
	case tile_pusherleft:	return image[img_pushlft];
	case tile_pusherright:	return image[img_pushrgt];
	case tile_convert:		return image[img_convert];
	case tile_dispenser1:	return image[img_dispen1];
	case tile_dispenser2:	return image[img_dispen2];

	case tile_acidright1:
	case tile_acidleft1:
	case tile_acidalone1:
	case tile_acid1:		return nthOf5(image[img_acid], 0, x1);
	case tile_acidright2:
	case tile_acidleft2:
	case tile_acidalone2:
	case tile_acid2:		return nthOf5(image[img_acid], 1, x1);
	case tile_acidright3:
	case tile_acidleft3:
	case tile_acidalone3:
	case tile_acid3:		return nthOf5(image[img_acid], 2, x1);
	case tile_acidright4:
	case tile_acidleft4:
	case tile_acidalone4:
	case tile_acid4:		return nthOf5(image[img_acid], 3, x1);
	case tile_acidright5:
	case tile_acidleft5:
	case tile_acidalone5:
	case tile_acid5:		return nthOf5(image[img_acid], 4, x1);

    case tile_swamp:		return image[img_swamp];
	case tile_drop:			return image[img_drop];

	case tile_explode1:		return nthOf5 (image[img_explode], 0, x1);
	case tile_explode2:		return nthOf5 (image[img_explode], 1, x1);
	case tile_explode3:		return nthOf5 (image[img_explode], 2, x1);
	case tile_explode4:		return nthOf5 (image[img_explode], 3, x1);
	case tile_explode5:		return nthOf5 (image[img_explode], 4, x1);
                  
    case tile_lorryleft:	return image[img_lorrylft];
    case tile_lorryright:	return image[img_lorryrgt];
    case tile_lorryup:		return image[img_lorryup];
    case tile_lorrydown:	return image[img_lorrydwn];
	case tile_bugleft:		return image[img_buglft];
    case tile_bugright:		return image[img_bugrgt];
    case tile_bugup:		return image[img_bugup];
    case tile_bugdown:		return image[img_bugdwn];
    case tile_yamyamleft:   return image[img_yamyamlt];
	case tile_yamyamright:	return image[img_yamyamrt];
	case tile_yamyamup:		return image[img_yamyamup];
	case tile_yamyamdown:	return image[img_yamyamdn];
	case tile_yamyam:		return image[img_yamyam];
	case tile_robot1:		return sequenceForward(image[img_robot],0,10,x1);
	case tile_robot2:		return sequenceBackward(image[img_robot],0,10,x1);
	case tile_wheel:		return image[img_wheel];

	case tile_1rest:		return image[img_1man];
	case tile_1walkup:		return image[img_1walkup];
	case tile_1walkdown:	return image[img_1walkdwn];
	case tile_1walkleft:	return image[img_1walklft];
	case tile_1walkright:	return image[img_1walkrgt];
	case tile_1digup:		return image[img_1digup];
	case tile_1digdown:		return image[img_1digdwn];
	case tile_1digleft:		return image[img_1diglft];
	case tile_1digright:	return image[img_1digrgt];
	case tile_1pushup:		return image[img_1walkup];
	case tile_1pushdown:	return image[img_1walkdwn];
	case tile_1pushleft:	return image[img_1pushlft];
	case tile_1pushright:	return image[img_1pushrgt];

	case tile_2rest:		return image[img_2man];
	case tile_2walkup:		return image[img_2walkup];
	case tile_2walkdown:	return image[img_2walkdwn];
	case tile_2walkleft:	return image[img_2walklft];
	case tile_2walkright:	return image[img_2walkrgt];
	case tile_2digup:		return image[img_2digup];
	case tile_2digdown:		return image[img_2digdwn];
	case tile_2digleft:		return image[img_2diglft];
	case tile_2digright:	return image[img_2digrgt];
	case tile_2pushup:		return image[img_2walkup];
	case tile_2pushdown:	return image[img_2walkdwn];
	case tile_2pushleft:	return image[img_2pushlft];
	case tile_2pushright:	return image[img_2pushrgt];

	case tile_movie0_0:     return nthMoviePicture(image[img_movie0],0,1,x1);
	case tile_movie1_0:     return nthMoviePicture(image[img_movie1],0,1,x1);
	case tile_movie2_0:     return nthMoviePicture(image[img_movie2],0,1,x1);
	case tile_movie3_0:     return nthMoviePicture(image[img_movie3],0,1,x1);
	case tile_movie4_0:     return nthMoviePicture(image[img_movie4],0,1,x1);

	case tile_movie5_0:     return nthMoviePicture(image[img_movie5],0,2,x1);
	case tile_movie5_1:     return nthMoviePicture(image[img_movie5],1,2,x1);
	case tile_movie6_0:     return nthMoviePicture(image[img_movie6],0,2,x1);
	case tile_movie6_1:     return nthMoviePicture(image[img_movie6],1,2,x1);
	case tile_movie7_0:     return nthMoviePicture(image[img_movie7],0,2,x1);
	case tile_movie7_1:     return nthMoviePicture(image[img_movie7],1,2,x1);
	case tile_movie8_0:     return nthMoviePicture(image[img_movie8],0,2,x1);
	case tile_movie8_1:     return nthMoviePicture(image[img_movie8],1,2,x1);
	case tile_movie9_0:     return nthMoviePicture(image[img_movie9],0,2,x1);
	case tile_movie9_1:     return nthMoviePicture(image[img_movie9],1,2,x1);

	case tile_movie10_0:    return nthMoviePicture(image[img_movie10],0,4,x1);
	case tile_movie10_1:    return nthMoviePicture(image[img_movie10],1,4,x1);
	case tile_movie10_2:    return nthMoviePicture(image[img_movie10],2,4,x1);
	case tile_movie10_3:    return nthMoviePicture(image[img_movie10],3,4,x1);
	case tile_movie11_0:    return nthMoviePicture(image[img_movie11],0,4,x1);
	case tile_movie11_1:    return nthMoviePicture(image[img_movie11],1,4,x1);
	case tile_movie11_2:    return nthMoviePicture(image[img_movie11],2,4,x1);
	case tile_movie11_3:    return nthMoviePicture(image[img_movie11],3,4,x1);
	case tile_movie12_0:    return nthMoviePicture(image[img_movie12],0,4,x1);
	case tile_movie12_1:    return nthMoviePicture(image[img_movie12],1,4,x1);
	case tile_movie12_2:    return nthMoviePicture(image[img_movie12],2,4,x1);
	case tile_movie12_3:    return nthMoviePicture(image[img_movie12],3,4,x1);
	case tile_movie13_0:    return nthMoviePicture(image[img_movie13],0,4,x1);
	case tile_movie13_1:    return nthMoviePicture(image[img_movie13],1,4,x1);
	case tile_movie13_2:    return nthMoviePicture(image[img_movie13],2,4,x1);
	case tile_movie13_3:    return nthMoviePicture(image[img_movie13],3,4,x1);
	case tile_movie14_0:    return nthMoviePicture(image[img_movie14],0,4,x1);
	case tile_movie14_1:    return nthMoviePicture(image[img_movie14],1,4,x1);
	case tile_movie14_2:    return nthMoviePicture(image[img_movie14],2,4,x1);
	case tile_movie14_3:    return nthMoviePicture(image[img_movie14],3,4,x1);

	case tile_movie15_0:    return nthMoviePicture(image[img_movie15],0,8,x1);
	case tile_movie15_1:    return nthMoviePicture(image[img_movie15],1,8,x1);
	case tile_movie15_2:    return nthMoviePicture(image[img_movie15],2,8,x1);
	case tile_movie15_3:    return nthMoviePicture(image[img_movie15],3,8,x1);
	case tile_movie15_4:    return nthMoviePicture(image[img_movie15],4,8,x1);
	case tile_movie15_5:    return nthMoviePicture(image[img_movie15],5,8,x1);
	case tile_movie15_6:    return nthMoviePicture(image[img_movie15],6,8,x1);
	case tile_movie15_7:    return nthMoviePicture(image[img_movie15],7,8,x1);
	case tile_movie16_0:    return nthMoviePicture(image[img_movie16],0,8,x1);
	case tile_movie16_1:    return nthMoviePicture(image[img_movie16],1,8,x1);
	case tile_movie16_2:    return nthMoviePicture(image[img_movie16],2,8,x1);
	case tile_movie16_3:    return nthMoviePicture(image[img_movie16],3,8,x1);
	case tile_movie16_4:    return nthMoviePicture(image[img_movie16],4,8,x1);
	case tile_movie16_5:    return nthMoviePicture(image[img_movie16],5,8,x1);
	case tile_movie16_6:    return nthMoviePicture(image[img_movie16],6,8,x1);
	case tile_movie16_7:    return nthMoviePicture(image[img_movie16],7,8,x1);
	case tile_movie17_0:    return nthMoviePicture(image[img_movie17],0,8,x1);
	case tile_movie17_1:    return nthMoviePicture(image[img_movie17],1,8,x1);
	case tile_movie17_2:    return nthMoviePicture(image[img_movie17],2,8,x1);
	case tile_movie17_3:    return nthMoviePicture(image[img_movie17],3,8,x1);
	case tile_movie17_4:    return nthMoviePicture(image[img_movie17],4,8,x1);
	case tile_movie17_5:    return nthMoviePicture(image[img_movie17],5,8,x1);
	case tile_movie17_6:    return nthMoviePicture(image[img_movie17],6,8,x1);
	case tile_movie17_7:    return nthMoviePicture(image[img_movie17],7,8,x1);
	case tile_movie18_0:    return nthMoviePicture(image[img_movie18],0,8,x1);
	case tile_movie18_1:    return nthMoviePicture(image[img_movie18],1,8,x1);
	case tile_movie18_2:    return nthMoviePicture(image[img_movie18],2,8,x1);
	case tile_movie18_3:    return nthMoviePicture(image[img_movie18],3,8,x1);
	case tile_movie18_4:    return nthMoviePicture(image[img_movie18],4,8,x1);
	case tile_movie18_5:    return nthMoviePicture(image[img_movie18],5,8,x1);
	case tile_movie18_6:    return nthMoviePicture(image[img_movie18],6,8,x1);
	case tile_movie18_7:    return nthMoviePicture(image[img_movie18],7,8,x1);
	case tile_movie19_0:    return nthMoviePicture(image[img_movie19],0,8,x1);
	case tile_movie19_1:    return nthMoviePicture(image[img_movie19],1,8,x1);
	case tile_movie19_2:    return nthMoviePicture(image[img_movie19],2,8,x1);
	case tile_movie19_3:    return nthMoviePicture(image[img_movie19],3,8,x1);
	case tile_movie19_4:    return nthMoviePicture(image[img_movie19],4,8,x1);
	case tile_movie19_5:    return nthMoviePicture(image[img_movie19],5,8,x1);
	case tile_movie19_6:    return nthMoviePicture(image[img_movie19],6,8,x1);
	case tile_movie19_7:    return nthMoviePicture(image[img_movie19],7,8,x1);

	default:  return NULL; 
	}	
}

Image* Artwork::getImage2ForTile (tiletype tile, int &x1)
{
	switch (tile) {
	case tile_sandfull:		x1=0; return image[img_sand];

	case tile_acidright1:
	case tile_acidright2:
	case tile_acidright3:
	case tile_acidright4:
	case tile_acidright5:	x1=0; return image[img_acidrgt];
	case tile_acidleft1:
	case tile_acidleft2:
	case tile_acidleft3:
	case tile_acidleft4:
	case tile_acidleft5:	x1=0; return image[img_acidleft];
	case tile_acidalone1:
	case tile_acidalone2:
	case tile_acidalone3:
	case tile_acidalone4:
	case tile_acidalone5:	x1=0; return image[img_acidalne];
	}
	return NULL;
}


Image* Artwork::getImageForSequence (sequencetype seq, int step, int totalsteps, int &x1)
{
	switch (seq) {
	case seq_earthup:	return sequenceForward (image[img_earthup], step, totalsteps, x1);
	case seq_earthdown:	return sequenceForward (image[img_earthdwn], step, totalsteps, x1);
	case seq_earthleft:	return sequenceForward (image[img_earthlft], step, totalsteps, x1);
	case seq_earthright:return sequenceForward (image[img_earthrgt], step, totalsteps, x1);

	case seq_stonerest:  return sequenceRest (image[img_stone], x1);
	case seq_stonedown:  return sequenceRest (image[img_stone], x1);
	case seq_stoneleft:  return sequenceBackward  (image[img_stone], step, totalsteps, x1);
	case seq_stoneright: return sequenceForward (image[img_stone], step, totalsteps, x1);

	case seq_sand:		return sequenceRest (image[img_sand], x1);

	case seq_emeraldrest:  return sequenceRest (image[img_emerald], x1);
	case seq_emeralddown:  return sequenceRest (image[img_emerald], x1);
	case seq_emeraldleft:  return sequenceForward  (image[img_emerald], step, totalsteps, x1);
	case seq_emeraldright: return sequenceBackward (image[img_emerald], step, totalsteps, x1);
	case seq_emeraldglitter: return sequenceForward (image[img_emglitt], step, totalsteps, x1);
	case seq_emeraldaway: return sequenceForward (image[img_emeraway], step, totalsteps, x1);

	case seq_sapphirerest:  return sequenceRest (image[img_sapphire], x1);
	case seq_sapphiredown:  return sequenceRest (image[img_sapphire], x1);
	case seq_sapphireleft:  return sequenceForward  (image[img_sapphire], step, totalsteps, x1);
	case seq_sapphireright: return sequenceBackward (image[img_sapphire], step, totalsteps, x1);
	case seq_sapphireglitter: return sequenceForward (image[img_sapphire], step, totalsteps, x1);
	case seq_sapphirebreak:  return sequenceForward (image[img_saphbrk], step, totalsteps, x1);
	case seq_sapphireaway: return sequenceForward (image[img_saphaway], step, totalsteps, x1);

	case seq_rubyrest:  return sequenceRest (image[img_ruby], x1);
	case seq_rubydown:  return sequenceRest (image[img_ruby], x1);
	case seq_rubyleft:  return sequenceForward  (image[img_ruby], step, totalsteps, x1);
	case seq_rubyright: return sequenceBackward (image[img_ruby], step, totalsteps, x1);
	case seq_rubyaway: return sequenceForward (image[img_rubyaway], step, totalsteps, x1);

	case seq_bagrest:		return sequenceRest (image[img_bag], x1);
	case seq_bagdown:		return sequenceRest (image[img_bag], x1);
	case seq_bagleft:		return sequenceBackward (image[img_bag], step, totalsteps, x1);
	case seq_bagright:		return sequenceForward (image[img_bag], step, totalsteps, x1);
	case seq_bagexpl:		return sequenceForward (image[img_bagexpl], step, totalsteps, x1);

	case seq_bombrest:		return sequenceRest (image[img_bomb], x1);
	case seq_bombdown:		return sequenceForward (image[img_bomb], step, totalsteps, x1);
	case seq_bombleft:		return sequenceForward (image[img_bomb], step, totalsteps, x1);
	case seq_bombright:		return sequenceBackward (image[img_bomb], step, totalsteps, x1);

	case seq_dooropen:		return sequenceForward (image[img_dooropen], step, totalsteps, x1);
	case seq_doorclose:		return sequenceBackward (image[img_dooropen], step, totalsteps, x1);
	case seq_doorisopen:	return sequenceRest (image[img_dooropen], x1);
	case seq_cushion:		return sequenceRest (image[img_cushion], x1);
	case seq_cushionbumb:	return sequenceForward (image[img_cushion], step, totalsteps, x1);
	case seq_elevatorup:	return sequenceForward (image[img_elevator], step, totalsteps, x1);
	case seq_elevatordown:	return sequenceBackward (image[img_elevator], step, totalsteps, x1);
	case seq_pushleftforward: return sequenceForward (image[img_pushlft], step, totalsteps, x1);
	case seq_pushleftbackward:return sequenceBackward (image[img_pushlft], step, totalsteps, x1);
	case seq_pushrightforward: return sequenceForward (image[img_pushrgt], step, totalsteps, x1);
	case seq_pushrightbackward:return sequenceBackward (image[img_pushrgt], step, totalsteps, x1);
	case seq_box:			return sequenceRest (image[img_box], x1);
	case seq_laserbr:		return sequenceForward (image[img_laserbr], step, totalsteps, x1); 
	case seq_lasertl:		return sequenceForward (image[img_lasertl], step, totalsteps, x1);
	case seq_laserbl:		return sequenceForward (image[img_laserbl], step, totalsteps, x1);
	case seq_lasertr:		return sequenceForward (image[img_lasertr], step, totalsteps, x1);
	case seq_laserv:		return sequenceForward (image[img_laserv], step, totalsteps, x1);
	case seq_laserh:		return sequenceForward (image[img_laserh], step, totalsteps, x1);
	case seq_tickbomb:		return sequenceForward (image[img_tickbomb], step, totalsteps, x1);
	
	case seq_explode1:		return nthSequenceOf5 (image[img_explode], 0, step, totalsteps, x1);
	case seq_explode2:		return nthSequenceOf5 (image[img_explode], 1, step, totalsteps, x1);
	case seq_explode3:		return nthSequenceOf5 (image[img_explode], 2, step, totalsteps, x1);
	case seq_explode4:		return nthSequenceOf5 (image[img_explode], 3, step, totalsteps, x1);
	case seq_explode5:		return nthSequenceOf5 (image[img_explode], 4, step, totalsteps, x1);
	
	case seq_swamp:			return sequenceForward (image[img_swamp], step, totalsteps, x1);
	case seq_dropup:		return sequenceForward (image[img_dropup], step, totalsteps, x1);
	case seq_dropdown:		return sequenceForward (image[img_dropdwn], step, totalsteps, x1);
	case seq_dropleft:		return sequenceForward (image[img_droplft], step, totalsteps, x1);
	case seq_dropright:		return sequenceForward (image[img_droprgt], step, totalsteps, x1);
	case seq_drop:			return sequenceForward (image[img_drop], step, totalsteps, x1);
	case seq_drophit:		return sequenceForward (image[img_drophit], step, totalsteps, x1);

	case seq_convert:		return sequenceForward (image[img_convert], step, totalsteps, x1);
	case seq_dispenser1:	return sequenceForward (image[img_dispen1], step, totalsteps, x1);
	case seq_dispenser2:	return sequenceForward (image[img_dispen2], step, totalsteps, x1);

	case seq_acid1:			return nthSequenceOf5 (image[img_acid], 0, step, totalsteps, x1);
	case seq_acid2:			return nthSequenceOf5 (image[img_acid], 1, step, totalsteps, x1);
	case seq_acid3:			return nthSequenceOf5 (image[img_acid], 2, step, totalsteps, x1);
	case seq_acid4:			return nthSequenceOf5 (image[img_acid], 3, step, totalsteps, x1);
	case seq_acid5:			return nthSequenceOf5 (image[img_acid], 4, step, totalsteps, x1);
	case seq_acidleft:		x1=0; return image[img_acidleft];
	case seq_acidright:	    x1=0; return image[img_acidrgt];
	case seq_acidalone:	    x1=0; return image[img_acidalne];

	case seq_lorryleft:		return sequenceForward (image[img_lorrylft], step, totalsteps, x1);
	case seq_lorryright:	return sequenceForward (image[img_lorryrgt], step, totalsteps, x1);
	case seq_lorryup:		return sequenceForward (image[img_lorryup], step, totalsteps, x1);
	case seq_lorrydown:		return sequenceForward (image[img_lorrydwn], step, totalsteps, x1);
	case seq_lorryturnleftdown: return sequenceBackward (image[img_lorrytdl], step, totalsteps, x1);
	case seq_lorryturndownleft:	return sequenceForward (image[img_lorrytdl], step, totalsteps, x1);
	case seq_lorryturnupleft:	return sequenceBackward (image[img_lorrytlu], step, totalsteps, x1);
	case seq_lorryturnleftup:	return sequenceForward (image[img_lorrytlu], step, totalsteps, x1);
	case seq_lorryturnrightdown: return sequenceForward (image[img_lorrytrd], step, totalsteps, x1);
	case seq_lorryturndownright:return sequenceBackward (image[img_lorrytrd], step, totalsteps, x1);
	case seq_lorryturnupright:	return sequenceForward (image[img_lorrytur], step, totalsteps, x1);
	case seq_lorryturnrightup:	return sequenceBackward (image[img_lorrytur], step, totalsteps, x1);
	
	case seq_bugleft:			return sequenceForward (image[img_buglft], step, totalsteps, x1);
	case seq_bugright:			return sequenceForward (image[img_bugrgt], step, totalsteps, x1);
	case seq_bugup:				return sequenceForward (image[img_bugup], step, totalsteps, x1);
	case seq_bugdown:			return sequenceForward (image[img_bugdwn], step, totalsteps, x1);
	case seq_bugturnleftdown:	return sequenceForward (image[img_bugtld], step, totalsteps, x1);
	case seq_bugturndownleft:	return sequenceBackward (image[img_bugtld], step, totalsteps, x1);
	case seq_bugturnupleft:		return sequenceForward (image[img_bugtul], step, totalsteps, x1);
	case seq_bugturnleftup:		return sequenceBackward (image[img_bugtul], step, totalsteps, x1);
	case seq_bugturnrightdown:	return sequenceBackward (image[img_bugtdr], step, totalsteps, x1);
	case seq_bugturndownright:	return sequenceForward (image[img_bugtdr], step, totalsteps, x1);
	case seq_bugturnupright:	return sequenceBackward (image[img_bugtru], step, totalsteps, x1);
	case seq_bugturnrightup:	return sequenceForward (image[img_bugtru], step, totalsteps, x1);

	case seq_yamyamleft:	return sequenceForward (image[img_yamyamlt], step, totalsteps, x1);
	case seq_yamyamright:	return sequenceForward (image[img_yamyamrt], step, totalsteps, x1);
	case seq_yamyamdown:	return sequenceForward (image[img_yamyamdn], step, totalsteps, x1);
	case seq_yamyamup:		return sequenceForward (image[img_yamyamup], step, totalsteps, x1);
	case seq_yamyaming:		return sequenceForward (image[img_yamyam], step, totalsteps, x1);

	case seq_wheel:			return sequenceForward (image[img_wheel], step, totalsteps, x1);
	case seq_robot1:		return sequenceForward (image[img_robot], step, totalsteps, x1);
	case seq_robot2:		return sequenceBackward (image[img_robot], step, totalsteps, x1);

	case seq_doorblue:		return sequenceForward (image[img_doorblue], step, totalsteps,x1);
	case seq_doorred:		return sequenceForward (image[img_doorred], step, totalsteps,x1);
	case seq_doorgreen:		return sequenceForward (image[img_doorgree], step, totalsteps,x1);
	case seq_dooryellow:	return sequenceForward (image[img_doorylow], step, totalsteps,x1);

	case seq_keyblue1:		return nthSequenceOf5 (image[img_keyblue], 0, step, totalsteps, x1);
	case seq_keyblue2:		return nthSequenceOf5 (image[img_keyblue], 1, step, totalsteps, x1);
	case seq_keyblue3:		return nthSequenceOf5 (image[img_keyblue], 2, step, totalsteps, x1);
	case seq_keyblue4:		return nthSequenceOf5 (image[img_keyblue], 3, step, totalsteps, x1);
	case seq_keyblue5:		return nthSequenceOf5 (image[img_keyblue], 4, step, totalsteps, x1);
	case seq_keyred1:		return nthSequenceOf5 (image[img_keyred], 0, step, totalsteps, x1);
	case seq_keyred2:		return nthSequenceOf5 (image[img_keyred], 1, step, totalsteps, x1);
	case seq_keyred3:		return nthSequenceOf5 (image[img_keyred], 2, step, totalsteps, x1);
	case seq_keyred4:		return nthSequenceOf5 (image[img_keyred], 3, step, totalsteps, x1);
	case seq_keyred5:		return nthSequenceOf5 (image[img_keyred], 4, step, totalsteps, x1);
	case seq_keygreen1:		return nthSequenceOf5 (image[img_keygreen], 0, step, totalsteps, x1);
	case seq_keygreen2:		return nthSequenceOf5 (image[img_keygreen], 1, step, totalsteps, x1);
	case seq_keygreen3:		return nthSequenceOf5 (image[img_keygreen], 2, step, totalsteps, x1);
	case seq_keygreen4:		return nthSequenceOf5 (image[img_keygreen], 3, step, totalsteps, x1);
	case seq_keygreen5:		return nthSequenceOf5 (image[img_keygreen], 4, step, totalsteps, x1);
	case seq_keyyellow1:		return nthSequenceOf5 (image[img_keyellow], 0, step, totalsteps, x1);
	case seq_keyyellow2:		return nthSequenceOf5 (image[img_keyellow], 1, step, totalsteps, x1);
	case seq_keyyellow3:		return nthSequenceOf5 (image[img_keyellow], 2, step, totalsteps, x1);
	case seq_keyyellow4:		return nthSequenceOf5 (image[img_keyellow], 3, step, totalsteps, x1);
	case seq_keyyellow5:		return nthSequenceOf5 (image[img_keyellow], 4, step, totalsteps, x1);

	case seq_1rest:		return sequenceRest (image[img_1man], x1);
	case seq_1walkup:	return sequenceForward (image[img_1walkup], step, totalsteps, x1);
	case seq_1walkdown:	return sequenceForward (image[img_1walkdwn], step, totalsteps, x1);
	case seq_1walkleft:	return sequenceForward (image[img_1walklft], step, totalsteps, x1);
	case seq_1walkright:return sequenceForward (image[img_1walkrgt], step, totalsteps, x1);
	case seq_1digup:	return sequenceForward (image[img_1digup], step, totalsteps, x1);
	case seq_1digdown:	return sequenceForward (image[img_1digdwn], step, totalsteps, x1);
	case seq_1digleft:	return sequenceForward (image[img_1diglft], step, totalsteps, x1);
	case seq_1digright:	return sequenceForward (image[img_1digrgt], step, totalsteps, x1);
	case seq_1pushup:	return sequenceForward (image[img_1walkup], step, totalsteps, x1);
	case seq_1pushdown:	return sequenceForward (image[img_1walkdwn], step, totalsteps, x1);
	case seq_1pushleft:	return sequenceForward (image[img_1pushlft], step, totalsteps, x1);
	case seq_1pushright:return sequenceForward (image[img_1pushrgt], step, totalsteps, x1);
	case seq_1blink:	return sequenceForward (image[img_1man], step, totalsteps, x1);

	case seq_2rest:		return sequenceRest (image[img_2man], x1);
	case seq_2walkup:	return sequenceForward (image[img_2walkup], step, totalsteps, x1);
	case seq_2walkdown:	return sequenceForward (image[img_2walkdwn], step, totalsteps, x1);
	case seq_2walkleft:	return sequenceForward (image[img_2walklft], step, totalsteps, x1);
	case seq_2walkright:return sequenceForward (image[img_2walkrgt], step, totalsteps, x1);
	case seq_2digup:	return sequenceForward (image[img_2digup], step, totalsteps, x1);
	case seq_2digdown:	return sequenceForward (image[img_2digdwn], step, totalsteps, x1);
	case seq_2digleft:	return sequenceForward (image[img_2diglft], step, totalsteps, x1);
	case seq_2digright:	return sequenceForward (image[img_2digrgt], step, totalsteps, x1);
	case seq_2pushup:	return sequenceForward (image[img_2walkup], step, totalsteps, x1);
	case seq_2pushdown:	return sequenceForward (image[img_2walkdwn], step, totalsteps, x1);
	case seq_2pushleft:	return sequenceForward (image[img_2pushlft], step, totalsteps, x1);
	case seq_2pushright:return sequenceForward (image[img_2pushrgt], step, totalsteps, x1);
	case seq_2blink:	return sequenceForward (image[img_2man], step, totalsteps, x1);

	case seq_movie0_0:     return nthMovieSequenceOfm (image[img_movie0],0,1, step,totalsteps, x1);
	case seq_movie1_0:     return nthMovieSequenceOfm (image[img_movie1],0,1, step,totalsteps, x1);
	case seq_movie2_0:     return nthMovieSequenceOfm (image[img_movie2],0,1, step,totalsteps, x1);
	case seq_movie3_0:     return nthMovieSequenceOfm (image[img_movie3],0,1, step,totalsteps, x1);
	case seq_movie4_0:     return nthMovieSequenceOfm (image[img_movie4],0,1, step,totalsteps, x1);

	case seq_movie5_0:     return nthMovieSequenceOfm (image[img_movie5],0,2, step,totalsteps, x1);
	case seq_movie5_1:     return nthMovieSequenceOfm (image[img_movie5],1,2, step,totalsteps, x1);
	case seq_movie6_0:     return nthMovieSequenceOfm (image[img_movie6],0,2, step,totalsteps, x1);
	case seq_movie6_1:     return nthMovieSequenceOfm (image[img_movie6],1,2, step,totalsteps, x1);
	case seq_movie7_0:     return nthMovieSequenceOfm (image[img_movie7],0,2, step,totalsteps, x1);
	case seq_movie7_1:     return nthMovieSequenceOfm (image[img_movie7],1,2, step,totalsteps, x1);
	case seq_movie8_0:     return nthMovieSequenceOfm (image[img_movie8],0,2, step,totalsteps, x1);
	case seq_movie8_1:     return nthMovieSequenceOfm (image[img_movie8],1,2, step,totalsteps, x1);
	case seq_movie9_0:     return nthMovieSequenceOfm (image[img_movie9],0,2, step,totalsteps, x1);
	case seq_movie9_1:     return nthMovieSequenceOfm (image[img_movie9],1,2, step,totalsteps, x1);

	case seq_movie10_0:    return nthMovieSequenceOfm (image[img_movie10],0,4, step,totalsteps, x1);
	case seq_movie10_1:    return nthMovieSequenceOfm (image[img_movie10],1,4, step,totalsteps, x1);
	case seq_movie10_2:    return nthMovieSequenceOfm (image[img_movie10],2,4, step,totalsteps, x1);
	case seq_movie10_3:    return nthMovieSequenceOfm (image[img_movie10],3,4, step,totalsteps, x1);
	case seq_movie11_0:    return nthMovieSequenceOfm (image[img_movie11],0,4, step,totalsteps, x1);
	case seq_movie11_1:    return nthMovieSequenceOfm (image[img_movie11],1,4, step,totalsteps, x1);
	case seq_movie11_2:    return nthMovieSequenceOfm (image[img_movie11],2,4, step,totalsteps, x1);
	case seq_movie11_3:    return nthMovieSequenceOfm (image[img_movie11],3,4, step,totalsteps, x1);
	case seq_movie12_0:    return nthMovieSequenceOfm (image[img_movie12],0,4, step,totalsteps, x1);
	case seq_movie12_1:    return nthMovieSequenceOfm (image[img_movie12],1,4, step,totalsteps, x1);
	case seq_movie12_2:    return nthMovieSequenceOfm (image[img_movie12],2,4, step,totalsteps, x1);
	case seq_movie12_3:    return nthMovieSequenceOfm (image[img_movie12],3,4, step,totalsteps, x1);
	case seq_movie13_0:    return nthMovieSequenceOfm (image[img_movie13],0,4, step,totalsteps, x1);
	case seq_movie13_1:    return nthMovieSequenceOfm (image[img_movie13],1,4, step,totalsteps, x1);
	case seq_movie13_2:    return nthMovieSequenceOfm (image[img_movie13],2,4, step,totalsteps, x1);
	case seq_movie13_3:    return nthMovieSequenceOfm (image[img_movie13],3,4, step,totalsteps, x1);
	case seq_movie14_0:    return nthMovieSequenceOfm (image[img_movie14],0,4, step,totalsteps, x1);
	case seq_movie14_1:    return nthMovieSequenceOfm (image[img_movie14],1,4, step,totalsteps, x1);
	case seq_movie14_2:    return nthMovieSequenceOfm (image[img_movie14],2,4, step,totalsteps, x1);
	case seq_movie14_3:    return nthMovieSequenceOfm (image[img_movie14],3,4, step,totalsteps, x1);

	case seq_movie15_0:    return nthMovieSequenceOfm (image[img_movie15],0,8, step,totalsteps, x1);
	case seq_movie15_1:    return nthMovieSequenceOfm (image[img_movie15],1,8, step,totalsteps, x1);
	case seq_movie15_2:    return nthMovieSequenceOfm (image[img_movie15],2,8, step,totalsteps, x1);
	case seq_movie15_3:    return nthMovieSequenceOfm (image[img_movie15],3,8, step,totalsteps, x1);
	case seq_movie15_4:    return nthMovieSequenceOfm (image[img_movie15],4,8, step,totalsteps, x1);
	case seq_movie15_5:    return nthMovieSequenceOfm (image[img_movie15],5,8, step,totalsteps, x1);
	case seq_movie15_6:    return nthMovieSequenceOfm (image[img_movie15],6,8, step,totalsteps, x1);
	case seq_movie15_7:    return nthMovieSequenceOfm (image[img_movie15],7,8, step,totalsteps, x1);
	case seq_movie16_0:    return nthMovieSequenceOfm (image[img_movie16],0,8, step,totalsteps, x1);
	case seq_movie16_1:    return nthMovieSequenceOfm (image[img_movie16],1,8, step,totalsteps, x1);
	case seq_movie16_2:    return nthMovieSequenceOfm (image[img_movie16],2,8, step,totalsteps, x1);
	case seq_movie16_3:    return nthMovieSequenceOfm (image[img_movie16],3,8, step,totalsteps, x1);
	case seq_movie16_4:    return nthMovieSequenceOfm (image[img_movie16],4,8, step,totalsteps, x1);
	case seq_movie16_5:    return nthMovieSequenceOfm (image[img_movie16],5,8, step,totalsteps, x1);
	case seq_movie16_6:    return nthMovieSequenceOfm (image[img_movie16],6,8, step,totalsteps, x1);
	case seq_movie16_7:    return nthMovieSequenceOfm (image[img_movie16],7,8, step,totalsteps, x1);
	case seq_movie17_0:    return nthMovieSequenceOfm (image[img_movie17],0,8, step,totalsteps, x1);
	case seq_movie17_1:    return nthMovieSequenceOfm (image[img_movie17],1,8, step,totalsteps, x1);
	case seq_movie17_2:    return nthMovieSequenceOfm (image[img_movie17],2,8, step,totalsteps, x1);
	case seq_movie17_3:    return nthMovieSequenceOfm (image[img_movie17],3,8, step,totalsteps, x1);
	case seq_movie17_4:    return nthMovieSequenceOfm (image[img_movie17],4,8, step,totalsteps, x1);
	case seq_movie17_5:    return nthMovieSequenceOfm (image[img_movie17],5,8, step,totalsteps, x1);
	case seq_movie17_6:    return nthMovieSequenceOfm (image[img_movie17],6,8, step,totalsteps, x1);
	case seq_movie17_7:    return nthMovieSequenceOfm (image[img_movie17],7,8, step,totalsteps, x1);
	case seq_movie18_0:    return nthMovieSequenceOfm (image[img_movie18],0,8, step,totalsteps, x1);
	case seq_movie18_1:    return nthMovieSequenceOfm (image[img_movie18],1,8, step,totalsteps, x1);
	case seq_movie18_2:    return nthMovieSequenceOfm (image[img_movie18],2,8, step,totalsteps, x1);
	case seq_movie18_3:    return nthMovieSequenceOfm (image[img_movie18],3,8, step,totalsteps, x1);
	case seq_movie18_4:    return nthMovieSequenceOfm (image[img_movie18],4,8, step,totalsteps, x1);
	case seq_movie18_5:    return nthMovieSequenceOfm (image[img_movie18],5,8, step,totalsteps, x1);
	case seq_movie18_6:    return nthMovieSequenceOfm (image[img_movie18],6,8, step,totalsteps, x1);
	case seq_movie18_7:    return nthMovieSequenceOfm (image[img_movie18],7,8, step,totalsteps, x1);
	case seq_movie19_0:    return nthMovieSequenceOfm (image[img_movie19],0,8, step,totalsteps, x1);
	case seq_movie19_1:    return nthMovieSequenceOfm (image[img_movie19],1,8, step,totalsteps, x1);
	case seq_movie19_2:    return nthMovieSequenceOfm (image[img_movie19],2,8, step,totalsteps, x1);
	case seq_movie19_3:    return nthMovieSequenceOfm (image[img_movie19],3,8, step,totalsteps, x1);
	case seq_movie19_4:    return nthMovieSequenceOfm (image[img_movie19],4,8, step,totalsteps, x1);
	case seq_movie19_5:    return nthMovieSequenceOfm (image[img_movie19],5,8, step,totalsteps, x1);
	case seq_movie19_6:    return nthMovieSequenceOfm (image[img_movie19],6,8, step,totalsteps, x1);
	case seq_movie19_7:    return nthMovieSequenceOfm (image[img_movie19],7,8, step,totalsteps, x1);
	}
	return NULL;
}




Artwork::Artwork() 
{
	tilesize = basetilesize;
	for (int i=0; i<img_end; i++) image[i]=NULL;
}


Artwork::~Artwork ()
{
	unload();
	doLog (2, "artwork unloaded");
}

void Artwork::load (charstring &name, charstring& movieset, int shrinkfactor)
{
	int i;

	doLog (2, "loading artwork: %s",name.data());

	// compute size of all tiles
	tilesize = basetilesize / shrinkfactor;

	// load all images from files
	for (int p=0; p<=lastpriority; p++) {
		for (i=0; i<img_end; i++) {
			if (imagename[i].prio != p) continue;

			char fname[200];

			if (imagename[i].movie) {
				if (movieset.size()>0) {
					sprintf (fname, "movie\\%s.zip#%s.bmp", movieset.data(), imagename[i].name);
					if (loadOrReuseImage (charstring(fname), shrinkfactor, i) ) continue;

					sprintf (fname, "movie\\%s\\%s.bmp", movieset.data(), imagename[i].name);
					if (loadOrReuseImage (charstring(fname), shrinkfactor, i) ) continue;

					doLog (3, "Could not load movie image: %s", imagename[i].name);
				}
			} else {
				sprintf (fname, "art\\%s.zip#%s.bmp", name.data(), imagename[i].name);
				if (loadOrReuseImage (charstring(fname), shrinkfactor, i) ) continue;

				sprintf (fname, "art\\%s\\%s.bmp", name.data(), imagename[i].name);
				if (loadOrReuseImage (charstring(fname), shrinkfactor, i) ) continue;

				sprintf (fname, "art\\default.zip#%s.bmp", imagename[i].name);
				if (loadOrReuseImage (charstring(fname), shrinkfactor, i) ) continue;

				sprintf (fname, "art\\default\\%s.bmp", imagename[i].name);
				if (loadOrReuseImage (charstring(fname), shrinkfactor, i) ) continue;

				doLog (1, "Could not load image: %s", imagename[i].name);
			}
		}
	}

	// remove all images from the cache, that we did not use here
	releaseImageCache();

	// determine background color
	backgroundcolor = 0;
	if (image[img_1man]) backgroundcolor = image[img_1man]->getTransparentColor();
}

void Artwork::unload () 
{
	releaseImageCache();
	
	for (int index=0; index<img_end; index++) {
		if (image[index]) {
			imagecache.resize(index+1, NULL);
			imagecache[index] = image[index];
			image[index] = NULL;
		}
	}
}

bool Artwork::loadOrReuseImage(charstring& fname, int shrinkfactor, int index)
{
	// check, if we already have the image in our cache
	if (imagecache.size()>index) {
		Image* i = imagecache[index];
		if (i) {
			if (_stricmp (i->filename.data(), fname.data())==0
			&& shrinkfactor==i->shrinkfactor) {
				imagecache[index] = NULL;
				image[index] = i;
				return true;
			}
		}
	}

	// otherwise try to load it from the file
	return ( (image[index] = loadImage (fname,shrinkfactor)) != NULL);
}


static int rangestart (int l, int w, int innerw, double distribution) {
	if (w>innerw) { 
		int l2 = (int) (w*distribution - innerw*0.5);
		if (l2<0) l2=0;
		if (l2+innerw>w) l2=w-innerw;
		l+=l2;
		w=innerw;
	}
	return l;
}

static int rangeend (int l, int w, int innerw, double distribution) {
	if (w>innerw) { 
		int l2 = (int) (w*distribution - innerw*0.5);
		if (l2<0) l2=0;
		if (l2+innerw>w) l2=w-innerw;
		l+=l2;
		w=innerw;
	}
	return l+w;
}

GameFrame::GameFrame (int l, int t, int w, int h, 
					  Game* g, int main, Artwork* a,
					  double toright, double tobottom)
: Frame (rangestart (l,w, (g->getWidth()-2)*a->tilesize,  toright),
		 rangestart (t,h, (g->getHeight()-2)*a->tilesize, tobottom),
		 rangeend   (l,w, (g->getWidth()-2)*a->tilesize,  toright),
		 rangeend   (t,h, (g->getHeight()-2)*a->tilesize,  tobottom),
		 false )
{
	game = g;
	mainplayer = main;
	artwork = a;
	scrollx = 0;
	scrolly = 0;
	tilesize = a->tilesize;

	for (int r=0; r<2; r++) {
		rasterscrollx[r] = 0;
		rasterscrolly[r] = 0;
	}
}

GameFrame::~GameFrame () 
{
}



void GameFrame::computeScrollRegion ()
{
	int width = right-left;
	int height = bottom-top;

	int midx = -( width/2) + tilesize/2;
	int midy = -( height/2) + tilesize/2;
	while ( (left+midx+4096) % 4 != 0) midx++;  // find a 4-pixel alignment

	int rangex=(game->getWidth()-1) * tilesize;
	int rangey=(game->getHeight()-1) * tilesize;

	int px,py;
	game->getFocusPoint (tilesize, mainplayer, px,py);

	scrollx=midx + px;
	scrolly=midy + py;

	if (scrollx>=rangex-width)  scrollx=rangex-width;
	if (scrolly>=rangey-height) scrolly=rangey-height;
	if (scrollx<tilesize) scrollx=tilesize;
	if (scrolly<tilesize) scrolly=tilesize;

	// check for manual scroll command
	if (mouse.isButtonNew(0)) {
		mouse.resetCoordinates(scrollx,scrolly,
								tilesize,tilesize, rangex-width,rangey-height);
	}
	if (mouse.isButtonDown(0)) {
		scrollx = mouse.getMouseX();
		scrolly = mouse.getMouseY();
	}

	// adjust to screen coordinates
	scrollx-=left;
	scrolly-=top;
}



void GameFrame::setDirtyRect (int r, int x1, int y1, int x2, int y2)
{
	int tx1 = (x1+scrollx) / tilesize;
	int ty1 = (y1+scrolly) / tilesize;
	int tx2 = ((x2-1)+scrollx) / tilesize;
	int ty2 = ((y2-1)+scrolly) / tilesize;

	if (tx1<0) tx1=0;
	if (ty1<0) ty1=0;
	if (tx2>=game->getWidth())  tx2=game->getWidth()-1; 
	if (ty2>=game->getHeight()) ty2=game->getHeight()-1; 
	
	for (int x=tx1; x<=tx2; x++) {
		for (int y=ty1; y<=ty2; y++) {
			raster[r][x][y] = tile_invalid;
		}
	}
}

void GameFrame::setCleanRect (int r, int x1, int y1, int x2, int y2)
{
	int tx1 = (x1+scrollx) / tilesize;
	int ty1 = (y1+scrolly) / tilesize;
	int tx2 = ((x2-1)+scrollx) / tilesize;
	int ty2 = ((y2-1)+scrolly) / tilesize;

	if (tx1<0) tx1=0;
	if (ty1<0) ty1=0;
	if (tx2>=game->getWidth())  tx2=game->getWidth()-1; 
	if (ty2>=game->getHeight()) ty2=game->getHeight()-1; 
	
	for (int x=tx1; x<=tx2; x++) {
		for (int y=ty1; y<=ty2; y++) {
			raster[r][x][y] = game->getFixedTile(x,y);
		}
	}
}


void GameFrame::refreshTiles (int r, int x1, int y1, int x2, int y2, 
							  bool transparent, bool onlyincremental,
							  list<Frame*>::iterator &it)
{
	int tx1 = (x1+scrollx) / tilesize;
	int ty1 = (y1+scrolly) / tilesize;
	int tx2 = (x2-1+scrollx) / tilesize;
	int ty2 = (y2-1+scrolly) / tilesize;

	if (tx1<0) tx1=0;
	if (ty1<0) ty1=0;
	if (tx2>=game->getWidth())  tx2=game->getWidth()-1;
	if (ty2>=game->getHeight()) ty2=game->getHeight()-1;

	for (int y=ty1; y<=ty2; y++) {
		for (int x=tx1; x<=tx2; x++) {
			tiletype tile = game->getFixedTile (x,y);

			if (onlyincremental && tile == raster[r][x][y]) continue;

			int dx1 = x*tilesize - scrollx;
			int dy1 = y*tilesize - scrolly;
			int dx2 = dx1+tilesize;
			int dy2 = dy1+tilesize;
			int sx = 0;
			int sy = 0;
			Image* img = artwork->getImageForTile (tile, sx);

			if ( clip (sx,sy, dx1,dy1,dx2,dy2, x1,y1,x2,y2) ) {
				if (img) {
					theScreen.draw (img, sx,sy, dx1,dy1,dx2,dy2, transparent);
					invalidateHigher (r,it, dx1,dy1,dx2,dy2);
				} else if (!transparent) {
					theScreen.fill (artwork->getBackgroundColor(), dx1, dy1, dx2, dy2);
					invalidateHigher (r,it, dx1,dy1,dx2,dy2);
				}
			}

			img = artwork->getImage2ForTile (tile, sx);
			if (img) {
				dx1 = x*tilesize - scrollx;
				dy1 = y*tilesize - scrolly;
				dx2 = dx1+tilesize;
				dy2 = dy1+tilesize;
				sy = 0;
				if ( clip (sx,sy, dx1,dy1,dx2,dy2, x1,y1,x2,y2) ) {
					theScreen.draw (img, sx,sy, dx1,dy1,dx2,dy2, true);
				}
			}
		}
	}
}

void GameFrame::refreshSequences (int r, int x1, int y1, int x2, int y2,
								  list<Frame*>::iterator &it)
{
	int microstepsperstep = game->getMicroStepsPerStep();
	int microcounter = game->getMicroCounter();
	int movepixels = (tilesize * microcounter) / microstepsperstep;

	// draw the background sequences
	int layer=Game::background;
	int idx;
	for (idx=0; idx<game->getAnimationNumber(layer); idx++) {
		Animation* a = game->getAnimation (layer, idx);
		int sx=0;
		int sy=0;
		Image* img = artwork->getImageForSequence (a->seq, microcounter, microstepsperstep, sx);
		if (img) {
			int dx1 = a->x*tilesize - scrollx + a->dx*movepixels;
			int dy1 = a->y*tilesize - scrolly + a->dy*movepixels;
			int dx2 = dx1+tilesize;
			int dy2 = dy1+tilesize;

			if ( clip (sx,sy, dx1,dy1,dx2,dy2, x1,y1,x2,y2) ) {
				theScreen.draw (img, sx,sy, dx1,dy1,dx2,dy2, true);
				invalidateHigher (r,it, dx1,dy1,dx2,dy2);
				setDirtyRect (r, dx1,dy1,dx2,dy2);
			}
		}
	}

	// repair all tiles above the background sequences as good as it gets
	for (idx=0; idx<game->getAnimationNumber(layer); idx++) {
		Animation* a = game->getAnimation (layer, idx);
		int sx=0; 
		int sy=0;
		int dx1 = a->x*tilesize - scrollx + a->dx*movepixels;
		int dy1 = a->y*tilesize - scrolly + a->dy*movepixels;
		int dx2 = dx1+tilesize;
		int dy2 = dy1+tilesize;

		if ( clip (sx,sy, dx1,dy1,dx2,dy2, x1,y1,x2,y2) ) {
			refreshTiles (r, dx1,dy1,dx2,dy2, true, false, it);
		}
	}
	
	// draw the foreground sequences
	for (layer=Game::foreground; layer<Game::layers; layer++) {
		for (int idx=0; idx<game->getAnimationNumber(layer); idx++) {
			Animation* a = game->getAnimation (layer, idx);
			int sx=0;
			int sy=0;
			Image* img = artwork->getImageForSequence (a->seq, microcounter, microstepsperstep, sx);
			if (img) {
				int dx1 = a->x*tilesize - scrollx + a->dx*movepixels;
				int dy1 = a->y*tilesize - scrolly + a->dy*movepixels;
				int dx2 = dx1+tilesize;
				int dy2 = dy1+tilesize;

				if ( clip (sx,sy, dx1,dy1,dx2,dy2, x1,y1,x2,y2) ) {
					theScreen.draw (img, sx,sy, dx1,dy1,dx2,dy2, true );
					invalidateHigher (r,it, dx1,dy1,dx2,dy2);
					setDirtyRect (r, dx1,dy1,dx2,dy2);
				}
			}
		}
	}
}



void GameFrame::drawChanges (int currentpage, list<Frame*>::iterator& it)
{
	int r;

	bool drawincremental = true;
	computeScrollRegion ();
	if (scrollx!=rasterscrollx[currentpage] || scrolly!=rasterscrolly[currentpage]) {
		rasterscrollx[currentpage] = scrollx;
		rasterscrolly[currentpage] = scrolly;
		drawincremental = false;
	}
	
	RectangleList* rl = &(valid[currentpage]);
	for (r=0; r<rl->rectnum;r++) {

		refreshTiles (currentpage, rl->rect[r].left,rl->rect[r].top,
						 rl->rect[r].right,rl->rect[r].bottom, 
						false, drawincremental,
						it);
	}

	setCleanRect(currentpage, left,top, right,bottom);

	for (r=0; r<rl->rectnum; r++) {
		refreshSequences (currentpage, rl->rect[r].left,rl->rect[r].top,
						rl->rect[r].right,rl->rect[r].bottom, 
						it);
	}
}

void GameFrame::updateInvalid (int currentpage, list<Frame*>::iterator& it, RectangleList& invalid)
{
	int r;
	for (r=0; r<invalid.rectnum; r++) {
		refreshTiles (currentpage, invalid.rect[r].left,invalid.rect[r].top,
						invalid.rect[r].right,invalid.rect[r].bottom, 
						false,false, it);

		refreshSequences (currentpage, invalid.rect[r].left,invalid.rect[r].top,
						invalid.rect[r].right,invalid.rect[r].bottom, 
						it);
	}
}




	
StatusFrame::StatusFrame (int l, int t, int w, int h, Game* g, Image* p)
: Frame (l,t,w,h, true)
{
	game = g;
	panel = p;
	setAlwaysDirty();
}


void StatusFrame::writeNumber (int num, int len, int dx, int dy, int x1,int y1, int x2, int y2)
{
	for (int d=len-1; d>=0; d--) {
		int n = 0;
		if (num>=0) {
			n = num%10;
			num /= 10;
		}
		theScreen.drawClipped (panel,n*16,40, dx+d*16,dy,dx+d*16+16,dy+22, x1,y1,x2,y2,true);
	}
}


StatusFrame1::StatusFrame1 (int x, int y, Game* g, Image* p)
: StatusFrame (x-statuswidth, y-statusheight, x,y, g,p)
{
}

void StatusFrame1::update (int currentpage, int x1, int y1, int x2, int y2)
{
	theScreen.drawClipped (panel, 0,0, 
		left+4*20,top+0, left+4*20+40,top+40, 
		x1,y1,x2,y2, true);
	theScreen.drawClipped (panel, 40,0, 
		left+4*20+1*40+3*16,top+0, left+4*20+1*40+3*16+40,top+40, 
		x1,y1,x2,y2, true);
	theScreen.drawClipped (panel, 280,0, 
		left+4*20+2*40+6*16,top+0, left+4*20+2*40+6*16+40,top+40, 
		x1,y1,x2,y2, true);
	theScreen.drawClipped (panel, 80,0, 
		left+4*20+3*40+10*16,top+0, left+4*20+3*40+10*16+40,top+40, 
		x1,y1,x2,y2, true);

	int t = game->getAvailableTime();
	if (t>0) t -= game->getPositionCounter();
		else t = game->getPositionCounter();
	writeNumber (t, 4, left+4*20+3*40+10*16+40,top+9, x1,y1,x2,y2);
	t = game->getAvailableMoves();
	if (t>0) t -= game->getMoveCounter();
		else t = game->getMoveCounter();
	writeNumber (t, 4, left+4*20+2*40+6*16+40, top+9, x1,y1,x2,y2);
	writeNumber (game->getEmeraldsNeeded(), 3, left+4*20+40+3*16+40,top+9, x1,y1,x2,y2);
	writeNumber (game->getTimeBombsLeft(0), 3, left+4*20+40,top+9, x1,y1,x2,y2);

	if (game->isDone(0)) {
		theScreen.drawClipped (panel, 200,0, left+40,top,left+80,bottom, x1,y1,x2,y2, true);
	} else if (game->isLost()) {
		theScreen.drawClipped (panel, 240,0, left+40,top,left+80,bottom, x1,y1,x2,y2, true);
	} else {

		int kpos=3*20;
		for (int kidx=3; kidx>=0; kidx--) {
			if (game->getHasKey(0,kidx)) {
				theScreen.drawClipped (panel, 3*40+kidx*20,0, 
					left+kpos,top+0, left+kpos+20,top+40, 
					x1,y1,x2,y2, true);
				kpos-=20;
			}
		}
	}
}


StatusFrame2::StatusFrame2 (int x, int y, Game* g, Image* p)
: StatusFrame (x, y-statusheight, x+statuswidth, y, g,p)
{
}

void StatusFrame2::update (int currentpage, int x1, int y1, int x2, int y2)
{
	theScreen.drawClipped (panel, 0,0, 
		left+4*20,top+0, left+4*20+40,top+40, 
		x1,y1,x2,y2, true);

	writeNumber (game->getTimeBombsLeft(1), 3, left+4*20+40,top+9, x1,y1,x2,y2);

	if (game->isDone(1)) {
		theScreen.drawClipped (panel, 200,0, left+40,top,left+80,bottom, x1,y1,x2,y2, true);
	} else if (game->isLost()) {
		theScreen.drawClipped (panel, 240,0, left+40,top,left+80,bottom, x1,y1,x2,y2, true);
	} else {

		int kpos=3*20;
		for (int kidx=3; kidx>=0; kidx--) {
			if (game->getHasKey(1,kidx)) {
				theScreen.drawClipped (panel, 3*40+kidx*20,0, 
					left+kpos,top+0, left+kpos+20,top+40, 
					x1,y1,x2,y2, true);
				kpos-=20;
			}
		}
	}
}




VCRFrame::VCRFrame (int x, int y, Game* g, int* recmode, Image* v, int mv)
: Frame (x,y, x+(v->getWidth()/15)*(mv+1), y+(v->getHeight()/2)*g->level->differentPlayersInLevel(), true)
{
	game = g;
	vcr = v;
	recordermode = recmode;
	moves = mv;
	setAlwaysDirty();
}


void VCRFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	int w=vcr->getWidth()/15;
	int h=vcr->getHeight()/2;
	int width=getWidth();
	int height=getHeight();

	// draw recorder mode button
	theScreen.drawClipped (vcr, w*(1+*recordermode),h, 
		left,top+height/2-h/2,left+w,top+height/2+h/2, x1,y1,x2,y2,true);

	// limit drawable to right side (do not draw over recorder mode button)
	clip (x1,y1,x2,y2, left+w,top+0,left+width,top+height);

	int offset = - (game->getMicroCounter()*w) / game->getMicroStepsPerStep();
	int channels=getHeight()/h;
	for (int c=0; c<channels; c++) {
		
		// draw all move-icons for the player
		int pc = game->getPositionCounter();
		int nm = game->thiswalk.numberOfMoves(c);
		for (int pos=pc-(moves/2); pos<=pc+(moves/2)+1; pos++) {
			if (pos<0 || pos>=nm) continue;

			int dx = width/2 + (pos-pc)*w + offset;

			movetype m = game->thiswalk.getMove (c, pos);
			theScreen.drawClipped (vcr, w*m,0, left+dx,top+h*c,left+dx+w,top+h*c+h,  x1,y1,x2,y2, true);
		}

		// draw small rectangle to indicate current play cursor
		theScreen.drawClipped (vcr, 0,h, left+width/2,top+h*c, left+width/2+w,top+h*(c+1), x1,y1,x2,y2,true);
	}
}



ReplayFrame::ReplayFrame (int x, int y, Game* g, Image* v, int blinkspeed)
: Frame (x,y, x+(v->getWidth()/15)*2, y+v->getHeight(), true)
{
	game = g;
	vcr = v;
	speed = blinkspeed*2;
	blink=0;
	setAlwaysDirty();
}

void ReplayFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	int w=vcr->getWidth()/15;

	if ( (blink>=speed) && game->hasReplayWalkthrough() ) {
		theScreen.drawClipped (vcr, 13*w,0, 
			left,top, right,bottom, x1,y1,x2,y2,true);
	}
}

void ReplayFrame::heartbeat()
{
	blink+=getFrequencyDivide();
	if (blink>=2*speed) blink=0;
}


