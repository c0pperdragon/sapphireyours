#include <time.h>

#include "toolbox.h"
#include "framework.h"

bool queryperformancecounter = false;
double performancefrequency;

bool initToolBox()
{
	LARGE_INTEGER freq;
	if (QueryPerformanceFrequency(&freq)) {
		queryperformancecounter = true;
		performancefrequency = (((double) freq.HighPart) * 4294967296.0) + freq.LowPart;
		doLog (1, "Performance counter frequency: %f",performancefrequency);
	} else {
		queryperformancecounter = false;
		doLog (1, "QueryPerformanceCounter not available");
	}

	getTimer();

	srand (time(NULL));
	return true;
}

void closeToolBox()
{
}

void readsubdirectorylist(vector<charstring> &v, const char* path)
{	
	char* n;
	findhandle h;
	char fullpath[500];

	v.clear();
	sprintf (fullpath,"%s*",path);

	n = findfirstfile (&h, fullpath);
	while (n!=NULL) {
		charstring txt;
		txt = charstring(path) + n;
		if (! stringcontains(n,'.')) {
			v.push_back(n);
		} 
		else {
			txt = n;
			if (txt.size()>4 && _stricmp (txt.data()+txt.size()-4, ".zip") == 0) {
				txt.resize(txt.size()-4);
				v.push_back(txt);
			}
		}
		n = findfile (&h);
	}
	stopfindfile (&h);
	sortstringlist (v);
}

void sortstringlist(vector<charstring> & v)
{
	for (int a=0; a<v.size()-1; a++) {
		for (int b=a+1; b<v.size(); b++) {
			if (_stricmp (v[a].data(), v[b].data()) > 0) {
				charstring dummy = v[a];
				v[a] = v[b];
				v[b] = dummy;
			}
		}
	}
}



char *findfirstfile (findhandle* h, const char* path)
{
	static WIN32_FIND_DATA finddata;

	*h = FindFirstFile (path, &finddata);
	if (*h == INVALID_HANDLE_VALUE) return NULL;

	return finddata.cFileName;
}

char *findfile (findhandle* h)
{
	static WIN32_FIND_DATA finddata;

	if (*h == INVALID_HANDLE_VALUE) return NULL;
	if (!FindNextFile (*h, &finddata)) return NULL;
	return finddata.cFileName;	
}

void stopfindfile (findhandle* h)
{
	if (*h != INVALID_HANDLE_VALUE) FindClose (*h);
	*h = INVALID_HANDLE_VALUE;
}

#if 0
int isdirectory (const char* fname)
{
	DWORD a;
	a = GetFileAttributes (fname);
	if (a==0xFFFFFFFF) return 0;
	if (a & FILE_ATTRIBUTE_DIRECTORY) return 1;
	return 0;
}
#endif

bool fileexists (const char* fname)
{
	DWORD a;
	a = GetFileAttributes (fname);
	if (a==0xFFFFFFFF) return false;
	return true;
}

#if 0
bool samefile(const char* f1, const char* f2)
{
	// this implementation is _very_ dirty, but it should work right now
	char b1[501] = "";
	char b2[501] = "";

	GetLongPathName (f1, b1, 500);
	GetLongPathName (f2, b2, 500);

	int l = minimum (strlen(b1),strlen(b2));

	if (l>0 && _stricmp( b1+strlen(b1)-l,b2+strlen(b2)-l )==0) return true;
	return false;
}
#endif

bool stringcontains (const char* s, char c)
{
	while (*s!='\0') {
		if (*s == c) return true;
		s++;
	}
	return false;
}

int minimum(int a, int b)
{
	return a<b ? a : b;
}

int maximum(int a, int b)
{
	return a>b ? a : b;
}

void doDownCase(charstring& str)
{
	for (int i=0; i<str.size(); i++) {
		if (str[i]>='A' && str[i]<='Z') str[i]=(str[i]-'A')+'a';
	}
}

void doCapitalize(charstring& str)
{
	doDownCase(str);
	if (str.size()>0) {
		if (str[0]>='a' && str[1]<='z') {
			str[0] -= ('a'-'A');
		}
	}
}


int randomnumber (int range)
{
	return (rand() % range);
}


// ---------------------- INI-FILE support ----------------------------------

FILE* openinifile (char* filename, char* mode)
{
	char windowsdirectory[MAX_PATH];
	char fname[MAX_PATH+100];

	if (! GetWindowsDirectory(windowsdirectory, MAX_PATH) ) return NULL;

	sprintf (fname, "%s\\%s", windowsdirectory, filename);
	return fopen (fname, mode);
}


// ------------------ timer support ----------------------

static LARGE_INTEGER prevcounter;
static DWORD prevgettime;

double getTimer()
{
	if (queryperformancecounter) {
		LARGE_INTEGER counter;
		if (QueryPerformanceCounter (&counter) ) {
			double diff = ((double) (counter.HighPart - prevcounter.HighPart)) * 4294967296.0
				+ ((double) (counter.LowPart)) - ((double) (prevcounter.LowPart));

			prevcounter.HighPart = counter.HighPart;
			prevcounter.LowPart = counter.LowPart;
			return diff / performancefrequency;
		}
	} 

	DWORD t = timeGetTime();
	double diff = (t - prevgettime) / 1000.0;
	prevgettime = t;
	return diff;
}

// command line support
bool scancmdline (char* line, char* option, int& param)
{
	int llen=strlen(line);
	int olen=strlen(option);
	for (int i=0; i+olen<=llen; i++) {
		if (memcmp (line+i,option,olen)==0) {
			sscanf (line+i+olen, "%d", &param);
			return true;
		}
	}
	return false;
}
