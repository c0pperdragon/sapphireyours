#ifndef _EDITOR_H
#define _EDITOR_H

#include "types.h"
#include "framework.h"
#include "viewbox.h"
#include "viewextension.h"
#include "inputbox.h"
#include "logic.h"
#include "display.h"


bool editLevel(Level* level);



class LevelFrame : public Frame {
	FrameCaller updater;

	Level* level;
	Artwork* artwork;
	Image* background;

	tiletype tiles[maxlevelwidth+4][maxyamyamnum*4+2];
	int levelwidth;
	int levelheight;
	int oldyamyamnum;

	int scrollx;
	int scrolly;

public:
	LevelFrame(Level* lev, int l, int t, int r, int b, Artwork* a, Image* bckgrnd);
	virtual ~LevelFrame();

	void recenter();
	void scroll(int dx, int dy);
	bool screenToLevelCoords(int sx,int sy, int& lx, int& ly);
	bool screenToYamYamCoords(int sx,int sy, int &bnum, int& lx, int& ly);

	virtual void call();	
	virtual void update (int currentpage, int l, int t, int r, int b);
};


#endif
