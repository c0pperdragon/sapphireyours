#define DIRECTINPUT_VERSION 0x0500
#include <dinput.h>

#include "framework.h"
#include "inputbox.h"

// heurisitc constants for input
#define KEYBOARDBUFFERSIZE 100
#define JOYREPEATDELAY 0.3
#define JOYREPEATSPEED 0.08
#define JOYTREASHHOLD  0.5
#define JOYMAX	 1000

#define MOUSEXSPEED 100
#define MOUSEYSPEED  30
#define MOUSEXRECENTER (MOUSEXSPEED/2)
#define MOUSEYRECENTER (MOUSEYSPEED/2)

// global inputbox variables
static LPDIRECTINPUT lpDI = NULL;
static HINSTANCE inputMasterInstance;
static HWND inputMasterWindow;

static bool iskeypressed[256];
static list<Keyboard*> keyboards;
static list<Mouse*> mice;
static list<InternalJoystick*> internaljoysticks;


#define MAXEVENTS 50
static int commandevent[MAXEVENTS];
static int commandparameter[MAXEVENTS];
static int commandwritecursor;
static int commandeventsinbuffer;

static double mousedeltax,mousedeltay;


// ------------------- initialisation and cleanup -------------------

static BOOL CALLBACK enumJoystickCallback(LPCDIDEVICEINSTANCE lpddi, LPVOID pvRef) 
{
	// if we already have found enough joysticks
	if (internaljoysticks.size() >= 2) return DIENUM_CONTINUE;


	LPDIRECTINPUTDEVICE lpTempJoy=NULL;
	LPDIRECTINPUTDEVICE2 lpJoy=NULL;

	if (FAILED (lpDI->CreateDevice(lpddi->guidInstance, &lpTempJoy, NULL))) 
	{
		doLog (1, "could not open joystick");
		return DIENUM_CONTINUE;
	}
	lpTempJoy->QueryInterface(IID_IDirectInputDevice2, (void**) &lpJoy);
	lpTempJoy->Release();
	if (!lpJoy) {
		doLog (1, "could not query for interface on joystick");
		return DIENUM_CONTINUE;
	}

	if (FAILED(lpJoy->SetDataFormat (&c_dfDIJoystick))) {
		doLog (1, "could not set up data format for joystick");
		lpJoy->Release();
		return DIENUM_CONTINUE;
	}
	if (FAILED(lpJoy->SetCooperativeLevel(inputMasterWindow, 
		DISCL_NONEXCLUSIVE|DISCL_FOREGROUND))) {
		doLog (1, "could not set cooperate level");
		lpJoy->Release();
		return DIENUM_CONTINUE;
	}
	DIPROPRANGE dipwd;
	dipwd.diph.dwSize = sizeof(dipwd);
	dipwd.diph.dwHeaderSize = sizeof(dipwd.diph);
	dipwd.diph.dwObj = DIJOFS_X;
	dipwd.diph.dwHow = DIPH_BYOFFSET;
	dipwd.lMin		 = -JOYMAX;
	dipwd.lMax		 = JOYMAX;
	lpJoy->SetProperty (DIPROP_RANGE, &dipwd.diph);
	dipwd.diph.dwSize = sizeof(dipwd);
	dipwd.diph.dwHeaderSize = sizeof(dipwd.diph);
	dipwd.diph.dwObj = DIJOFS_Y;
	dipwd.diph.dwHow = DIPH_BYOFFSET;
	dipwd.lMin		 = -JOYMAX;
	dipwd.lMax		 = JOYMAX;
	lpJoy->SetProperty (DIPROP_RANGE, &dipwd.diph);
	doLog (2, "joystick opened");

	// create object for one joystick
	internaljoysticks.push_back(new InternalJoystick(lpJoy, internaljoysticks.size() ));
	return DIENUM_CONTINUE;
}

bool initInputBox (HINSTANCE inst, HWND hwnd)
{
	HRESULT hr;

	// set up direct input
	inputMasterInstance = inst;
	inputMasterWindow = hwnd;


	if (FAILED (CoCreateInstance(
		CLSID_DirectInput, NULL, CLSCTX_ALL, IID_IDirectInput,
		(LPVOID*) &lpDI) ))
	{
		doLog (1, "could not open DirectInput - working just with the windows API");
		goto nojoystick;
	}
	if (FAILED (lpDI->Initialize(inst,DIRECTINPUT_VERSION))) 
	{
		doLog (1, "could not initialize DirectInput");
		goto nojoystick;
	}
	if (FAILED(hr = lpDI->EnumDevices(DIDEVTYPE_JOYSTICK, 
			enumJoystickCallback, NULL, DIEDFL_ATTACHEDONLY)) ) {
		doLog (1, "joystick callback failed: %8x", hr);
	}
nojoystick:


	keyboards.clear();
	for (int i=0; i<256; i++) {
		iskeypressed[i]=0;
	}
	
	commandwritecursor = 0;
	commandeventsinbuffer = 0;

	mousedeltax=0;
	mousedeltay=0;

	return true;
}

void closeInputBox ()
{
	for (list<InternalJoystick*>::iterator j = internaljoysticks.begin(); 
					j!=internaljoysticks.end(); j++) {
		delete *j;
	}
	internaljoysticks.clear();

	if (lpDI) lpDI->Release();
	lpDI = NULL;
}



// -------------------------- global command queue ------------------------

void addCommandEvent(int event, int parameter)
{
	commandevent[commandwritecursor] = event;
	commandparameter[commandwritecursor] = parameter;
	
	commandwritecursor++;
	if (commandwritecursor>=MAXEVENTS) commandwritecursor=0;

	if (commandeventsinbuffer<MAXEVENTS) commandeventsinbuffer++;
}

bool getCommandEvent(int& cmd, int& parameter)
{
	if (commandeventsinbuffer<=0) return false;

	int readpos = commandwritecursor-commandeventsinbuffer;
	if (readpos<0) readpos+=MAXEVENTS;

	cmd = commandevent[readpos];
	parameter = commandparameter[readpos];

	commandeventsinbuffer--;
	return true;
}

bool getCommandEvent(int& cmd)
{
	int dummyparameter;
	return getCommandEvent(cmd,dummyparameter);
}

void clearCommandEvents()
{
	int dummy;
	while (getCommandEvent(dummy));
}

void clearDeviceEvents()
{
	for (list<Keyboard*>::iterator it = keyboards.begin(); it!=keyboards.end(); it++) {
		(*it) -> clearEvents ();
	}
}

int numberJoystickPresent()
{
	return internaljoysticks.size();
}


// ------------------------ methods of: InternalJoystick --------------------------


InternalJoystick::InternalJoystick(LPDIRECTINPUTDEVICE2 dev,int index)
{
	device = dev;
	prevx=0;
	prevy=0;
	prevb0=false;
	prevb1=false;
	prevb2=false;

	uprepeattime=0;
	downrepeattime=0;
	leftrepeattime=0;
	rightrepeattime=0;

	switch (index) {
	case 0:
	default:
		codeb0		= KEY_JOY0BUTTON0;
		codeb1		= KEY_JOY0BUTTON1;
		codeb2		= KEY_JOY0BUTTON2;
		codeup		= KEY_JOY0UP;
		codedown	= KEY_JOY0DOWN;
		codeleft	= KEY_JOY0LEFT;
		coderight	= KEY_JOY0RIGHT;
		break;
	case 1:
		codeb0		= KEY_JOY1BUTTON0;
		codeb1		= KEY_JOY1BUTTON1;
		codeb2		= KEY_JOY1BUTTON2;
		codeup		= KEY_JOY1UP;
		codedown	= KEY_JOY1DOWN;
		codeleft	= KEY_JOY1LEFT;
		coderight	= KEY_JOY1RIGHT;
		break;
	}
}

InternalJoystick::~InternalJoystick() 
{
	if (device) device->Release();
}


void InternalJoystick::CheckEvent (double timeexpired)
{
	DIJOYSTATE dijs;
	HRESULT hr;

	device->Poll();

again:
	hr=device->GetDeviceState(sizeof(DIJOYSTATE), &dijs);
	if (FAILED(hr)) {
		if ( SUCCEEDED(device->Acquire())) goto again;
	}
	if (!SUCCEEDED(hr)) return;

	double x = (((double) dijs.lX) / JOYMAX);
	double y = (((double) dijs.lY) / JOYMAX);
	bool b0 = ((dijs.rgbButtons[0] & 0x80) != 0);
	bool b1 = ((dijs.rgbButtons[1] & 0x80) != 0);
	bool b2 = ((dijs.rgbButtons[2] & 0x80) != 0);

	if (b0 != prevb0) {
		handleKeyEvent (b0, codeb0);
		if (b0) addCommandEvent(COMMAND_YES,  0);
	}		
	if (b1 != prevb1) {
		handleKeyEvent (b1, codeb1);
		if (b1) addCommandEvent(COMMAND_NO, 0);
	}
	if (b2 != prevb2) {
		handleKeyEvent (b2, codeb2);
		if (b2) addCommandEvent(COMMAND_ESCAPE, 0);
	}

	if (  (x<-JOYTREASHHOLD) ) {
		if ( !(prevx<-JOYTREASHHOLD)) {
			leftrepeattime=0;
		} else {
			leftrepeattime += timeexpired;
			if (leftrepeattime < JOYREPEATDELAY + JOYREPEATSPEED) goto noleft;
			leftrepeattime -= JOYREPEATSPEED;
		}
		handleKeyEvent (true, codeleft);
		addCommandEvent (COMMAND_LEFT,0);
	noleft: 1;
	}
	if ( !(x<-JOYTREASHHOLD) &&  (prevx<-JOYTREASHHOLD)) {
		handleKeyEvent (false, codeleft);
	}

	if (  (x>JOYTREASHHOLD) ) {
		if ( !(prevx>JOYTREASHHOLD)) {
			rightrepeattime=0;
		} else {
			rightrepeattime += timeexpired;
			if (rightrepeattime < JOYREPEATDELAY + JOYREPEATSPEED) goto noright;
			rightrepeattime -= JOYREPEATSPEED;
		}
		handleKeyEvent (true, coderight);
		addCommandEvent (COMMAND_RIGHT,0);
	noright: 1;
	}
	if ( !(x>JOYTREASHHOLD)  &&  (prevx>JOYTREASHHOLD)) {
		handleKeyEvent (false, coderight);
	}

	if (  (y<-JOYTREASHHOLD) ) {
		if ( !(prevy<-JOYTREASHHOLD)) {
			uprepeattime=0;
		} else {
			uprepeattime += timeexpired;
			if (uprepeattime < JOYREPEATDELAY + JOYREPEATSPEED) goto noup;
			uprepeattime -=JOYREPEATSPEED;
		}
		handleKeyEvent (true, codeup);
		addCommandEvent (COMMAND_UP,0);
	noup: 1;
	}
	if ( !(y<-JOYTREASHHOLD) &&  (prevy<-JOYTREASHHOLD)) {
		handleKeyEvent (false, codeup);
	}
	
	if (  (y>JOYTREASHHOLD) ) {
		if ( !(prevy>JOYTREASHHOLD)) {
			downrepeattime=0;
		} else {
			downrepeattime += timeexpired;
			if (downrepeattime < JOYREPEATDELAY + JOYREPEATSPEED) goto nodown;
			downrepeattime -= JOYREPEATSPEED;
		}
		handleKeyEvent (true, codedown);
		addCommandEvent (COMMAND_DOWN,0);
	nodown: 1;
	}
	if ( !(y>JOYTREASHHOLD)  &&  (prevy>JOYTREASHHOLD)) {
		handleKeyEvent (false, codedown);
	}

	prevb0=b0;
	prevb1=b1;
	prevb2=b2;
	prevx=x;
	prevy=y;
}



// ------------------------ methods of: Keyboard --------------------------

Keyboard::Keyboard()
{
	writecursor = 0;
	readcursor = 0;
	eventsinbuffer = 0;
	timestamp = 1;
	for (int i=0; i<256; i++) {
		iskeypressed[i] = ::iskeypressed[i];
		if (iskeypressed[i]) keytimestamp[i] = timestamp++;
	}
	keyboards.push_back (this);
}

Keyboard::~Keyboard()
{
	keyboards.remove (this);
}

void Keyboard::clearEvents()
{
	bool dummy1;
	int dummy2;
	while (getEvent(dummy1,dummy2,false));
}

void Keyboard::addEvent (bool keydown, int scancode)
{
	if (scancode<0 || scancode>255) return;
	if (eventsinbuffer >= buffersize) return;

	down[writecursor] = keydown;
	code[writecursor] = scancode;

	eventsinbuffer++;
	writecursor++;
	if (writecursor>=buffersize) writecursor=0;
}

bool Keyboard::getEvent (bool &keydown, int &scancode, bool getrepeats)
{
	while (eventsinbuffer>0) {
		keydown=down[readcursor];
		scancode=code[readcursor];
	
		eventsinbuffer--;
		readcursor++;
		if (readcursor>=buffersize) readcursor=0;

		if (iskeypressed[scancode] != keydown  || getrepeats) {
			iskeypressed[scancode] = keydown;
			keytimestamp[scancode] = timestamp++;
			return true;
		}

		iskeypressed[scancode] = keydown;
	}
	return false;
}

bool Keyboard::isKeyPressed (int scancode)
{
	if (scancode<0 || scancode>255) return false;
	return iskeypressed[scancode];
}

unsigned long int Keyboard::keyTimeStamp (int scancode)
{
	if (scancode<0 || scancode>255) return 0;
	return keytimestamp[scancode];
}

// ------------------------ methods of: Mouse ----------------------------

Mouse::Mouse()
{
	mousex=0;
	mousey=0;
	left=0;
	top=0;
	right=10000;
	bottom=10000;
	borderpushx=0;
	borderpushy=0;
	for (int b=0; b<maxbuttons; b++) {
		buttondown[b] = false;
		buttonnew[b] = false;
	}

	mice.push_back(this);
}

Mouse::~Mouse()
{
	mice.remove(this);
}

void Mouse::addButtonEvent(bool down, int button)
{
	if (button<0 || button>=maxbuttons) return;

	if (down && !buttondown[button]) buttonnew[button] = true;
	if (!down) buttonnew[button] = false;

	buttondown[button] = down;
}

void Mouse::addMoveEvent(int dx, int dy)
{
	mousex+=dx;
	mousey+=dy;
	if (mousex>=right)  { borderpushx+=((right-1)-mousex); mousex=right-1; }
	if (mousex<left)    { borderpushx+=(left-mousex); mousex=left; }
	if (mousey>=bottom) { borderpushy+=((bottom-1)-mousey); mousey=bottom-1; }
	if (mousey<top)     { borderpushy+=(top-mousey); mousey=top; }
}

void Mouse::resetCoordinates(int x, int y, int l, int t, int r, int b)
{
	mousex=x;
	mousey=y;
	left=l;
	right=r;
	top=t;
	bottom=b;
}
void Mouse::resetBorderPush()
{
	borderpushx=0;
	borderpushy=0;
}

bool Mouse::isButtonDown(int button)
{
	if (button<0 || button>=maxbuttons) return false;
	return (buttondown[button]);
}

bool Mouse::isButtonNew(int button)
{
	if (button<0 || button>=maxbuttons) return false;
	bool n = buttonnew[button];
	buttonnew[button] = false;
	return n;
}

void Mouse::forgetButton(int button)
{
	buttondown[button]=false;
	buttonnew[button]=false;
}

// ---------------------- methods to dispatch input ---------------------------

void handleLetterEvent (int letter)
{
	addCommandEvent(COMMAND_LETTER, letter);
}

void handleKeyEvent (bool keydown, int scancode)
{
	// generate generic command codes from key events
	if (keydown) {
		switch (scancode) {
		case VK_ESCAPE:		addCommandEvent(COMMAND_ESCAPE,  0); break;
		case VK_RETURN:		addCommandEvent(COMMAND_ENTERKEY, 0); 
			                addCommandEvent(COMMAND_YES, 0); break;
		case VK_BACK:		addCommandEvent(COMMAND_BACKSPACE,0);
							addCommandEvent(COMMAND_NO, 0); break;
		case VK_SPACE:		addCommandEvent(COMMAND_CONTINUE, 0); break;
		case VK_UP:			addCommandEvent(COMMAND_UP, 0); break;
		case VK_DOWN:		addCommandEvent(COMMAND_DOWN, 0); break;
		case VK_LEFT:		addCommandEvent(COMMAND_LEFT, 0); break;
		case VK_RIGHT:		addCommandEvent(COMMAND_RIGHT, 0); break;
		case VK_PRIOR:		addCommandEvent(COMMAND_PRIOR, 0); break;
		case VK_NEXT:		addCommandEvent(COMMAND_NEXT, 0); break;
		case VK_HOME:		addCommandEvent(COMMAND_HOME, 0); break;
		case VK_END:		addCommandEvent(COMMAND_END, 0); break;
		case VK_DELETE:		addCommandEvent(COMMAND_DELETE, 0); break;
		case VK_F1:			addCommandEvent(iskeypressed[VK_F3] ? COMMAND_F3F1 : COMMAND_F1, 0); break;
		case VK_F2:			addCommandEvent(iskeypressed[VK_F3] ? COMMAND_F3F2 : COMMAND_F2, 0); break;
		case VK_F3:			addCommandEvent(iskeypressed[VK_F3] ? COMMAND_F3F3 : COMMAND_F3, 0); break;
		case VK_F4:			addCommandEvent(iskeypressed[VK_F3] ? COMMAND_F3F4 : COMMAND_F4, 0); break;
		case VK_F5:			addCommandEvent(iskeypressed[VK_F3] ? COMMAND_F3F5 : COMMAND_F5, 0); break;
		case VK_F6:			addCommandEvent(COMMAND_F6, 0); break;
		case VK_F7:			addCommandEvent(COMMAND_F7, 0); break;
		case VK_F8:			addCommandEvent(COMMAND_F8, 0); break;
		case VK_F9:			addCommandEvent(COMMAND_F9, 0); break;
		case VK_F10:		addCommandEvent(COMMAND_F10, 0); break;
		case VK_F11:		addCommandEvent(COMMAND_F11, 0); break;
		case VK_F12:		addCommandEvent(COMMAND_F12, 0); break;
		}
	}

	// really process keyboard input and joystick actions
	if (scancode<0 || scancode>255) return;
	iskeypressed[scancode] = keydown;
	
	for (list<Keyboard*>::iterator it = keyboards.begin(); it!=keyboards.end(); it++) {
		(*it) -> addEvent (keydown, scancode);
	}
}

void handleMouseButtonEvent(bool down, int button)
{
	if (down) {
		switch (button) {
		case 0:
			addCommandEvent(COMMAND_YES,0);
			break;
		case 1:
			addCommandEvent(COMMAND_NO,0);
			break;
		case 2:
			addCommandEvent(COMMAND_ESCAPE,0);
			break;
		}
	}


	for (list<Mouse*>::iterator it=mice.begin(); it!=mice.end(); it++) {
		(*it)->addButtonEvent(down,button);
	}
}

void handleMouseMove(int dx, int dy)
{
	mousedeltax += dx;
	mousedeltay += dy;

	while (mousedeltax>=MOUSEXSPEED) { 
		mousedeltax-=MOUSEXSPEED; 
		addCommandEvent(COMMAND_RIGHT,0);
	}
	while (mousedeltax<=-MOUSEXSPEED) { 
		mousedeltax+=MOUSEXSPEED; 
		addCommandEvent(COMMAND_LEFT,0);
	}
	while (mousedeltay>=MOUSEYSPEED) { 
		mousedeltay-=MOUSEYSPEED; 
		addCommandEvent(COMMAND_DOWN,0);
	}
	while (mousedeltay<=-MOUSEYSPEED) { 
		mousedeltay+=MOUSEYSPEED; 
		addCommandEvent(COMMAND_UP,0);
	}


	for (list<Mouse*>::iterator it=mice.begin(); it!=mice.end(); it++) {
		(*it)->addMoveEvent(dx,dy);
	}
}

void pollInput (double timeexpired)
{
	for (list<InternalJoystick*>::iterator j = internaljoysticks.begin();
				j!=internaljoysticks.end(); j++) {
		(*j)->CheckEvent(timeexpired);
	}

	if (mousedeltax>0) mousedeltax-=timeexpired*MOUSEXRECENTER;
	else               mousedeltax+=timeexpired*MOUSEXRECENTER;
	if (mousedeltay>0) mousedeltay-=timeexpired*MOUSEYRECENTER;
	else               mousedeltay+=timeexpired*MOUSEYRECENTER;
}
