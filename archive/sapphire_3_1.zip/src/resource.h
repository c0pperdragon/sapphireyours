//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by sapphire.rc
//
#define IDENTERCODE                     3
#define IDI_MYAPPLICATION               102
#define IDD_TRIALCHECK                  102
#define IDD_ENTERCODE                   103
#define IDC_HAND                        105
#define IDC_DAY                         1000
#define IDC_CODE                        1000
#define IDC_HOMEPAGE                    1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
