#ifndef _TYPES_H
#define _TYPES_H

#include <string>
#include <list>
#include <vector>

using namespace std;
typedef basic_string<char> charstring;
typedef vector<charstring> charstringvector;

#endif
