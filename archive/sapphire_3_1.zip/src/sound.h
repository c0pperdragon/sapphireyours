#include "viewbox.h"
#include "soundbox.h"
#include "logic.h"


void releaseSoundCache();


class SoundSet {
	friend class SoundPlayer;

	Sound* sound[snd_end];
public:
	SoundSet ();
	virtual ~SoundSet ();

	void load (charstring &name);
	void unload();
	bool loadOrReuseSound (charstring& fname, int index);
};


class SoundPlayer {
	Game* game;
	SoundSet* soundset; // owned by this object itself

public:
	SoundPlayer (Game* g, charstring& defaultsound);
	virtual ~SoundPlayer();

	void run();
};
