
//#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>

#include "framework.h"
#include "viewbox.h"
#include "inputbox.h"
#include "musicbox.h"
#include "soundbox.h"
#include "toolbox.h"
#include "dataread.h"
#include "resource.h"


static HWND theWindow = NULL;
static HINSTANCE theInstance = NULL;
static bool bActive = true;

FILE* logfile = NULL;
int loglevel = 1;

static bool forcetrialmode = false;
static char errortext[300] = "";

BOOL CALLBACK checktrialdialog(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
void registerHyperLinkClass(HINSTANCE hInstance);

#define GAMENAME  "SapphireYours"
#define GAMETITLE "Sapphire Yours"

static int startmousex=0;
static int startmousey=0;


void doLog (int level, char* format, ...)
{
	if (level > loglevel) return;
	
	char text[300];
	va_list marker;
	va_start (marker, format);
	vsprintf (text, format, marker);

	if (level==0 && strlen(errortext)==0) strcpy(errortext,text);
	
	if (!logfile) return;
	fprintf (logfile, "LOG%d: (%08x) %s\n", level, time(NULL), text);
	fflush (logfile);
}

bool anyLevel0Error()
{
	return errortext[0] != '\0';
}

static void printloggederror()
{
	char text[1000];
	sprintf (text, "%s\n\n\"%s\"\n\n%s\n%s\n%s",
		"A problem occured while running the program Sapphire Yours:",
		errortext,
		"Try to reboot your computer and start the program again.",
		"If this does not help, the game will probably not run on your machine.",
		"Sorry. " );

	doLog (1, "Displaying error message: [%s]", text);
	MessageBox(NULL, text, "Error condition", MB_OK | MB_ICONHAND);
	doLog (1, "Finished displaying message");
}

static void setmousestartpos()
{
	POINT point;
	GetCursorPos(&point);

	startmousex = point.x;
	startmousey = point.y;
	if (startmousex<50) startmousex=50;
	if (startmousey<50) startmousey=50;
	if (startmousex>600) startmousex=600;
	if (startmousey>400) startmousey=400;

	SetCursorPos (startmousex,startmousey);
}

static long FAR PASCAL WindowProc( HWND hWnd, UINT message, 
                            WPARAM wParam, LPARAM lParam )
{
    switch ( message )
    {
		case WM_CREATE:
			setmousestartpos();
			break;
	
		case WM_ACTIVATEAPP:
			// after we again gained control over the machine, just
			// reload and reactivate everything 
			// (if anything fails, refuse to reactivate)
			if (wParam && !bActive) {
				bActive = true;

				if (!reloadViewBox()) {
					bActive = false;
					break;
				}
				if (!reloadSoundBox()) {
					bActive = false;
					break;
				}

			} else {
	            bActive = (wParam != FALSE);
			}

			setmousestartpos();
            break;

        case WM_SETCURSOR:
            SetCursor( NULL );    // Turn off the mouse cursor.
            return TRUE;
 
        case WM_KEYDOWN:
			if (wParam==VK_SCROLL ) {
				char fname[50];
				sprintf (fname, "c:\\temp\\sy%08x.bmp", time(NULL));
				printScreen(charstring(fname));
			} else {
				handleKeyEvent (true, wParam);
			}
			return TRUE;

        case WM_KEYUP:
			if (wParam!=VK_SCROLL) {
				handleKeyEvent (false, wParam);
			}
			return TRUE;

		case WM_CHAR:
			handleLetterEvent(wParam);
			return TRUE;

		case WM_LBUTTONDOWN:
			handleMouseButtonEvent(true,0);
			return TRUE;
		case WM_LBUTTONUP:
			handleMouseButtonEvent(false,0);
			return TRUE;
		case WM_MBUTTONDOWN:
			handleMouseButtonEvent(true,1);
			return TRUE;
		case WM_MBUTTONUP:
			handleMouseButtonEvent(false,1);
			return TRUE;
		case WM_RBUTTONDOWN:
			handleMouseButtonEvent(true,2);
			return TRUE;
		case WM_RBUTTONUP:
			handleMouseButtonEvent(false,2);
			return TRUE;

		case WM_MOUSEMOVE:
			{
				POINT point;
				GetCursorPos(&point);
				if (point.x!=startmousex || point.y!=startmousey) {
					handleMouseMove( ((int)point.x)-startmousex,((int)point.y)-startmousey);
					SetCursorPos(startmousex,startmousey);
				}
			}
			return TRUE;

		case MM_MCINOTIFY:
			if (wParam==MCI_NOTIFY_SUCCESSFUL) {
				restartMIDI();
			}
			return 0;
			break;
        }
    return DefWindowProc( hWnd, message, wParam, lParam );
} /* WindowProc */




void processInput(double timeexpired)
{
	pollInput (timeexpired);

	MSG         msg;

	while ( PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) ) {
		if ( GetMessage( &msg, NULL, 0, 0 ) ) {
			TranslateMessage( &msg );
		    DispatchMessage( &msg );
		}

		// if someone has deactivated the game, just wait
		// until we get some activation message
		while (!bActive) {
			if ( GetMessage( &msg, NULL, 0, 0 ) ) {
				TranslateMessage( &msg );
			    DispatchMessage( &msg );
			}
		}
	}
}


static void setBaseDirectory()
{
	int i;
	char path[500];
	if (! GetModuleFileName(NULL, path, 500)) return;

	// cut off the trailing executable name 
	for (i=strlen(path)-1; i>0; i--) {
		if (path[i]=='\\' || path[i]=='/') {
			path[i] = '\0';
			break;
		}
	}

	// set the current working directory
	SetCurrentDirectory (path);
}


static void registerWindowClass(HINSTANCE hInstance)
{
    WNDCLASS            wc;
     // Set up and register window class
    wc.style = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc = WindowProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon( hInstance, MAKEINTRESOURCE(IDI_MYAPPLICATION) );
    wc.hCursor = LoadCursor( NULL, IDC_ARROW );
    wc.hbrBackground = NULL;
    wc.lpszMenuName = GAMENAME;
    wc.lpszClassName = GAMENAME;
    RegisterClass( &wc );
}


static bool createWindow( HINSTANCE hInstance)
{
	DWORD freq=0;

    // Create a fullscreen window
    theWindow = CreateWindowEx(
        WS_EX_TOPMOST,
        GAMENAME,
        GAMETITLE,
        WS_POPUP,
        0, 0,
        GetSystemMetrics( SM_CXSCREEN ),
        GetSystemMetrics( SM_CYSCREEN ),
        NULL,
        NULL,
        hInstance,
        NULL );

    if( !theWindow ) return false;
	bActive = true;

	ShowWindow(theWindow,SW_SHOWNORMAL);
//	UpdateWindow (theWindow);

	return true;
}

static void closeWindow()
{
	if (!theWindow) return;
	bActive = true;

	DestroyWindow (theWindow);
	theWindow = NULL;
}


int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPSTR lpCmdLine, int nCmdShow)
{
	theInstance = hInstance;

	// find the path where the executeable itself is stored
	setBaseDirectory();

	// open logfile
	scancmdline(lpCmdLine, "-log", loglevel);
	logfile = fopen ("sapphire.log", "w");

	// check for forced trial parameter
	int dummy;
	if (scancmdline (lpCmdLine, "-trial", dummy)) forcetrialmode = true;

	// register necessary window classes
	registerWindowClass(hInstance);
	registerHyperLinkClass(hInstance);

	// manualle start up COM
	CoInitialize(NULL);

	if (!initToolBox()) goto cleanup;

	if (!createWindow(hInstance)) goto cleanup;
	if (!initViewBox(theWindow)) goto cleanup;
	if (!initSoundBox(theWindow)) goto cleanup;
	if (!initMusicBox(theWindow)) goto cleanup;
	if (!initInputBox(hInstance,theWindow)) goto cleanup;

	processInput(0);

	if (!GameMain(false, lpCmdLine)) {
		// this means, we have no registered version

		closeMusicBox();
		closeSoundBox();
		closeViewBox();
		closeInputBox();
		closeWindow();

		while (registrationDialog()) {

			if (!createWindow(hInstance)) goto cleanup;
			if (!initViewBox(theWindow)) goto cleanup;
			if (!initSoundBox(theWindow)) goto cleanup;
			if (!initMusicBox(theWindow)) goto cleanup;
			if (!initInputBox(hInstance,theWindow)) goto cleanup;

			processInput(0);

			if (GameMain(true, lpCmdLine)) goto cleanup;

			closeInputBox();
			closeMusicBox();
			closeSoundBox();
			closeViewBox();
			closeWindow();
		}
	}

cleanup:
	// destroy everything 
	closeInputBox();
	closeMusicBox();
	closeSoundBox();
	closeViewBox();
	closeWindow();

	closeToolBox();
	closeZipFiles();
	

	CoUninitialize();

	if (anyLevel0Error()) printloggederror();
	if (logfile) fclose (logfile); 

	return TRUE;
} /* WinMain */



// ----------------------- registration support functions -----------------------

VOID CALLBACK timerproc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime);

#define SYLICENCEKEY      "Licenses\\CB4C97D0-F027-11d2-9828-EFB609035EA2"
#define TRIALPERIOD       (15*60*60)
#define SYKEYWORD		  "Sapphire"

static bool registeredversion=false;
static long int countdown = -1;
static time_t countdownreadtime;


bool isRegistered()
{
	return registeredversion && !forcetrialmode;
}

static bool isCorrectCode(char* txt)
{
	if (strlen(txt)!=16) return false;

	for (int i=0; i<8; i++) {
		int sum = ((int) (txt[i])) + ((int) (txt[8+i])) + ((int) (SYKEYWORD[i]));
		if (sum % 10 != 0) return false;

		if (txt[i]<'A' || txt[i]>'Z') return false;
	}
	return true;
}


// check, if the game is already registered

bool checkIfRegistered()
{
	HKEY lkey;
	DWORD type;
	DWORD disposition;
	char value[500];
	value[0]='\0';
	DWORD valuesize=500;

	if ( RegCreateKeyEx (HKEY_CLASSES_ROOT, SYLICENCEKEY, 0, "text", 
		REG_OPTION_NON_VOLATILE,
		KEY_QUERY_VALUE, 
		NULL, &lkey, &disposition)	!= ERROR_SUCCESS) {
		return false;
	}

	// read out the value
	if (RegQueryValueEx (lkey, NULL, NULL, &type, (unsigned char*) value, &valuesize) 
		!= ERROR_SUCCESS) value[0] = '\0';

	// check if this is a registered version
	if (isCorrectCode (value)) {
		RegCloseKey (lkey);
		registeredversion = true;
		return true;
	}
	RegCloseKey (lkey);
	return false;
}


// check the trial period of the game (must only called, if _not_ registered)

long int checkTrialPeriod()
{
	HKEY lkey;
	DWORD type;
	DWORD disposition;
	char value[500];
	DWORD valuesize=500;
	long int trialleft = 0;

	if (registeredversion) return 0;

	// MUST be able to create the registry key where to store the
	// info. Otherwise totally refuse to operate
	if ( RegCreateKeyEx (HKEY_CLASSES_ROOT, SYLICENCEKEY, 0, "text", 
		REG_OPTION_NON_VOLATILE,
		KEY_SET_VALUE | KEY_QUERY_VALUE, 
		NULL, &lkey, &disposition)	!= ERROR_SUCCESS) {
		trialleft=0;
		return 0;
	}

	// read out the value
	if (RegQueryValueEx (lkey, NULL, NULL, &type, (unsigned char*) value, &valuesize) 
		!= ERROR_SUCCESS) value[0] = '\0';

	// if we did already read the time value, just do an update 
	if (countdown > 0) {
		trialleft = countdown - (time(NULL) - countdownreadtime);
		if (trialleft < 0) trialleft = 0;

		sprintf (value, "%lx", trialleft);
		RegSetValueEx (lkey, NULL, 0, REG_SZ, (unsigned char*) value, strlen(value)+1); 
		RegCloseKey (lkey);
		return trialleft;
	}

	// read out the countdown value 
	countdown = -1;
	countdownreadtime = time (NULL);
	if (strlen (value) > 10) {  // if no number is here, the wrong code was entered
		countdown = 0;
	} else if (strlen (value) > 0) {
		sscanf (value, "%lx", &countdown);
	}

	// if no countdown has been installed, do it now
	if (countdown == -1 || countdown > TRIALPERIOD) {
		countdown = TRIALPERIOD;
		sprintf (value, "%8lx", countdown);
		RegSetValueEx (lkey, NULL, 0, REG_SZ, (unsigned char*) value, strlen(value)+1); 
	}

	// close registry key after usage
	RegCloseKey (lkey);

	trialleft = countdown - (time(NULL) - countdownreadtime);
	if (trialleft < 0) trialleft = 0;
	return trialleft;
}


static void setupRegistrationCode(char* value)
{
	HKEY lkey;
	DWORD disposition;

	if ( RegCreateKeyEx (HKEY_CLASSES_ROOT, SYLICENCEKEY, 0, "text", 
		REG_OPTION_NON_VOLATILE,
		KEY_SET_VALUE, 
		NULL, &lkey, &disposition)	!= ERROR_SUCCESS) {
		return;
	}

	RegSetValueEx (lkey, NULL, 0, REG_SZ, (unsigned char*) value, strlen(value)+1); 
	RegCloseKey (lkey);

	countdown = -1;
}



// --------- dialog box for entering the registration key ------

static bool isCorrectCodeSimple(char* txt)
{
	if (strlen(txt)!=16) return false;

	for (int i=0; i<8; i++) {
		int sum = ((int) (txt[i])) + ((int) (txt[8+i])) + ((int) (SYKEYWORD[i]));
		if (sum % 10 != 0) return false;
	}
	return true;
}


BOOL CALLBACK entercodedialog(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	char txt[201];

	switch (uMsg) {
	case WM_INITDIALOG:
		return TRUE;
	
	case WM_COMMAND:
		switch (wParam) {
		case IDOK:
			// get the key-value and if correct, set up the registration info
			GetWindowText( GetDlgItem (hwndDlg, IDC_DAY), txt, 200);
			txt[199] = '\0';
			if (isCorrectCodeSimple(txt)) {
				setupRegistrationCode(txt);
				EndDialog (hwndDlg,1);
			} else {
				MessageBox (hwndDlg,
					"Sorry, this is not a valid\nregistration code for\nSapphire Yours", 
					"Invalid code", MB_OK | MB_ICONHAND );
			}
			return TRUE;

		case IDCANCEL:
			EndDialog (hwndDlg,0);
			return TRUE;
		}
	}
	return FALSE;
}


// ------ dialog box for displaying the countdown -------------

VOID CALLBACK timerproc(HWND hwnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	long int timeleft = checkTrialPeriod();
	// as long as no valid registration is here, write out the countdown
	char txt[30];
	sprintf (txt, "%2d:%02d:%02d", (timeleft/60)/60,(timeleft/60)%60 ,timeleft%60);

	SetWindowText (GetDlgItem (hwnd, IDC_DAY), txt);
	EnableWindow (GetDlgItem (hwnd, IDOK), timeleft>0);
	
	SetTimer (hwnd, 0, 500, (TIMERPROC) timerproc);
}


LONG GetRegKey(HKEY key, char* subkey, char* retdata)
{
	HKEY hkey;
	LONG retval = RegOpenKeyEx(key,subkey,0,KEY_QUERY_VALUE, &hkey);
	if (retval==ERROR_SUCCESS) {
		long datasize = MAX_PATH;
		char data[MAX_PATH];
		RegQueryValue(hkey,NULL,data,&datasize);
		lstrcpy(retdata,data);
		RegCloseKey(hkey);
	}
	return retval;
}

void FollowHyperLink(char* url)
{
	char key[MAX_PATH+MAX_PATH];

	// first try ShellExecute()
	HINSTANCE result = ShellExecute(NULL,("open"),
		url, NULL,NULL, SW_SHOW);
	if ( ((UINT)result)>HINSTANCE_ERROR) return;

	// if this fails, get the .htm regkey and lookup the prog.
	if (GetRegKey (HKEY_CLASSES_ROOT, ".htm", key)==ERROR_SUCCESS) {
		strcat(key,"\\shell\\open\\command");
		if (GetRegKey (HKEY_CLASSES_ROOT,key,key)==ERROR_SUCCESS) {
			char* pos;
			pos = strstr(key,"\"%1\"");
			if (pos==NULL) {
				pos = strstr(key,"%1");
				if (pos==NULL) pos = key+lstrlen(key-1);
				else *pos = '\0';

				lstrcat (pos, " ");
				lstrcat (pos, url);
				WinExec(key,SW_SHOW);
			}
		}
	}
}


LRESULT CALLBACK HyperLinkProc (HWND hwnd, UINT message,
					WPARAM wParam, LPARAM lParam)
{
	char szText[40];
	HDC hdc;
	PAINTSTRUCT ps;
	RECT rect;
	HPEN hPen;

	switch (message) 
	{
	case WM_PAINT:
		GetClientRect(hwnd,&rect);
		GetWindowText (hwnd, szText, sizeof(szText));

		hdc = BeginPaint(hwnd,&ps);
		
		SelectObject (hdc, GetStockObject(DEFAULT_GUI_FONT));
		SetBkMode (hdc, TRANSPARENT);
		SetTextColor (hdc, PALETTERGB(0,0,200));
		DrawText (hdc, szText, -1, &rect,
			DT_SINGLELINE | DT_CENTER  | DT_BOTTOM);
		
		hPen = CreatePen(PS_SOLID,0,PALETTERGB(0,0,200));
		SelectObject (hdc, hPen);
		MoveToEx (hdc,rect.left,rect.bottom-1, NULL);
		LineTo (hdc, rect.right,rect.bottom-1);
		DeleteObject (hPen);

		EndPaint(hwnd, &ps);
		return 0;

	case WM_LBUTTONDOWN:
		SendMessage(GetParent(hwnd),WM_COMMAND,
			GetWindowLong(hwnd,GWL_ID),(LPARAM)hwnd);
		return 0;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}

void registerHyperLinkClass(HINSTANCE hInstance)
{
	WNDCLASS wndclass;
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = HyperLinkProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = NULL;
	wndclass.hCursor = LoadCursor(hInstance,MAKEINTRESOURCE(IDC_HAND));
	wndclass.hbrBackground = (HBRUSH) (COLOR_BTNFACE+1);
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = "hyperlink";
	RegisterClass (&wndclass);
}

BOOL CALLBACK checktrialdialog(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg) {
	case WM_INITDIALOG:
		timerproc (hwndDlg, 0,0,0);
		return TRUE;
	
	case WM_COMMAND:
		switch (wParam) {
		case IDOK:
			EndDialog (hwndDlg,1);
			return TRUE;

		case IDCANCEL:
			EndDialog (hwndDlg,0);
			return TRUE;

		case IDENTERCODE:
			if ( DialogBox(theInstance, MAKEINTRESOURCE (IDD_ENTERCODE), hwndDlg, 
				entercodedialog) ) {
				EndDialog (hwndDlg,1);
			}
			return TRUE;

		case IDC_HOMEPAGE:
			FollowHyperLink("http://members.aon.at/sapphire");
			return TRUE;
		}
	}
	return FALSE;
}


bool registrationDialog()
{
	return (DialogBox(theInstance, MAKEINTRESOURCE (IDD_TRIALCHECK), NULL, 
			checktrialdialog) != 0);
}


// ------ support for game processing and the selfrunner objects --------------


static list<SelfRunner*> allselfrunners;

SelfRunner::SelfRunner()
{
	doLog (2, "installing selfrunner");
	allselfrunners.push_back (this);
}

SelfRunner::~SelfRunner()
{
	doLog (2, "un-installing selfrunner");
	allselfrunners.remove (this);
}


void gameTick()
{
	// perform everything for the self-runners
	for (list<SelfRunner*>::iterator it=allselfrunners.begin();
						 			 it!=allselfrunners.end(); it++) {
			(*it)->run();
	}

	// do the whole drawing stuff
	double ticktime = drawFrames();

	// after normal screen drawing, do input processing
	processInput(ticktime);
}


