#ifndef _GAMEMAIN_H
#define _GAMEMAIN_H

#include "types.h"

#define ACTION_OK	  (-1)
#define ACTION_CANCEL (-2)

extern int color_neutral;
extern int color_menu;
extern int color_playernum;
extern int color_black;
extern int color_white;
extern int color_grey;
extern int color_darkgrey;
extern int color_green;
extern int color_red;
#define DIFFICULTIES 11
extern int color_diff[DIFFICULTIES];

extern int maxxresolution;
extern int maxyresolution;
extern charstring usedtitlemusic;
extern charstring usedbackgroundmusic;
extern charstring defaultartwork;
extern charstring defaultsoundwork;
extern int defaultshrinkfactor;
extern int defaultfont;


class PerformanceMonitor : public Frame
{
	charstring str;
	double smoothcpu;
	int nthmessure;

	FrameCaller frontpopper;

public:
	PerformanceMonitor (int x, int y);
	virtual ~PerformanceMonitor();

	virtual void call();
	virtual void update (int currentpage, int x1, int y1, int x2, int y2);
};


class MenuItem {
	friend class MainMenuFrame;

	charstring name;
	int color;
	int itemid;
};

class Category {
	friend class MainMenuFrame;

	charstring name;
	int color;
	int actionid;
	vector<MenuItem*> items;

	Category() { color = 1; };
	~Category() {
		for (int i=0;i<items.size();i++) delete items[i];
	}
};


class MainMenuFrame : public BufferedTransparentFrame 
{
private:
	vector<Category*> categories;
	charstring txt;

	int currentcatindex;
	int currentitemindex;

	int linespercolumn;
	int columnsperscreen;

public:
	enum { categoryspacing=2};
	enum { levelspacing=2};
	enum { columnwidth=25 };
	enum { catwidth=15 };

	MainMenuFrame(int l, int t, int r, int b);
	virtual ~MainMenuFrame();

	void addCategory (int index, const charstring& name, int color, int actionid);
	charstring* getCategoryName(int index);
	void addMenuItem (int catindex, int itemid, const charstring& name, int color);
	void selectItem (int itemid);
	void selectCategory (int catindex);

	bool processSelection(int &selecteditem);

	int getFirstColumnOnScreen();
	int columnsInCategory(Category* c);

	void subtractFreeArea (RectangleList& usedarea);
	void updateBuffer (int x1, int y1, int x2, int y2);
	void setItemDirty(int first, int iidx);
};


class LevelHeader {
public:
	charstring filename;
	mlangstring longname;
	mlangstringlist infolines;
	charstring authorname;
	charstring firstfinisher;
	charstring nextlevel;

	int difficulty;
	int category;
	int playersinlevel;

	vector<mlangstring> walkthroughnames;
	vector<int> walkthroughflags;

	bool isknown;
	bool isfinished;
	bool demoimpossible;

	LevelHeader();
	Level* load();
	void extractLevel (Level* l);
	void updateFromFile();

	bool hasAllowedDemos();
	bool hasBackgroundDemo(int& idx);
	bool hasSuspendGame();
	bool hasImpossibleDemo();
	bool mayViewDemo (int idx);
	bool mayViewBackgroundDemo (int idx);
	void getLevelInfo(vector<charstring> &lines);
	int getColor();

	void setKnown();
	void setFinished();
};

typedef LevelHeader* LevelHeaderPtr;



class DialogFrame : public Frame {
	enum { borderwidth = 2 };
	enum { hborderpad = 4 };
	enum { vborderpad = 3 };
	class DialogLine {
	public:
		enum { textline=0, actionline, selectionline, editline } type;
		charstring text;
		int color;

		int id; // only for ActionLine
		int* selectvar; // only for SelectionLine
		vector<charstring> selectiontexts; // only for SelectionLine

		charstring* editvar;
		int editlen;
	};

	int midx;
	int midy;

	charstring title;
	int color;
	int backgroundcolor;

	vector<DialogLine> lines;
	int maxwidth;
	int selectionline;
	int editcolumn;
	int maxlines;
	bool enterkeywashit;
	bool backspacewashit;

	void computePosition();
	DialogLine* addLine ();

public:
	DialogFrame (int _midx, int _midy, const charstring& _title, int _color, int _backgroundcolor);
	virtual ~DialogFrame();

	void addLevelInfo (LevelHeader* h);
	void addBlankLine ();
	void addTextLine (const charstring& txt, int color);
	void addTextLine (char* txt);
	void addActionLine (const charstring& txt, int color, int id);
	void addSelectionLine (const charstring& prompt, int color, int* selectvar);
	void addSelectionOption (const charstring& option);
	void addEditLine (const charstring& prompt, int color, int id, charstring* editvar, int editlen);
	void setMaxLines (int l) { maxlines = l; };

	virtual void update (int currentpage, int x1, int y1, int x2, int y2);

	int doModal(int nowselected=-1, int nowselectedcolumn=9999, bool returnbackspace=false);
	bool getEnterKeyPosition(int &line, int &column);
	bool getBackspacePosition(int &line, int &column);
};



class TextFrame : public Frame {
protected:
	Surface* surface;

	int color;
	charstring text;

	virtual void update (int currentpage, int x1, int y1, int x2, int y2);

public:
	TextFrame (int x, int y, charstring& _text, int _color);
	virtual ~TextFrame();
};


class ScrollTextFrame : public Frame {
protected:
	Surface* buffer;

	int lowestline;

public:
	ScrollTextFrame (int l, int t, int r, int b);
	~ScrollTextFrame();

	void addLine (charstring& line, int pixelrow, int color);
	virtual void update (int currentpage, int x1, int y1, int x2, int y2);
};


class TutorManager : public SelfRunner {
	int numplayer;

	Frame* frameabove;

	Level* level;
	Game* game;
	Artwork* a;
	GameFrame* gf;
	StatusFrame1* sf;
	StatusFrame2* sf2;
	TextFrame* tf;

	int lastposition;
	int gamecounter;
public:
	TutorManager(int _numplayer, Frame *above);
	~TutorManager();
	void closeContent();
	virtual void run();
	void restart();
};


class BackgroundContainer {
	Frame* frame;
public:

	BackgroundContainer (int diff);
	~BackgroundContainer ();
};



int mainMenu(LevelHeaderPtr& selectedlevel, int& walkthroughindex, int numplayer);
void starttitlemusic();
void selectmusic (char* prompt, charstring& music);
bool settings(TutorManager* tm, int& returnvalue);
void about();
bool controlsettings(TutorManager* tm, int& returnvalue);
void playGame (LevelHeaderPtr& selectedlevel, bool continuesuspended);
void playDemo (LevelHeader* selectedlevel, int walkthroughindex);
bool demoNameDialog (charstring& name, int color);
LevelHeader* startEditor(LevelHeader* lh);

LevelHeader* addLevel(const char* t, LevelHeader* notload);
void loadLevelDirectory (char* path, LevelHeader* notload);
void sortLevels();
void deleteLevelList();
LevelHeader* findLevelHeader (const char* name);
int findLevelHeaderIndex (LevelHeader* h);
LevelHeader* findNextLevelHeader (LevelHeader* lh);
void checkDemos ();
int computeRanking(int numplayer);

void loadFundamentalConfigurationParameter();
void loadLevelKnownInfo();
void saveConfigurationParameter();

int computeStepsPerTurn();
double computeTimePerStep();

void startLevelMusic(Level* l);
void toggleScreenMode (Game* g, GameFrame** gf1, GameFrame** gf2, Artwork* a);
void toggleScreenCenter (Game* g, GameFrame** gf1, GameFrame** gf2);

void drawString (Painter* painter,
				int l, int t, const charstring& str, int maxlen,
				int color, bool framed, bool inverted,
				int x1,int y1,int x2, int y2);
void drawLetter (Painter* painter,
				int l, int t, char letter, int color, 
				int x1, int y1, int x2, int y2);
void setActiveFont (int fontidx);

void showTrailer();

InputHandler* createInputHandler(int player);
void fillScreen(int col);

Image* loadArtworkImage (char* file, charstring* artwork = NULL);

#endif
