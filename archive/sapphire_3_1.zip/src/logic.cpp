#include "stdlib.h"
#include "time.h"

#include "framework.h"
#include "logic.h"
#include "toolbox.h"

#define BONUSTURNS 50

#define LORRYSOUNDSPEED 3
#define BUGSOUNDSPEED   1
#define WINSOUNDDELAY   3




static tiletype standardtileconvert[piece_end] = {
	tile_air,
	tile_wall, tile_stonewall, tile_glasswall, tile_invisiblewall, tile_wallemerald, 
	tile_air, tile_earth, tile_sand, tile_sandfull,
	tile_stone, tile_bag, tile_bomb, tile_roundwall,
    tile_door, tile_door_opened, tile_door_opened, tile_door,
    tile_doorblue, tile_doorred, tile_doorgreen, tile_dooryellow,
    tile_emerald, tile_sapphire, tile_ruby, tile_timebomb, tile_timebomb10,
    tile_keyblue1, tile_keyred1, tile_keygreen1, tile_keyyellow1,
    tile_box, tile_cushion, tile_elevator, tile_pusherleft, tile_pusherright,
    tile_convert, tile_dispenser2, tile_acid1, tile_swamp, tile_drop,

    tile_tickbomb, tile_tickbomb, tile_tickbomb,
	tile_tickbomb, tile_tickbomb, tile_tickbomb,

    tile_emerald, tile_stone, tile_bag, tile_bag,
    tile_sapphire, tile_sapphire, tile_bomb, 
	tile_ruby,
				  
	tile_explode1, tile_explode1,
    tile_explode2, tile_explode3, tile_explode4, tile_explode5,
                  
    tile_lorryleft, tile_lorryleft, 
    tile_lorryright, tile_lorryright,
    tile_lorryup, tile_lorryup, 
    tile_lorrydown, tile_lorrydown,
                  
	tile_bugleft, tile_bugleft, 
    tile_bugright, tile_bugright,
    tile_bugup, tile_bugup, 
    tile_bugdown, tile_bugdown, tile_explode1,

    tile_yamyamleft,tile_yamyamright,
    tile_yamyamup, tile_yamyamdown, tile_yamyamdown,

	tile_robot1, tile_wheel,

    tile_1rest, tile_2rest,

	tile_movie0_0, tile_movie1_0, tile_movie2_0, tile_movie3_0, tile_movie4_0,
	tile_movie5_0, tile_movie6_0, tile_movie7_0, tile_movie8_0, tile_movie9_0,
	tile_movie10_0, tile_movie11_0, tile_movie12_0, tile_movie13_0, tile_movie14_0,
	tile_movie15_0, tile_movie16_0, tile_movie17_0, tile_movie18_0, tile_movie19_0
};

static bool smoothesearth[piece_end];

void initLogic()
{
	// do init of static variable (at least once)
	for (int t=0; t<piece_end; t++) smoothesearth[t]=false;
	smoothesearth[outlineborder] = true;
	smoothesearth[wall] = true;
	smoothesearth[stonewall] = true;
	smoothesearth[glasswall] = true;
	smoothesearth[invisiblewall] = true;
	smoothesearth[wallemerald] = true;
	smoothesearth[earth] = true;
	smoothesearth[sand] = true;
	smoothesearth[sand_full] = true;
	smoothesearth[dispenser] = true;
}


Walkthrough::Walkthrough(int _channelnum)
{
	flags = 0;
	channelnum = _channelnum;
	for (int c=0; c<channelnum; c++) {
		channels[c].reserve(100);
		writecursor[c]=0;
	}
	reset();
}

Walkthrough::~Walkthrough () 
{
}


void Walkthrough::reset()
{
	cut(0);
	randseed = time(NULL) % 99999;
	clearReplayFlag();
}

void Walkthrough::cut(int len)
{
	for (int c=0; c<channelnum; c++) {
		if (channels[c].size()>len) channels[c].resize(len);
		writecursor[c]=len;
	}
	clearReplayFlag();
}

void Walkthrough::cutOneMove(int channel, int pos)
{
	int s=channels[channel].size();
	if (pos<s) {
		for (int p=pos; p<s-1; p++) channels[channel][p] = channels[channel][p+1];
		channels[channel].resize (s-1);
	}
	writecursor[channel] = pos;
	clearReplayFlag();
}
	
int Walkthrough::numberOfMoves (int channel)
{
	return channels[channel].size();
}

int Walkthrough::numberOfMoves()
{	
	int m=0;
	for (int c=0; c<channelnum; c++) {
		int m2 = numberOfMoves(c);
		if (m2>m) m = m2;
	}
	return m;
}

int Walkthrough::firstWriteCursor()
{	
	int m=numberOfMoves();
	for (int c=0; c<channelnum; c++) {
		int m2 = writecursor[c];
		if (m2<m) m = m2;
	}
	return m;
}

void Walkthrough::addMove (int channel, movetype move)
{
	int s = channels[channel].size();
	if (writecursor[channel] > s) writecursor[channel]=s;

	// insert new move at the desired position (write cursor)
	channels[channel].resize(s+1);
	for (int i=s-1; i>=writecursor[channel]; i--) channels[channel][i+1] = channels[channel][i];

	channels[channel][ (writecursor[channel])++ ] = move;
	clearReplayFlag();
}


movetype Walkthrough::getMove (int channel, int position)
{
	if (position>=channels[channel].size()) return rest;
	return channels[channel][position];
}

void Walkthrough::setWriteCursor (int channel, int position)
{
	writecursor[channel] = position;
}

int Walkthrough::getWriteCursor (int channel)
{
	return writecursor[channel];
}

	
void Walkthrough::addFromFile (char c)
{
	if (channelnum<1) return;

	movetype m=rest;
	switch (c) {
	case 't': m=moveup; break;
	case 'b': m=movedown; break;
	case 'l': m=moveleft; break;
	case 'r': m=moveright; break;
	case 'T': m=grabup; break;
	case 'B': m=grabdown; break;
	case 'L': m=grableft; break;
	case 'R': m=grabright; break;
	case 'u': m=bombup; break;
	case 'c': m=bombdown; break;
	case 'm': m=bombleft; break;
	case 's': m=bombright; break;
	}

	int s=channels[0].size(); 
	int min=0;
	for (int i=1; i<channelnum; i++) {
		if (channels[i].size()<s) { min=i; s=channels[i].size(); }
	}
	channels[min].push_back(m);
}

char Walkthrough::move2char (movetype move)
{
	switch (move) {
	case moveup:	return 't';
	case movedown:	return 'b';
	case moveleft:	return 'l';
	case moveright:	return 'r';
	case grabup:	return 'T';
	case grabdown:	return 'B';
	case grableft:	return 'L';
	case grabright:	return 'R';
	case bombup:	return 'u';
	case bombdown:	return 'c';
	case bombleft:	return 'm';
	case bombright:	return 's';
	default:		return '.';
	}
}

void Walkthrough::insertRests()
{
	int longest=0;
	bool different=false;
	int c;
	for (c=0; c<channelnum; c++) {
		if (writecursor[c]>longest) longest=writecursor[c];
	}
	for (c=0; c<channelnum; c++) {
		if (writecursor[c]!=longest) different = true;
	}
	if (!different) longest++;

	for (c=0; c<channelnum; c++) {
		while (writecursor[c] < longest) addMove (c, rest);
	}
}




static int piecevalue (piecetype p)
{
	switch (p) {
	case sapphire:
	case sapphire_falling:  return 3;
	case ruby:
	case ruby_falling:		return 5;
    case wallemerald:        
    case emerald:   
    case bag:      
    case box:         
	case emerald_falling:
	case bag_falling:
	case bag_opening:       return 1;
	case bugup:
	case bugleft:
	case bugright:
	case bugdown:			return 11;
	default: return 0;
	}
}

static bool isunsupporting (piecetype p)
{
	switch (p) {
	case stone:
	case bag:
	case bomb:
	case roundwall:
	case door:
    case door_opened:
	case door_closing:
	case door_closed:
	case doorblue:
	case doorred:
	case doorgreen:
	case dooryellow:
    case emerald:
	case sapphire:
	case ruby:
    case keyblue:
	case keyred:
	case keygreen:
	case keyyellow:
	case cushion:	return true;
	case wheel:		return true;
	default:		return false;
	}
}

#define CASELIVING   \
	case lorryleft: case lorryleft_fixed: \
	case lorryright: case lorryright_fixed: \
	case lorryup: case lorryup_fixed: \
    case lorrydown: case  lorrydown_fixed: \
	case bugleft: case bugleft_fixed: \
	case bugright: case bugright_fixed: \
	case bugup: case bugup_fixed: \
    case bugdown: case  bugdown_fixed: \
    case yamyamleft: case yamyamright: \
    case yamyamup: case yamyamdown: \
	case robot: \
    case man1: case man2: 

#define CASEMAN   \
    case man1: case man2: 

#define CASEPICKUP   case emerald: case sapphire: case ruby: \
		case timebomb: case timebomb10: \
		case keyblue: case keyred: case keygreen: case keyyellow:

static piecetype char2piece (char c)
{
	switch (c) {
    case ' ':
	case '~': return air;
    case '.': return earth;
	case 's': return sand;
	case 'S': return sand_full;
    case '#': return wall;
	case ':': return glasswall;
	case 'i': return invisiblewall;
    case '+': return stonewall;
    case '|': return roundwall;
    case '&': return wallemerald; 
    case '*': return emerald; 
	case '$': return sapphire; 
	case '(': return ruby;
    case '0': return stone;
    case '@': return bag; 
	case 'Q': return bomb;
    case 'E': return door;
    case '%': return swamp;
	case '/': return drop;
    case '!': return timebomb;
	case '?': return activebomb5;
    case '"': return timebomb10;
    case 'c': return converter;
    case '[': return box;
	case '_': return cushion;
	case '{': return elevator;
	case 'l': return pusherleft;
	case 'm': return pusherright;

    case 'd': return dispenser;
    case 'a': return acid;

	case 'b': return keyblue;
    case 'r': return keyred;
    case 'g': return keygreen;
    case 'y': return keyyellow;

    case 'B': return doorblue;
    case 'R': return doorred;
    case 'G': return doorgreen;
    case 'Y': return dooryellow;

    case '5': return lorryleft;
    case '6': return lorryup;
    case '7': return lorryright;
    case '8': return lorrydown;

    case 'h': return bugleft;
    case 'u': return bugup;
    case 'k': return bugright;
    case 'j': return bugdown;

    case '>': return yamyamright;
    case '<': return yamyamleft;
    case '^': return yamyamup;
    case 'V': return yamyamdown;

	case 'o': return robot;
	case 'w': return wheel;

    case '1': return man1;
    case '2': return man2;

	case 'A': return movie0;
	case 'C': return movie1;
	case 'D': return movie2;
	case 'F': return movie3;
	case 'H': return movie4;
	case 'I': return movie5;
	case 'J': return movie6;
	case 'K': return movie7;
	case 'L': return movie8;
	case 'M': return movie9;
	case 'N': return movie10;
	case 'O': return movie11;
	case 'P': return movie12;
	case 'T': return movie13;
	case 'U': return movie14;
	case 'W': return movie15;
	case 'X': return movie16;
	case 'Z': return movie17;
	case 'e': return movie18;
	case 'f': return movie19;

	default:  return air;
	}
}

static char piece2char (piecetype p, bool border)
{
	switch (p) {
	case outlineborder: return '#';
    case earth:			return '.';
	case sand:			return 's';
	case sand_full:		return 'S';
	case air:			return border ? '~' : ' ';
    case wall:			return '#';
	case glasswall:		return ':';
	case invisiblewall:	return 'i';
    case stonewall:		return '+';
    case roundwall:		return '|';
    case wallemerald:	return '&';
    case emerald:		return '*';
	case sapphire:		return '$';
	case ruby:			return '(';
    case stone:			return '0';
    case bag:			return '@'; 
	case bomb:			return 'Q';
    case door:			return 'E';
    case swamp:			return '%';
	case drop:			return '/';
    case timebomb:		return '!';
	case activebomb5:	return '?';
    case timebomb10:	return '"';
    case converter:		return 'c';
    case box:			return '[';
	case cushion:		return '_';
	case elevator:      return '{';
	case pusherleft:	return 'l';
	case pusherright:	return 'm';

    case dispenser:		return 'd';
    case acid:			return 'a';

	case keyblue:		return 'b';
    case keyred:		return 'r';
    case keygreen:		return 'g';
    case keyyellow:		return 'y';

    case doorblue:		return 'B';
    case doorred:		return 'R';
    case doorgreen:		return 'G';
    case dooryellow:	return 'Y';

    case lorryleft:		return '5';
    case lorryup:		return '6';
    case lorryright:	return '7';
    case lorrydown:		return '8';

    case bugleft:		return 'h';
    case bugup:			return 'u';
    case bugright:		return 'k';
    case bugdown:		return 'j';

    case yamyamright:	return '>';
    case yamyamleft:	return '<';
    case yamyamup:		return '^';
    case yamyamdown:	return 'V';

	case robot:			return 'o';
	case wheel:			return 'w';

    case man1:			return '1';
    case man2:			return '2';

	case movie0: return 'A';
	case movie1: return 'C';
	case movie2: return 'D';
	case movie3: return 'F';
	case movie4: return 'H';
	case movie5: return 'I';
	case movie6: return 'J';
	case movie7: return 'K';
	case movie8: return 'L';
	case movie9: return 'M';
	case movie10: return 'N';
	case movie11: return 'O';
	case movie12: return 'P';
	case movie13: return 'T';
	case movie14: return 'U';
	case movie15: return 'W';
	case movie16: return 'X';
	case movie17: return 'Z';
	case movie18: return 'e';
	case movie19: return 'f';

	default:  return '~';
	}
}


Level::Level() 
{
	width = 15;
	height = 12;
	for (int x=0; x<width; x++) for (int y=0; y<height; y++) piece[x][y]=earth;

	emeraldsneeded = 0; 
	emeraldsdestructable = -1;
	availabletime = -1;
	availablemoves = -1;
	swamprate = DEFAULTSWAMPRATE;
	pushprob = DEFAULTPUSHPROB;
	dispenserspeed = DEFAULTDISPENSERSPEED;
	elevatorspeed = DEFAULTELEVATORSPEED;
	wheelturntime = DEFAULTWHEELTURNTIME;
	robotspeed = DEFAULTROBOTSPEED;
	silentyamyam = false;
	silentlaser = false;

	difficulty = 0;
	category = 0;
	songplaystart = 0;
}

Level::~Level() 
{}


int Level::countEmeralds()
{
	int e = 0;
	for (int x=0; x<width; x++) {
		for (int y=0; y<height; y++) {
			e += piecevalue ( piece[x][y] );
		}
	}
	for (int ya=0; ya<yamyaminfo.size(); ya++) {
		for (int a=0; a<3; a++) {
			for (int b=0; b<3; b++) {
				e += piecevalue ( yamyaminfo[ya].piece[a][b] );
			}
		}
	}
	return e;
}

bool Level::load (charstring& fname, bool loadalldetails) 
{
	int i,len;
	int x,y;
	FILE* f;
	piecetype p;
	int autogemcounter = 0;

	doLog (2,"try to open level-file: %s", fname.data() );
	f = fopen (fname.data(), "r");
	if (f==NULL) {
		doLog (2, "could not open file: %s", fname.data() );
		return false;
	}

	width = 0;
	height = 0;

	filename = fname;
	longname.setstring(charstring(DEFAULTLANGUAGE),charstring(fname));

	difficulty = 0;
	category = 0;
	emeraldsneeded = -1;
	emeraldsdestructable = -1;
	availabletime = -1;
	availablemoves = -1;
	swamprate = DEFAULTSWAMPRATE; 
	pushprob = DEFAULTPUSHPROB;
	dispenserspeed = DEFAULTDISPENSERSPEED;
	elevatorspeed = DEFAULTELEVATORSPEED;
	wheelturntime = DEFAULTWHEELTURNTIME;
	robotspeed = DEFAULTROBOTSPEED;
	silentyamyam = false;
	silentlaser = false;

	artwork = "";
	movieset = "";
	soundwork = "";
	songname = "";
	songplaystart = 0;
	nextlevel = "";

	infolines.clear();
	authorname = "";
	firstfinisher = "";

	yamyaminfo.resize(0);
	walkthroughs.resize(0);

	while (!feof(f)) {
		char cmd;
		char linebuffer[1000];
		char *line;
		char *langprefix;

		if (feof(f)) goto fileover;
		if (!fgets (linebuffer, 1000, f)) goto fileover; 
		
		cmd = linebuffer[0];
		if (strlen(linebuffer)<=2) strcpy (linebuffer, "?  ");

		if (cmd=='l') {  // found a language prefix
			langprefix=line=linebuffer+1;
			while ((*line)>' ') line++;  // read to end of language name
			while ((*line)<=' ' && (*line)!='\0') {
				*line='\0'; line++;   // kill white spaces
			}
			if (*line!='\0') {  // do we have a command after the prefix?
				cmd = *line;
				line += 2;
			}
		} else {
			langprefix=NULL;
			line = linebuffer+2;
		}

		len = strlen(line);
		while (len>0 && ((unsigned char)line[len-1]) <= ' ') line[--len] = '\0';

		switch (cmd) {
		case 'n': 
			if (langprefix) longname.setstring(charstring(langprefix), charstring(line));
			else longname.setstring(charstring(DEFAULTLANGUAGE), charstring(line));
			break;

		case 'D':
			sscanf (line, "%d", &difficulty);
			break;

		case 'C':
			sscanf (line, "%d", &category);
			break;

		case 'e':
			if (line[0]=='+') {
				sscanf (line+1, "%d", &i);
				autogemcounter+=i;
			} else if (line[0]=='-') {
				sscanf (line+1, "%d", &i);
				autogemcounter-=i;
			} else {
				sscanf (line, "%d", &emeraldsneeded );
			}
			break;

		case 'E': sscanf (line, "%d", &emeraldsdestructable); break;
		
		case 'T':
			sscanf (line, "%d", &availabletime );
			break; 
		case 't':
			sscanf (line, "%d", &availablemoves );
			break; 

		case 's': sscanf (line, "%d", &swamprate ); break;
		case 'p': sscanf (line, "%d", &pushprob ); break;
		case 'd': sscanf (line, "%d", &dispenserspeed); break;
		case 'v': sscanf (line, "%d", &elevatorspeed); break;
		case 'o': sscanf (line, "%d", &robotspeed); break;
		case 'w': sscanf (line, "%d", &wheelturntime); break;

		case 'Y': silentyamyam = true;	break;
		case 'L': silentlaser = true;	break;

		case 'A':
			if (len>0) {
				artwork = line;
				doDownCase (artwork);
				if (artwork=="default") artwork="";
			}
			break;

		case 'O':
			if (len>0) {
				movieset = line;
				doDownCase (movieset);
			}
			break;

		case 'S':
			if (len>0) {
				soundwork = line;
				doDownCase (soundwork);
				if (soundwork=="default") soundwork="";
			}
			break;

		case 'M':
			if (len>0) {
				sscanf (line, "%d", &songplaystart);
				while ( (line[0]>='0' && line[0]<='9') 
					  || line[0]=='-' || line[0]=='+') line++;
				while (line[0]==' ') line++;
				songname = line;
			}
			break;

		case 'N':
			if (len>0) {
				nextlevel = line;
			}
			break;

		case 'i':
			if (langprefix) infolines.addstring(charstring(langprefix),charstring(line));
			else infolines.addstring(charstring(DEFAULTLANGUAGE), charstring(line));
			break;

		case 'a':
			if (len>0) authorname = line;
			break;

		case 'f':
			if (len>0) firstfinisher = line;
			break;

		case 'm':
			sscanf (line, "%d %d", &width, &height);
			width+=2;   // add invisible border
			height+=2;
			doLog (3, "map size: %d %d", width,height);

			for (x=0; x<width; x++) for (y=0; y<height; y++) piece[x][y] = outlineborder;

			for (y=1; y<height-1; y++) {
				bool endofline = false;
				fgets (linebuffer,1000,f);
				for (x=1;x<width-1; x++) {
					if (linebuffer[x-1]<' ') endofline = true;
					p = char2piece ( (char)(endofline ? '~' : linebuffer[x-1]));
					piece[x][y] = p; 
				}
			}
			break;

		case 'y':
			i = yamyaminfo.size();
			yamyaminfo.resize (i+1);
			{
				bool endofline = false;
				for (y=0; y<3; y++) {
					for (x=0; x<3; x++) {
						if (line[x+y*3]<' ') endofline = true;
						piecetype p = char2piece ( endofline ? '~' : line[x+y*3] );
						yamyaminfo[i].piece[x][y] = p;
					}
				}
			}
			break;

		case 'R':
			{
			walkthroughs.resize(walkthroughs.size()+1);
			Walkthrough* t = &(walkthroughs[walkthroughs.size()-1]);
			int rs=0;
			sscanf (line, "%d", &rs);
			t->randseed = rs;
			t->flags = PLAYBACKFLAG_SECRETDEMO;
			t->channelnum = differentPlayersInLevel();
			}
			break;

		case '0':
			{ int s = walkthroughs.size();
			if (s>0) sscanf (line, "%d", &walkthroughs[s-1].flags);
			}
			break;
		case '1':
			{ int s = walkthroughs.size();
			if (s>0) {
				if (langprefix) walkthroughs[s-1].name.setstring(charstring(langprefix),charstring(line));
				else walkthroughs[s-1].name.setstring(charstring(DEFAULTLANGUAGE),charstring(line));
			}
			}
			break;
		case 'r': // compatiblity with old EmeraldMine 2.0 format
			{ int s = walkthroughs.size();
			if (s>0 && walkthroughs[s-1].numberOfMoves()==0) {
				for (i=0; i<differentPlayersInLevel(); i++) {
					walkthroughs[s-1].addFromFile ('.');
				}
			}
			}
		case '2':
			if (loadalldetails)
			{ 
				int s = walkthroughs.size();
				if (s>0) {
					for (i=0; i<((int)strlen(line)); i++) {
						if ( line[i]>' ' ) walkthroughs[s-1].addFromFile (line[i]);
					}
				}
			}
			break;

		}
	}
fileover:

	if (emeraldsneeded<0) emeraldsneeded=countEmeralds()  + autogemcounter;

	fclose (f);

	// check if the level has a correct format
	if (width<=2 || height<=2 || width>maxlevelwidth || height>maxlevelheight) {
		doLog (1, "level of incorrect size");
		return false;
	}
    doLog (3, "successfully finished loading");
	return true;
}

bool Level::save()
{
	doLog (2,"try to open level-file for writing: %s", filename.data() );
	int i,j;
	FILE* f = fopen (filename.data(), "w");
	if (!f) return false;

	fprintf (f, "n %s\n",longname.contents[0].data());
	for (i=1; i<longname.contents.size(); i++) {
		fprintf (f, "l%s n %s\n", 
		longname.languages[i].data(), longname.contents[i].data() );
	}
	fprintf (f, "D %d\n", difficulty);
	if (category!=0) fprintf (f, "C %d\n", category);
	if (emeraldsneeded != countEmeralds() ) fprintf (f, "e %d\n", emeraldsneeded);
	if (emeraldsdestructable>=0) fprintf (f, "E %d\n", emeraldsdestructable);
	if (availabletime>0) fprintf (f, "T %d\n", availabletime);
	if (availablemoves>0) fprintf (f, "t %d\n", availablemoves);
	if (swamprate != DEFAULTSWAMPRATE) fprintf (f, "s %d\n", swamprate );
	if (pushprob != DEFAULTPUSHPROB) fprintf (f,"p %d\n", pushprob );
	if (dispenserspeed != DEFAULTDISPENSERSPEED) fprintf (f, "d %d\n", dispenserspeed);
	if (elevatorspeed != DEFAULTELEVATORSPEED) fprintf (f, "v %d\n", elevatorspeed);
	if (robotspeed!=DEFAULTROBOTSPEED) fprintf (f, "o %d\n", robotspeed);
	if (wheelturntime!=DEFAULTWHEELTURNTIME) fprintf (f, "w %d\n", wheelturntime);
	if (silentyamyam) fprintf (f, "Y\n");
	if (silentlaser) fprintf (f, "L\n"); 
	if (artwork!="") fprintf (f, "A %s\n", artwork.data());
	if (movieset!="") fprintf (f, "O %s\n", movieset.data());
	if (soundwork!="") fprintf (f, "S %s\n", soundwork.data());
	if (songname!="") fprintf (f, "M %d %s\n", songplaystart, songname.data());
	if (nextlevel!="") fprintf (f, "N %s\n", nextlevel.data());

	for (i=0; i<infolines.contents[0].size(); i++) {
		fprintf (f, "i %s\n", infolines.contents[0][i].data());
	}
	for (j=1; j<infolines.contents.size(); j++) {
		for (i=0; i<infolines.contents[j].size(); i++) {
			fprintf (f, "l%s i %s\n", infolines.languages[j].data(),
				infolines.contents[j][i].data());
		}
	}

	if (authorname!="") fprintf (f, "a %s\n", authorname.data());
	if (firstfinisher!="") fprintf (f, "f %s\n", firstfinisher.data());

	fprintf (f, "m %d %d\n", width-2, height-2);
	for (int y=1; y<height-1; y++) {
		for (int x=1;x<width-1; x++) {
			fprintf (f, "%c", piece2char (piece[x][y], x==1 ) );
		}
		fprintf (f, "\n");
	}

	for (int ya=0; ya<yamyaminfo.size(); ya++) {
		fprintf (f, "y ");
		for (int y=0; y<3; y++) {
			for (int x=0; x<3; x++) {
				fprintf (f, "%c", piece2char (yamyaminfo[ya].piece[x][y], y==0 && x==0 ) );
			}
		}
		fprintf (f, "\n");
	}

	for (int widx=0; widx<walkthroughs.size(); widx++) {
		Walkthrough* w = &(walkthroughs[widx]);

		fprintf (f, "R %d\n", w->randseed);
		fprintf (f, "0 %d\n", w->flags);
		fprintf (f, "1 %s\n", w->name.contents[0].data());
		for (i=1; i<w->name.contents.size(); i++) {
			fprintf (f, "l%s 1 %s\n", w->name.languages[i].data(), 
				w->name.contents[i].data());
		}

		int turns = w->numberOfMoves();
		int charpos=0;
		for (int t=0; t<turns; t++) {
			for (int c=0; c<w->channelnum; c++) {
				if (charpos % 40 == 0) fprintf (f, "%s2 ", (charpos==0) ? "" : "\n");
				charpos++;

				fprintf (f, "%c", w->move2char ( w->getMove(c,t) ) );
			}
		}
		fprintf (f, "\n");
	}

	fclose (f);
	return true;
}


int Level::differentPlayersInLevel ()
{
	int diff=0;
	for (int x=0; x<width; x++) {
		for (int y=0; y<height; y++) {
			piecetype p = piece[x][y];
			if (p>=man1 && p<=man2) {
				int d = (p-man1)+1;
				if (d>diff) diff=d;
			}
		}
	}
	return diff;
}

int Level::totalPlayersInLevel()
{
	int num=0;
	for (int x=0; x<width; x++) {
		for (int y=0; y<height; y++) {
			piecetype p = piece[x][y];
			if (p>=man1 && p<=man2) {
				num++;
			}
		}
	}
	return num;
}

int Level::totalExitsInLevel()
{
	int num=0;
	for (int x=0; x<width; x++) {
		for (int y=0; y<height; y++) {
			piecetype p = piece[x][y];
			if (p==door) {
				num++;
			}
		}
	}
	return num;
}


bool Level::allDemosOK()
{
	for (int i=0; i<walkthroughs.size(); i++) {
		Walkthrough* w = &(walkthroughs[i]);
		if (w->flags & PLAYBACKFLAG_SUSPENDED) continue;

		doLog (2, "checking demo: %s", w->name.contents[0].data());

		Game* g = new Game (this, 2, i);
		while (g->fastForward());

		doLog (2, "demo play ended at position: %d", g->getPositionCounter());

		if (!g->isDone()) {
			doLog (2, "demo did not run correctly!");
			delete g;
			return false;
		}
		delete g;
	}		
	return true;
}

void Level::lockDemos()
{
	for (int i=0; i<walkthroughs.size(); i++) {
		Walkthrough* w = &(walkthroughs[i]);
		if (w->flags & PLAYBACKFLAG_SUSPENDED) continue;
		if (w->flags & PLAYBACKFLAG_BACKGROUNDDEMO) continue;
		
		w->flags |= PLAYBACKFLAG_SECRETDEMO;
	}
}


tiletype Level::getTile (int x, int y)
{
	if (x<=0 || x>=width-1 || y<=0 || y>=height-1) return tile_air;

	piecetype p = piece[x][y];
	switch (p) {

	case acid:
		if (piece[x-1][y] == acid) {
			if (piece[x+1][y] == acid) {
				return tile_acid1;
			} else {
				return tile_acidleft1;
			}
		} else {
			if (piece[x+1][y] == acid) {
				return tile_acidright1;
			} else {
				return tile_acidalone1;
			}
		}
		break;
	}
	
	return standardtileconvert[p];
}

tiletype Level::getYamYamTile(int b, int x, int y)
{
	if (x<0 || x>2 || y<0 || y>2 || b>yamyaminfo.size()) return tile_air;

	piecetype p = yamyaminfo[b].piece[x][y];
	return standardtileconvert[p];
}

void Level::getWalkthroughName(int walkidx, charstring& name)
{
	if (walkidx>=0 && walkidx<walkthroughs.size()) {
		name = *(walkthroughs[walkidx].name.get());
		return;
	}

	int num=0;
	for (int i=0; i<walkthroughs.size(); i++) {
		if (! (walkthroughs[i].flags & PLAYBACKFLAG_SUSPENDED)) num++;
	}
	char txt[100];
	sprintf (txt,"Demo %d", num+1);
	name = txt;
}

void Level::deleteWalkthrough (int walkthroughindex)
{
	int l = walkthroughs.size();
	for (int i=walkthroughindex; i<l-1; i++) walkthroughs[i] = walkthroughs[i+1];
	walkthroughs.resize (l-1);
}

int Level::findSuspended()
{
	for (int widx=0; widx<walkthroughs.size(); widx++) {
		if (walkthroughs[widx].flags & PLAYBACKFLAG_SUSPENDED) return widx;
	}
	return -1;
}

void Level::deleteSuspended()
{
	int s;
	while ( (s = findSuspended()) >= 0) deleteWalkthrough (s);
}





Checkpoint::Checkpoint(Game* g)
{
	Level* l = g->level;
	int w=l->width;
	int h=l->height;

	players.resize(g->players.size());
	for (int p=0; p<g->players.size(); p++) {
		players[p].xpos  =  g->players[p]->xpos;
		players[p].ypos  =  g->players[p]->ypos;
		players[p].dead  =  g->players[p]->dead;
		players[p].done  =  g->players[p]->done;
		players[p].bombsready  =  g->players[p]->bombsready;
		players[p].haveredkey     =  g->players[p]->haveredkey;
		players[p].havegreenkey   =  g->players[p]->havegreenkey;
		players[p].havebluekey    =  g->players[p]->havebluekey;
		players[p].haveyellowkey  =  g->players[p]->haveyellowkey;
	}

	positioncounter		= g->positioncounter;
	emeraldsneeded		= g->emeraldsneeded;
	availabletime		= g->availabletime;
	randseed			= g->randseed;
	emeraldsdestroyed	= g->emeraldsdestroyed;
	yamyamskilled		= g->yamyamskilled;
	wheelendtime		= g->wheelendtime;
	wheelx				= g->wheelx;
	wheely				= g->wheely;
	gamewintime			= g->gamewintime;
	movecounter         = g->movecounter;

	piece = new piecetype[w*h];
	explosionrest = new piecetype[w*h];
	for (int x=0; x<w; x++) {
		for (int y=0; y<h; y++) {
			piece[x*h+y]			= g->piece[x][y];
			explosionrest[x*h+y]	= g->explosionrest[x][y];
		}
	}
}

Checkpoint::~Checkpoint()
{
	delete[] piece;
	delete[] explosionrest;
}

void Checkpoint::reactivate(Game* g)
{
	Level* l = g->level;
	int w=l->width;
	int h=l->height;

	for (int p=0; p<g->players.size(); p++) {
		g->players[p]->xpos  =  players[p].xpos;
		g->players[p]->ypos  =  players[p].ypos;
		g->players[p]->dead  =  players[p].dead;
		g->players[p]->done  =  players[p].done;
		g->players[p]->bombsready	  =  players[p].bombsready;
		g->players[p]->haveredkey     =  players[p].haveredkey;
		g->players[p]->havegreenkey   =  players[p].havegreenkey;
		g->players[p]->havebluekey    =  players[p].havebluekey;
		g->players[p]->haveyellowkey  =  players[p].haveyellowkey;
	}

	g->positioncounter		= positioncounter;
	g->emeraldsneeded		= emeraldsneeded;
	g->availabletime		= availabletime;
	g->randseed				= randseed;
	g->emeraldsdestroyed	= emeraldsdestroyed;
	g->yamyamskilled		= yamyamskilled;
	g->wheelendtime			= wheelendtime;
	g->wheelx				= wheelx;
	g->wheely				= wheely;
	g->gamewintime			= gamewintime;
	g->movecounter          = movecounter;

	for (int x=0; x<w; x++) {
		for (int y=0; y<h; y++) {
			g->piece[x][y]				= piece[x*h+y];
			g->explosionrest[x][y]		= explosionrest[x*h+y];
		}
	}
}




Player::Player (int _channel, int startx, int starty) 
{
	channel = _channel;
	startxpos = startx;
	startypos = starty;
	piece = channel ? man2 : man1;
	seq_rest = channel ? seq_2rest : seq_1rest;
	seq_walkup = channel ? seq_2walkup : seq_1walkup;
	seq_walkdown = channel ? seq_2walkdown : seq_1walkdown;
	seq_walkleft = channel ? seq_2walkleft : seq_1walkleft;
	seq_walkright = channel ? seq_2walkright : seq_1walkright;
	seq_digup = channel ? seq_2digup : seq_1digup;
	seq_digdown = channel ? seq_2digdown : seq_1digdown;
	seq_digleft = channel ? seq_2digleft : seq_1digleft;
	seq_digright = channel ? seq_2digright : seq_1digright;
	seq_pushup = channel ? seq_2pushup : seq_1pushup;
	seq_pushdown = channel ? seq_2pushdown : seq_1pushdown;
	seq_pushleft = channel ? seq_2pushleft : seq_1pushleft;
	seq_pushright = channel ? seq_2pushright : seq_1pushright;
	seq_blink = channel ? seq_2blink : seq_1blink;
}

Player::~Player ()
{
}

bool Player::hasKeyFor (piecetype p)
{
	switch (p) {
	case doorred:	return haveredkey; 
	case doorgreen:	return havegreenkey;
	case doorblue:	return havebluekey;
	case dooryellow:return haveyellowkey;
	default:	 return false;
	}
}



Game::Game(Level* l, int micros) 
  : thiswalk (l->differentPlayersInLevel())
{
	doLog (3, "starting game with %d microsteps per steps", micros);

	level = l;
	microstepsperstep = micros;
	needcheckpoints = false;
	for (int la=0; la<layers; la++) animations[la].reserve(100);	

	init();
	reset();
}

Game::Game(Level*l, int micros, int walkthroughindex)
  : thiswalk (l->differentPlayersInLevel())
{
	doLog (3, "starting game with %d microsteps per steps", micros);

	level = l;
	microstepsperstep = micros;
	needcheckpoints = false;
	for (int la=0; la<layers; la++) animations[la].reserve(100);	

	init ();
	if (walkthroughindex>=0 && walkthroughindex < level->walkthroughs.size()) {
		thiswalk = level->walkthroughs[walkthroughindex];
	}
	reset ();
}

void Game::init() 
{
	for (int c=0; c<maxinputchannels; c++) inputhandler[c] = NULL;

	for (int lay=0; lay<layers; lay++) {
		animations[lay].reserve(50);
	}

	for (int y=0; y<level->height; y++) {
		for (int x=0; x<level->width; x++) {
			piecetype p = level->piece[x][y];
			if (p == man1 || p == man2) {
				players.push_back ( new Player( (p==man1) ? 0 : 1, x,y ) );
			}
		}
	}
}


Game::~Game() 
{ 
	flushCheckPoints(0);
	for (int i=0; i<players.size(); i++) delete players[i];
}


int Game::getTimeBombsLeft(int channel) 
{ 
	int bombs = 0;
	for (int pidx=0; pidx<players.size(); pidx++){
		Player* p = players[pidx];
		if (p->channel == channel) bombs += p->bombsready;
	}
	return bombs;
};

bool Game::getHasKey(int channel, int kidx) 
{ 
	for (int pidx=0; pidx<players.size(); pidx++){
		Player* p = players[pidx];
		if (p->channel != channel) continue;

		switch (kidx) {
		case 0: if (p->haveredkey) return true;
			break;
		case 1: if (p->havegreenkey) return true;
			break;
		case 2: if (p->havebluekey) return true;
			break;
		case 3: if (p->haveyellowkey) return true;
			break;
		}
	}
	return false;
}

void Game::setInputHandler (int channel, InputHandler* handler)
{
	inputhandler[channel] = handler;
}

tiletype Game::getFixedTile (int x, int y)
{
	int pidx;
	piecetype p;

	switch (islocked[x][y]) {
	case unlocked: 		p=piece[x][y]; break;
	case normallocked:	return tile_air;
	case diglocked:		p=earth; break;
	}

	switch (p) {
	case earth:
		{
			tiletype t = tile_earth;
			if (! smoothesearth[piece[x+1][y]] && islocked[x+1][y]<diglocked) t=(tiletype)(((int)t)+1);
			if (! smoothesearth[piece[x-1][y]] && islocked[x-1][y]<diglocked) t=(tiletype)(((int)t)+2);
			if (! smoothesearth[piece[x][y+1]] && islocked[x][y+1]<diglocked) t=(tiletype)(((int)t)+4);
			if (! smoothesearth[piece[x][y-1]] && islocked[x][y-1]<diglocked) t=(tiletype)(((int)t)+8);
			return t;
		}

	case acid:
				if (piece[x-1][y] == acid) {
					if (piece[x+1][y] == acid) {
						switch ((positioncounter+4) % 5) { 
						case 0: return tile_acid1;
						case 1: return tile_acid2;
						case 2: return tile_acid3;
						case 3: return tile_acid4;
						case 4: return tile_acid5;
						}
					} else {
						switch ((positioncounter+4) % 5) { 
						case 0: return tile_acidleft1;
						case 1: return tile_acidleft2;
						case 2: return tile_acidleft3;
						case 3: return tile_acidleft4;
						case 4: return tile_acidleft5;
						}
					}
				} else {
					if (piece[x+1][y] == acid) {
						switch ((positioncounter+4) % 5) { 
						case 0: return tile_acidright1;
						case 1: return tile_acidright2;
						case 2: return tile_acidright3;
						case 3: return tile_acidright4;
						case 4: return tile_acidright5;
						}
					} else {
						switch ((positioncounter+4) % 5) { 
						case 0: return tile_acidalone1;
						case 1: return tile_acidalone2;
						case 2: return tile_acidalone3;
						case 3: return tile_acidalone4;
						case 4: return tile_acidalone5;
						}
					}
				}
				break;

	case keyblue:
	case keyred:
	case keygreen:
	case keyyellow:
				switch ( (piece[x][y]-keyblue)*5 + (positioncounter % 5) ) {
				case 0*5+0: return tile_keyblue1;
                case 0*5+1: return tile_keyblue2;
                case 0*5+2: return tile_keyblue3;
                case 0*5+3: return tile_keyblue4;
                case 0*5+4: return tile_keyblue5;
                case 1*5+0: return tile_keyred1;
                case 1*5+1: return tile_keyred2;
                case 1*5+2: return tile_keyred3;
                case 1*5+3: return tile_keyred4;
                case 1*5+4: return tile_keyred5;
                case 2*5+0: return tile_keygreen1;
                case 2*5+1: return tile_keygreen2;
                case 2*5+2: return tile_keygreen3;
                case 2*5+3: return tile_keygreen4;
                case 2*5+4: return tile_keygreen5;
                case 3*5+0: return tile_keyyellow1;
                case 3*5+1: return tile_keyyellow2;
                case 3*5+2: return tile_keyyellow3;
                case 3*5+3: return tile_keyyellow4;
                case 3*5+4: return tile_keyyellow5;
                } 
				break;

	case dispenser: 
				if (level->dispenserspeed>0) {
					switch ((positioncounter+level->dispenserspeed-1) % level->dispenserspeed) {
					case 0: return tile_dispenser1;
					default: return tile_dispenser2;
					}
				} else return tile_dispenser2;
				break;

	case yamyamleft:
		if (piece[x-1][y]==air) return tile_yamyamleft;
		return tile_yamyam;
	case yamyamright:
		if (piece[x+1][y]==air) return tile_yamyamright;
		return tile_yamyam;
	case yamyamup:
		if (piece[x][y-1]==air) return tile_yamyamup;
		return tile_yamyam;
	case yamyamdown:
		if (piece[x][y+1]==air) return tile_yamyamdown;
		return tile_yamyam;

	case robot:
		if (positioncounter%2 == 0) return tile_robot1;
		return tile_robot2;

	case man1:
	case man2:
		for (pidx=0; pidx<players.size(); pidx++) {
			Player* p = players[pidx];
			if (p->xpos==x && p->ypos==y) {
				switch (p->previoussequence) {
				case seq_1rest:			return tile_1rest;
				case seq_1walkup:		return tile_1walkup;
				case seq_1walkdown:		return tile_1walkdown;
				case seq_1walkleft:		return tile_1walkleft;
				case seq_1walkright:	return tile_1walkright;
				case seq_1pushup:		return tile_1pushup;
				case seq_1pushdown:		return tile_1pushdown;
				case seq_1pushleft:		return tile_1pushleft;
				case seq_1pushright:	return tile_1pushright;
				case seq_1digup:		return tile_1digup;
				case seq_1digdown:		return tile_1digdown;
				case seq_1digleft:		return tile_1digleft;
				case seq_1digright:		return tile_1digright;
				case seq_1blink:		return tile_1rest;
				case seq_2rest:			return tile_2rest;
				case seq_2walkup:		return tile_2walkup;
				case seq_2walkdown:		return tile_2walkdown;
				case seq_2walkleft:		return tile_2walkleft;
				case seq_2walkright:	return tile_2walkright;
				case seq_2pushup:		return tile_2pushup;
				case seq_2pushdown:		return tile_2pushdown;
				case seq_2pushleft:		return tile_2pushleft;
				case seq_2pushright:	return tile_2pushright;
				case seq_2digup:		return tile_2digup;
				case seq_2digdown:		return tile_2digdown;
				case seq_2digleft:		return tile_2digleft;
				case seq_2digright:		return tile_2digright;
				case seq_2blink:		return tile_2rest;
				}
			}
		}
		break;

	case movie5:  return tile_movie5_0 + (positioncounter%2);
	case movie6:  return tile_movie6_0 + (positioncounter%2);
	case movie7:  return tile_movie7_0 + (positioncounter%2);
	case movie8:  return tile_movie8_0 + (positioncounter%2);
	case movie9:  return tile_movie9_0 + (positioncounter%2);
	case movie10: return tile_movie10_0 + (positioncounter%4);
	case movie11: return tile_movie11_0 + (positioncounter%4);
	case movie12: return tile_movie12_0 + (positioncounter%4);
	case movie13: return tile_movie13_0 + (positioncounter%4);
	case movie14: return tile_movie14_0 + (positioncounter%4);
	case movie15: return tile_movie15_0 + (positioncounter%8);
	case movie16: return tile_movie16_0 + (positioncounter%8);
	case movie17: return tile_movie17_0 + (positioncounter%8);
	case movie18: return tile_movie18_0 + (positioncounter%8);
	case movie19: return tile_movie19_0 + (positioncounter%8);
	}
	return standardtileconvert[p];
}


int Game::getAnimationNumber (int layer) 
{ 
	return animations[layer].size(); 
}


Animation* Game::getAnimation (int layer, int index) 
{
	return &animations[layer][index];
}


void Game::getFocusPoint (int tilesize, int channel, int &x, int &y)
{
	int w2 = (microcounter==0) ? tilesize : (microcounter*tilesize)/microstepsperstep;
	int w1 = tilesize - w2;

	int differentchannels = 0;
	
	x = 0;
	y = 0;
	for (int c=0; c<maxinputchannels; c++) {
		int sx = 0;
		int sy = 0;
		int pnum =0;

		for (int pidx=0; pidx<players.size(); pidx++) {
			Player* p = players[pidx];
			if (c==p->channel) {
				sx += p->prevxpos*w1 + p->xpos*w2;
				sy += p->prevypos*w1 + p->ypos*w2;
				pnum++;
			}
		}

		if (pnum>0) {
			double mx = sx / pnum;
			double my = sy / pnum;

			if (channel==-1) {
				x += mx;
				y += my;
				differentchannels++;
			} else if (channel==c) {
				x = mx;
				y = my;
				return;
			}
		}
	}

	if (differentchannels>1) {
		x /= differentchannels;
		y /= differentchannels;
	}
}


Animation* Game::createAnimation (int layer)
{
	int s = animations[layer].size();
	animations[layer].resize (s+1);
	return &animations[layer][s];
}


void Game::addBGAnimation (sequencetype seq, int x, int y, int dx, int dy)
{
	Animation* n = createAnimation (background);
	n->seq=seq;
	n->x=x;
	n->y=y;
	n->dx=dx;
	n->dy=dy;
}

void Game::addFGAnimation (sequencetype seq, int x, int y, int dx, int dy)
{
	Animation* n = createAnimation (foreground);
	n->seq=seq;
	n->x=x;
	n->y=y;
	n->dx=dx;
	n->dy=dy;
}

void Game::addTOPAnimation (sequencetype seq, int x, int y, int dx, int dy)
{
	Animation* n = createAnimation (toplayer);
	n->seq=seq;
	n->x=x;
	n->y=y;
	n->dx=dx;
	n->dy=dy;
}


void Game::forgetAnimations ()
{
	for (int lay=0; lay<layers; lay++) {
		animations[lay].resize(0);
	}

	for (int x=0; x<level->width; x++) {
		for (int y=0; y<level->height; y++) {
			islocked[x][y] = unlocked;
		}
	}
}


bool Game::isSoundTime()
{
	if (microcounter!=1) return false;
	if (soundsconsumed) return false;
	soundsconsumed = true;
	return true;
}

int Game::getSound(soundtype snd)
{
	if (snd>=0 && snd<snd_end) {
		return soundvolume[snd];
	}
	return volume_silence;
}

enum {DIFFERENTVOLUMES=30};
int volumetable[DIFFERENTVOLUMES] = {
	  0,  0, -1, -2, -3, -4, -5, -6, -7, -8, 
	 -9,-10,-11,-12,-13,-14,-15,-16,-17,-18,
	-19,-20,-21,-22,-23,-24,-25,-26,-27,-28 
};

void Game::addSound(int x, int y, soundtype snd)
{
	if (snd<0 || snd>=snd_end) return;

	int mindist=DIFFERENTVOLUMES-1;
	for (int pidx=0; pidx<players.size(); pidx++) {
		Player* p = players[pidx];

		int dx=p->xpos-x; if (dx<0) dx=-dx;
		int dy=p->ypos-y; if (dy<0) dy=-dy;
		int dist = (dx>dy) ? dx : dy;

		if (dist<mindist) mindist=dist;
	}

	int vol = volumetable[mindist];
	if (soundvolume[snd] < vol) soundvolume[snd] = vol;
}

void Game::addSound(soundtype snd)
{
	if (snd<0 || snd>=snd_end) return;
	soundvolume[snd] = volume_full;
}


void Game::forgetSounds()
{
	for (int snd=0; snd<snd_end; snd++) {
		soundvolume[snd] = volume_silence;
	}
	soundsconsumed = false;
}


void Game::setCheckPointIfNeeded()
{
	if (!needcheckpoints) return;
	if (positioncounter==0 || (positioncounter%checkpointintervall)!=0) return;
	if (checkpoints.size() >= positioncounter) return;

	checkpoints.resize (positioncounter+1, NULL);
	checkpoints[positioncounter] = new Checkpoint (this);
}

void Game::flushCheckPoints (int position)
{
	if (checkpoints.size() <= position) return;

	for (int c=position; c<checkpoints.size(); c++) {
		delete checkpoints[c];
	}
	checkpoints.resize (position);
}



bool Game::saveWalkthrough (int& walkidx, charstring& name)
{
	Walkthrough* w;
	bool newlevel=false;

	if (walkidx>=0 && walkidx<level->walkthroughs.size()) {
		w = &(level->walkthroughs[walkidx]);
	} else {
		int s=level->walkthroughs.size();
		level->walkthroughs.resize (s+1);
		w = &(level->walkthroughs[s]);
		walkidx = s;
		newlevel = true;
	}

	(*w) = thiswalk;
	w->name.setstring(*getcurrentlanguage(),name);
	if (newlevel) w->name.setstring(charstring(DEFAULTLANGUAGE),name);

	return level->save();
}

bool Game::saveSuspended ()
{
	Walkthrough* w=NULL;
	int widx;

	for (widx=0; widx<level->walkthroughs.size(); widx++) {
		if (level->walkthroughs[widx].flags & PLAYBACKFLAG_SUSPENDED) {
			w = &(level->walkthroughs[widx]);
			break;
		}
	}
	if (w==NULL) {
		int s=level->walkthroughs.size();
		level->walkthroughs.resize (s+1);
		w = &(level->walkthroughs[s]);
	}

	(*w) = thiswalk;
	w->name.setstring(charstring(DEFAULTLANGUAGE), charstring("Suspended"));
	w->flags = PLAYBACKFLAG_SUSPENDED;

	return level->save();
}

void Game::resetAndClearWalkthrough()
{
	thiswalk.reset();
	flushCheckPoints(0);
	reset();
}

void Game::reset ()
{
	microcounter=0;
	resetLogic();

	forgetAnimations();
	forgetSounds();
}

void Game::resetLogic()
{
	positioncounter=0;
	emeraldsneeded = level->emeraldsneeded;
	availabletime = level->availabletime;
	emeraldsdestroyed=0;
	yamyamskilled = 0;
	randseed = thiswalk.randseed;
	wheelendtime = 0;
	wheelx = 0;
	wheely = 0;
	gamewintime = -1;
	movecounter = 0;

	for (int x=0; x<level->width; x++) {
		for (int y=0; y<level->height; y++) {
			piece[x][y] = level->piece[x][y];
			explosionrest[x][y] = air;
		}
	}

	for (int pidx=0; pidx<players.size(); pidx++) {
		Player* p = players[pidx];
		p->prevxpos = p->xpos = p->startxpos;
		p->prevypos = p->ypos = p->startypos;
		p->dead = false;
		p->done = false;
		p->bombsready = 0;
		p->haveredkey = false;
		p->havegreenkey = false;
		p->havebluekey = false;
		p->haveyellowkey = false;
		p->previoussequence = p->seq_rest;
	}
}


void Game::microStepRecord ()
{
	doLog (4, "recording single micro step: %d/%d", positioncounter, microcounter);

	flushCheckPoints(positioncounter);

	for (int c=0; c<thiswalk.channelnum; c++) {
		if (inputhandler[c]) {
			inputhandler[c]->recordMove (&thiswalk, c, positioncounter);
		}
	}

	microStepForward();
}

void Game::microStepRecordSingle ()
{
	doLog (4, "recording single micro step: %d/%d in single mode", positioncounter, microcounter);

	flushCheckPoints(positioncounter);

	for (int c=0; c<thiswalk.channelnum; c++) {
		if (inputhandler[c]) {
			inputhandler[c]->recordMove (&thiswalk, c, -1);
		}
	}
	if (thiswalk.firstWriteCursor() > positioncounter) {
		microStepForward();
	}
}

bool Game::microStepForward ()
{
	doLog (4, "doing single micro step: %d/%d", positioncounter, microcounter);

	if (thiswalk.numberOfMoves() > positioncounter) {

		if (microcounter==0) {
			singleStepForward();
		}

		microcounter++;
		if (microcounter >= microstepsperstep) {
			positioncounter++;
			microcounter=0;

			forgetAnimations();
			forgetSounds();
		}
	} else {
		return false;
	}
	return true;
}

bool Game::microStepBackward ()
{
	doLog (4, "doing single backward step: %d/%d", positioncounter, microcounter);

	if (microcounter>0) {
		microcounter--;
		if (microcounter==0) {
			forgetAnimations();
			nStepsFromBegin (positioncounter);
		}
	} else {
		if (positioncounter>0) {
			nStepsFromBegin (positioncounter-1);
			singleStepForward();

			forgetSounds();

			microcounter=microstepsperstep-1;
		} else {
			return false;
		}
	}
	return true;
}

bool Game::microStepDelete ()
{
	if (microStepBackward()) {

		if (microcounter==0) {
			for (int c=0; c<thiswalk.channelnum; c++) {
				thiswalk.cutOneMove (c, positioncounter);
			}
		}

		return true;
	}
	return false;
}

bool Game::fastForward ()
{
	if (thiswalk.numberOfMoves() > positioncounter) {
		if (microcounter>0) {
			microcounter=0;
			positioncounter++;
		} else {
			singleStepForward();
			positioncounter++;

			forgetAnimations();
			forgetSounds();
		}
	} else {
		return false;
	}
	return true;
}

bool Game::fastBackward ()
{
	if (microcounter>0) {
		nStepsFromBegin (positioncounter);
		microcounter=0;
	} else {
		if (positioncounter>0) {
			nStepsFromBegin (positioncounter-1);
		} else {
			return false;
		}
	}
	return true;
}


void Game::nStepsFromBegin (int steps)
{
	for (int s=steps; s>=0; s--) {
		if (checkpoints.size()>s && checkpoints[s]) {
			checkpoints[s]->reactivate (this);
			goto foundone;
		}
	}
	resetLogic();
foundone:

	while (positioncounter<steps) {
		singleStepForward();
		forgetAnimations();

		positioncounter++;
	}
	forgetSounds();
}

void Game::singleStepForward ()
{
	doLog (4, "doing single step: %d", positioncounter);

	// remember checkpoints
	setCheckPointIfNeeded();

	static vector<Player*> sortedplayers;
	int sumx=0;
	int sumy=0;
	int i,j;
	Player* dummy;

	// remember, if the game was lost already
	bool alreadylost = isLost();

	// set up initial state of the sorted player list
	sortedplayers.resize(players.size());
	for (int pidx=0; pidx<players.size(); pidx++) sortedplayers[pidx]=players[pidx];

	// compute arithmetic midpoint of all players
	for (i=0; i<players.size(); i++) {
		sumx += players[i]->xpos;
		sumy += players[i]->ypos;
	}

	// compute a deterministic value, how fast the player runs away
	// from the other(s)
	for (i=0; i<players.size(); i++) {
		Player* p = players[i];
		int px = 0, py = 0;

		switch (thiswalk.getMove (p->channel, positioncounter) ) {
		case moveup:    case grabup:      case bombup:     py=-1; break;
		case movedown:  case grabdown:    case bombdown:   py=1; break;
		case moveleft:  case grableft:    case bombleft:   px=-1; break;
		case moveright: case grabright:   case bombright:  px=1; break;
		}
		p->runawayspeed = (p->xpos*players.size() - sumx) * px
			            + (p->ypos*players.size() - sumy) * py;
	}

	// compute a correct player movement order (away running move first)
	for (i=0; i<sortedplayers.size()-1; i++) {
		for (j=i+1; j<sortedplayers.size(); j++) {
			if (sortedplayers[i]->runawayspeed < sortedplayers[j]->runawayspeed) {
				dummy = sortedplayers[i];
				sortedplayers[i] = sortedplayers[j];
				sortedplayers[j] = dummy;
			}
		}
	}

	// do player movement in right order
	for (i=0; i<sortedplayers.size(); i++) {
		moveplayer (sortedplayers[i]);
	}


	// after this, do movement of the pieces
	movepieces();


	// check, if game has been won, and emmit a sound if it happened
	if (gamewintime<0 && isDone()) {
		gamewintime = positioncounter;
	}
	if (gamewintime>=0 && positioncounter == gamewintime+WINSOUNDDELAY) {
		addSound (snd_win);
	}

	// check, if game has been lost, and emmit a sound if it happened
	if (!alreadylost && isLost()) {
		addSound (snd_lose);
	}
}

void Game::cutWalkthrough()
{
	thiswalk.cut(positioncounter);	
	flushCheckPoints(positioncounter);
}

bool Game::endOfWalkthrough()
{
	if (positioncounter >= thiswalk.numberOfMoves()) return true;
	return false;
}

void Game::setWriteCursor()
{
	for (int c=0; c<thiswalk.channelnum; c++) {
		thiswalk.setWriteCursor (c, positioncounter);
	}
}

bool Game::deleteWriteBuffers()
{
	bool anydelete=false;

	flushCheckPoints(positioncounter);

	for (int c=0; c<thiswalk.channelnum; c++) {
		int wc;
		while ( (wc = thiswalk.getWriteCursor(c)) > positioncounter) {
			thiswalk.cutOneMove (c,wc-1);
			anydelete=true;
		}
	}
	return anydelete;
}

void Game::insertRests()
{
	flushCheckPoints(positioncounter);

	thiswalk.insertRests();
}

bool Game::isDone()
{
	for (int p=0; p<players.size(); p++) {
		if (! (players[p]->done)) return false;
	}
	return true;
}

bool Game::isDone(int channel)
{
	for (int pidx=0; pidx<players.size(); pidx++) {
		Player*p = players[pidx];
		if (p->channel != channel) continue;
		if (!p->done) return false;
	}
	return true;
}

bool Game::isLost()
{
	if (level->emeraldsdestructable<0) return false;
	return emeraldsdestroyed > level->emeraldsdestructable;
}

bool Game::isDead()
{
	for (int p=0; p<players.size(); p++) {
		if (! (players[p]->dead)) return false;
	}
	return true;
}

// ----------- pure game logic for one single step -------------


void Game::lock (int x, int y)
{
	if (islocked[x][y] < normallocked) islocked[x][y] = normallocked;
}

void Game::diglock (int x, int y)
{
	if (islocked[x][y] < diglocked) islocked[x][y] = diglocked;
}


void Game::followlaser (int startx, int starty, int startdx, int startdy)
{
	int x=startx;
	int y=starty;
	int dx=startdx;
	int dy=startdy;
	int length=100000;
	int dummy;

	do {

		piecetype p = piece[x][y];
		if (length<=0) {
			doLog (2, "maximum laser length exeeded");
			return;
		}
		length--;

		switch (p) {
		case emerald:
		case emerald_falling:
			if (dy==0) {
				if (dx==-1) addTOPAnimation (seq_laserbr, x,y, 0,0);
				else		addTOPAnimation (seq_lasertl, x,y, 0,0);
			} else {
				if (dy==-1) addTOPAnimation (seq_laserbl, x,y, 0,0);
				else        addTOPAnimation (seq_lasertr, x,y, 0,0);
			}

			dummy = dx;
			dx = dy;
			dy = -dummy;
			x+=dx;
			y+=dy;
			break;

		case sapphire:
		case sapphire_falling:
			if (dy==0) {
				if (dx==-1) addTOPAnimation (seq_lasertr, x,y, 0,0);
				else		addTOPAnimation (seq_laserbl, x,y, 0,0);
			} else {
				if (dy==-1) addTOPAnimation (seq_laserbr, x,y, 0,0);
				else        addTOPAnimation (seq_lasertl, x,y, 0,0);
			}

			dummy = dx;
			dx = -dy;
			dy = dummy;
			x+=dx;
			y+=dy;
			break;

		case ruby:
		case ruby_falling:
			addTOPAnimation ( (dx==0) ? seq_laserv : seq_laserh, x,y, 0,0);

			x+=dx;
			y+=dy;
			break;

		case air:
		case bomb_explode:
		case bigbomb_explode:
		case yamyam_explode:
		case explode1: 
		case explode2:
		case explode3:
		case explode4:
			addTOPAnimation ( (dx==0) ? seq_laserv : seq_laserh, x,y, 0,0);
			x+=dx;
			y+=dy;
			break;

		case glasswall:
			addTOPAnimation ( (dx==0) ? seq_laserv : seq_laserh, x,y, 0,0);
			x+=dx;
			y+=dy;
			break;

		default:
			addexplosion (x,y, x,y, x,y, true);
			return;
		}

	} while (x!=startx || y!=starty || dx!=startdx || dy!=startdy);
}


void Game::laserbeam (int startx, int starty, int centerx, int centery)
{
	int d;

	if (startx==centerx) {  // vertical laser beam
		if (starty==centery) return;
		if (starty<centery) d=-1; // laser upwards
		else                d=1;  // laser downwards
		
		followlaser (startx,starty+d, 0,d);
	    if (!level->silentlaser) addSound (startx, starty, snd_laser);
	}
	if (starty==centery) { // horizontal laser beam
		if (startx==centerx) return;
		if (startx<centerx) d=-1; // laser left
		else                d=1;  // laser right
		
		followlaser (startx+d,starty, d,0);
		if (!level->silentlaser) addSound (startx, starty, snd_laser);
	}
}

void Game::addexplosion (int x1,int y1,int x2,int y2, int centerx, int centery, 
				   bool yamyamtriggered)
{
	int x,y;
	int olddestroyed = emeraldsdestroyed;
	
	if (x1<0) x1=0;
	if (y1<0) y1=0;
	if (x2>=level->width) x2=level->width-1;
	if (y2>=level->height) y2=level->height-1;

	for (x=x1; x<=x2; x++) {
		for (y=y1;y<=y2;y++) {
		 emeraldsdestroyed += piecevalue (explosionrest[x][y]);
         explosionrest[x][y] = air;

         switch (piece[x][y]) {
         case wall:
		 case glasswall:
		 case outlineborder: 
			 goto dontkill;


		 case bomb_explode:
		 case bigbomb_explode:
		 case yamyam_explode: 
		 case bug_explode:
			 goto dontkill;

         case bomb:
		 case bomb_falling:
		 case timebomb:
         case activebomb0: case activebomb1: case activebomb2: case activebomb3:
		 case activebomb4: case activebomb5:
         case lorryleft: case lorryleft_fixed:
         case lorryright: case lorryright_fixed:
         case lorryup: case lorryup_fixed:
         case lorrydown: case lorrydown_fixed:
             piece[x][y] = bomb_explode;
			 lock (x,y);
             addFGAnimation (seq_explode1, x,y, 0,0);
             goto dontkill;
		 case timebomb10:
             piece[x][y] = bigbomb_explode;
			 lock (x,y);
             addFGAnimation (seq_explode1, x,y, 0,0);
             goto dontkill;

         case bugleft: case bugleft_fixed:
         case bugright: case bugright_fixed:
         case bugup: case bugup_fixed:
         case bugdown: case bugdown_fixed:
             piece[x][y] = bug_explode;
			 lock (x,y);
             addFGAnimation (seq_explode1, x,y, 0,0);
             goto dontkill;

         case yamyamleft: case yamyamright: case yamyamup: case yamyamdown: 
             piece[x][y] = yamyam_explode;
			 lock (x,y);
             addFGAnimation (seq_explode1, x,y, 0,0);
             goto dontkill;

         case man1: case man2: 
			 {
			 for (int i=0; i<players.size(); i++) {
                 if ((players[i]->xpos == x) && (players[i]->ypos == y)) {
                       players[i]->dead = true;
                       addSound (x,y, snd_die);
                 }
			 }
			 }
			 break;

         case wallemerald: 
			 explosionrest[x][y] = emerald;
			 emeraldsdestroyed--;
			 break;

         case box: 
			 explosionrest[x][y] = bag;
			 emeraldsdestroyed--;
			 break;

		 case ruby:
		 case ruby_falling:
			 laserbeam (x,y, centerx, centery);
			 goto dontkill;
		 }

		 emeraldsdestroyed += piecevalue (piece[x][y]);

         piece[x][y] = explode1;
		 lock (x,y);
         addFGAnimation (seq_explode1, x,y, 0,0);

      dontkill: 1;

		}
	}

    if (!(yamyamtriggered && level->silentlaser)) addSound ((x1+x2)/2, (y1+y2)/2, snd_explode);

	if (olddestroyed != emeraldsdestroyed) addSound ((x1+x2)/2, (y1+y2)/2, snd_blastvip);
}



void Game::totalexplode (int x1, int y1, int x2, int y2)
{
	int x,y;

	for (x=x1; x<=x2; x++) {
		for (y=y1;y<=y2;y++) {
			int v = piecevalue (explosionrest[x][y]);
			emeraldsdestroyed += v;
			if (v>0) addSound (x,y, snd_blastvip);
			explosionrest[x][y] = air;

			switch (piece[x][y]) {
			case wall:
			case glasswall:
			case ruby:
			case ruby_falling:
			    piece[x][y] = explode1;
				lock (x,y);
				addFGAnimation (seq_explode1, x,y, 0,0);
				break;
			default:
				break;
			}
		}
	}
}



void Game::ignite (int x, int y)
{
	int x2,y2;

	switch (piece[x][y]) {
	case bomb_falling:
	case bomb: 
		piece[x][y] = bomb_explode;
		lock (x,y);
        addFGAnimation (seq_explode1, x,y, 0,0);
		break;
	case lorryleft: case lorryleft_fixed:
    case lorryright: case lorryright_fixed:
    case lorryup: case lorryup_fixed:
    case lorrydown: case lorrydown_fixed:
		piece[x][y] = air;
		addexplosion (x-1,y-1,x+1,y+1, x,y, false);
		break;

	case bugleft: case bugleft_fixed:
    case bugright: case bugright_fixed:
    case bugup: case bugup_fixed:
    case bugdown: case bugdown_fixed: case bug_explode:
		piece[x][y] = air;
        addexplosion (x-1,y-1,x+1,y+1, x,y, true);
        for (x2=0;x2<3;x2++) {
			for (y2=0;y2<3;y2++) {
				if (piece[x][y] == explode1) {
					int v = piecevalue (explosionrest[x+x2-1][x+y2-1]);
					emeraldsdestroyed += v;
					if (v>0) addSound (x,y, snd_blastvip);
					explosionrest[x+x2-1][y+y2-1] = (x2==1 && y2==1) ? sapphire : emerald;
				}
			}
		}
		break;

	case yamyamleft: case yamyamright: case yamyamup: case yamyamdown: 
	case yamyam_explode: 
		piece[x][y] = air;
        addexplosion (x-1,y-1,x+1,y+1, x,y, true);
		
        for (x2=0;x2<3;x2++) {
			for (y2=0;y2<3;y2++) {
				if (piece[x][y] == explode1) {
					int v = piecevalue (explosionrest[x+x2-1][y+y2-1]);
					emeraldsdestroyed += v;
					if (v>0) addSound (x,y, snd_blastvip);
					explosionrest[x+x2-1][y+y2-1] =
						(yamyamskilled<level->yamyaminfo.size())
					   ? level->yamyaminfo[yamyamskilled].piece[x2][y2]
					   : emerald;
				}
			}
		}
		// if we reached last yamyam, we keep producing its pieces 
        if (yamyamskilled+1 < level->yamyaminfo.size()) yamyamskilled++;
		break;
	}
}

void Game::pickup (Player* p, int x, int y)
{
	switch (piece[x][y]) {
    case emerald: 
           addFGAnimation (seq_emeraldaway, x,y, 0,0);
           emeraldsneeded--;
           addSound (x,y,snd_grabemld);
		   break;
    case sapphire: 
           addFGAnimation (seq_sapphireaway, x,y, 0,0);
           emeraldsneeded-=3;
           addSound (x,y,snd_grabsphr);
		   break;
	case ruby:
           addFGAnimation (seq_rubyaway, x,y, 0,0);
		   emeraldsneeded-=5;
		   addSound (x,y,snd_grabruby);
		   break;
    case timebomb:
           p->bombsready++;
           addSound (x,y,snd_grabbomb);
           break;
    case timebomb10:
           p->bombsready += 10;
           addSound (x,y,snd_grabbomb);
           break;
    case keyblue: 
           p->havebluekey = true;
           addSound (x,y,snd_grabkey);
           break;
    case keyred: 
           p->haveredkey = true;
           addSound (x,y,snd_grabkey);
           break;
    case keygreen: 
           p->havegreenkey = true;
           addSound (x,y,snd_grabkey);
           break;
    case keyyellow: 
		   p->haveyellowkey = true;
           addSound (x,y,snd_grabkey);
           break;
    };

       // add time bonus for all additionally collected gems 
    if (emeraldsneeded < 0) {
		if (availabletime > 0) {
			availabletime -= (emeraldsneeded * BONUSTURNS);
		}
		emeraldsneeded = 0;
    }
}

void Game::startwheel(int piecex, int piecey)
{
	if (piece[piecex][piecey]==wheel) {
		wheelendtime = positioncounter + level->wheelturntime;
		wheelx = piecex;
		wheely = piecey;
	}
}

bool Game::willfallin (int piecex, int piecey, int holex, int holey)
{
	switch (piece[holex][holey]) {
	case air:
	case acid:	return true;

	case converter:
		if (piece[holex][holey+1] == air) {
			switch (piece[piecex][piecey]) {
			case emerald:
			case sapphire:
			case stone:
			case bag:
			case ruby:	return true;
			}
		}
		break;
	}
	return false;
}

void Game::turnfalling (int x, int y)
{
	if (willfallin(x,y, x,y+1)) {
		switch (piece[x][y]) {
		case stone:     piece[x][y] = stone_falling; break;
		case bag:       piece[x][y] = bag_falling; break;
		case bomb:      piece[x][y] = bomb_falling; break;
		case emerald:   piece[x][y] = emerald_falling; break;
		case sapphire:  piece[x][y] = sapphire_falling; break;
		case ruby:      piece[x][y] = ruby_falling; break;
		}
	}
}




void Game::animatePlayer (Player* p, sequencetype seq, int dx, int dy, bool foreground)
{
	if (foreground)	addFGAnimation (seq, p->xpos, p->ypos, dx,dy);
	        else    addBGAnimation (seq, p->xpos, p->ypos, dx,dy);
	piece[p->xpos][p->ypos] = air;
	p->xpos += dx;
	p->ypos += dy;
	piece[p->xpos][p->ypos] = p->piece;
	lock(p->xpos,p->ypos);
	p->previoussequence = seq;
}

void Game::moveplayer(Player* p)
{
	int xpos,ypos;

	p->previoussequence = p->seq_rest;
	xpos = p->prevxpos = p->xpos;
	ypos = p->prevypos = p->ypos;


	// check, if there are some reasons, why movement is not possible
	if (p->dead || p->done) return;

    if ( (positioncounter>=availabletime && availabletime > 0)
	||   (level->availablemoves>=0 && movecounter>=level->availablemoves) )
	{
		addexplosion (xpos,ypos, xpos, ypos, xpos,ypos, false);
		return;
	}

   // move player 
	movetype m = thiswalk.getMove (p->channel, positioncounter);
	
	switch (m) {

    case moveup:  
	case bombup:
	   switch (piece[xpos][ypos-1]) {
       case door_opened: 
              piece[xpos][ypos] = air;
              piece[xpos][ypos-1] = door_closing;
			  lock (xpos,ypos-1);
			  addFGAnimation (seq_doorisopen, xpos,ypos-1, 0,0);
              addFGAnimation (p->seq_walkup, xpos,ypos, 0,-1);
              p->ypos --;
              p->done = true;
              addSound (xpos,ypos, snd_walk);
              goto movedone;
       case air: 
			  animatePlayer (p, p->seq_walkup, 0,-1);
              addSound (xpos,ypos, snd_walk);
              goto movedone;
       CASEPICKUP
              pickup (p, xpos, ypos-1);
			  animatePlayer (p, p->seq_walkup, 0,-1);
              goto movedone;
        case earth: 
              addFGAnimation (seq_earthup, xpos,ypos-1, 0,0);
			  animatePlayer (p, p->seq_digup, 0,-1);
			  diglock (xpos,ypos-1);
              addSound (xpos,ypos, snd_dig);
              goto movedone;
        case doorblue:
		case doorred:
		case doorgreen:
		case dooryellow:
			if ((piece[xpos][ypos-2] == air) && p->hasKeyFor(piece[xpos][ypos-1])) {
				animatePlayer (p, p->seq_walkup, 0,-2, true);
				switch (piece[xpos][ypos-1]) {
				case doorblue:   addFGAnimation (seq_doorblue, xpos,ypos-1, 0,0); break;
				case doorred:    addFGAnimation (seq_doorred, xpos,ypos-1, 0,0); break;
				case doorgreen:  addFGAnimation (seq_doorgreen, xpos,ypos-1, 0,0); break;
				case dooryellow: addFGAnimation (seq_dooryellow, xpos,ypos-1, 0,0); break;
				}
				lock (xpos,ypos-1);
				addSound (xpos,ypos, snd_usedoor);
				goto movedone;
			}
			break;
        case box: 
			if (piece[xpos][ypos-2] == air && !israndom(level->pushprob)) {
				piece[xpos][ypos-2] = box;
				lock (xpos,ypos-2);
				addFGAnimation (seq_box, xpos,ypos-1, 0,-1);
				animatePlayer (p, p->seq_pushup, 0,-1);
                addSound(xpos,ypos, snd_pushbox);
			} else {
                animatePlayer (p, p->seq_pushup, 0,0);
            }
			goto movedone;
        case cushion: 
			if (piece[xpos][ypos-2] == air && !israndom(level->pushprob)) {
                 piece[xpos][ypos-2] = cushion;
				 lock (xpos, ypos-2);
                 addFGAnimation (seq_cushion, xpos,ypos-1, 0,-1);
                 animatePlayer (p, p->seq_pushup, 0,-1);
                 addSound(xpos,ypos, snd_pcushion);
			} else {
                 animatePlayer (p, p->seq_pushup, 0,0);
            }
			goto movedone;
		case wheel:
			startwheel (xpos,ypos-1);
			goto movedone;
	   } // end switch 
	   break; // moveup

    case movedown:  
	case bombdown:
	   switch (piece[xpos][ypos+1]) {
       case door_opened: 
              piece[xpos][ypos] = air;
              piece[xpos][ypos+1] = door_closing;
			  lock (xpos, ypos+1);
			  addFGAnimation (seq_doorisopen, xpos,ypos+1, 0,0);
              addFGAnimation (p->seq_walkdown, xpos,ypos, 0,+1);
              p->ypos++;
              p->done = true;
              addSound (xpos,ypos, snd_walk);
              goto movedone;
       case air: 
			  animatePlayer (p, p->seq_walkdown, 0,1);
              addSound (xpos,ypos, snd_walk);
              goto movedone;
       CASEPICKUP
              pickup (p, xpos, ypos+1);
			  animatePlayer (p, p->seq_walkdown, 0,1);
              goto movedone;
        case earth: 
              addFGAnimation (seq_earthdown, xpos,ypos+1, 0,0);
			  animatePlayer (p, p->seq_digdown, 0,1);
			  diglock (xpos,ypos+1);
              addSound (xpos,ypos, snd_dig);
              goto movedone;
        case doorblue:
		case doorred:
		case doorgreen:
		case dooryellow:
			if ((piece[xpos][ypos+2] == air) && p->hasKeyFor(piece[xpos][ypos+1])) {
				animatePlayer (p, p->seq_walkdown, 0,2, true);
				switch (piece[xpos][ypos+1]) {
				case doorblue:   addFGAnimation (seq_doorblue, xpos,ypos+1, 0,0); break;
				case doorred:    addFGAnimation (seq_doorred, xpos,ypos+1, 0,0); break;
				case doorgreen:  addFGAnimation (seq_doorgreen, xpos,ypos+1, 0,0); break;
				case dooryellow: addFGAnimation (seq_dooryellow, xpos,ypos+1, 0,0); break;
				}
				lock (xpos,ypos+1);
				addSound (xpos,ypos, snd_usedoor);
				goto movedone;
			}
			break;
        case box: 
			if (piece[xpos][ypos+2] == air && !israndom(level->pushprob)) {
				piece[xpos][ypos+2] = box;
				lock (xpos,ypos+2);
				addFGAnimation (seq_box, xpos,ypos+1, 0,1);
				animatePlayer (p, p->seq_pushdown, 0,1);
                addSound(xpos,ypos, snd_pushbox);
			} else {
                animatePlayer (p, p->seq_pushdown, 0,0);
            }
			goto movedone;
        case cushion: 
			if (piece[xpos][ypos+2] == air && !israndom(level->pushprob)) {
                 piece[xpos][ypos+2] = cushion;
				 lock (xpos, ypos+2);
                 addFGAnimation (seq_cushion, xpos,ypos+1, 0,1);
                 animatePlayer (p, p->seq_pushdown, 0,1);
                 addSound(xpos,ypos, snd_pcushion);
			} else {
                 animatePlayer (p, p->seq_pushdown, 0,0);
            }
			goto movedone;
		case wheel:
			startwheel (xpos,ypos+1);
			goto movedone;
	   } // end switch 
	   break; // movedown


    case moveleft:
	case bombleft:
	   switch (piece[xpos-1][ypos]) {
       case door_opened: 
              piece[xpos][ypos] = air;
              piece[xpos-1][ypos] = door_closing;
			  lock (xpos-1,ypos);
			  addFGAnimation (seq_doorisopen, xpos-1,ypos, 0,0);
              addFGAnimation (p->seq_walkleft, xpos,ypos, -1,0);
              addSound (xpos,ypos, snd_walk);
              p->xpos--;
              p->done = true;
              goto movedone;
        case air: 
			  animatePlayer (p, p->seq_walkleft, -1,0);
			  addSound(xpos,ypos, snd_walk);
              goto movedone;
       CASEPICKUP
              pickup (p,xpos-1, ypos);
				animatePlayer (p, p->seq_walkleft, -1,0);
              goto movedone;
        case earth: 
              addFGAnimation (seq_earthleft, xpos-1,ypos, 0,0);
			  animatePlayer (p, p->seq_digleft, -1,0);
			  diglock (xpos-1,ypos);
              addSound (xpos,ypos, snd_dig);
              goto movedone;
        case stone:
              if ( (piece[xpos-2][ypos] == air) &&
                 (! israndom(level->pushprob)) ) {
                 piece[xpos-2][ypos] = stone;
				 turnfalling (xpos-2,ypos);
				 lock (xpos-2,ypos);
                 addFGAnimation (seq_stoneleft, xpos-1, ypos, -1,0);
				 animatePlayer (p, p->seq_pushleft, -1,0);
                 addSound(xpos,ypos, snd_push);
              } else {
                 animatePlayer (p, p->seq_pushleft, 0,0);
              }
              goto movedone;

        case bag: 
              if ( (piece[xpos-2][ypos] == air) &&
                 (! israndom(level->pushprob)) ) {
                 piece[xpos-2][ypos] = bag;
				 turnfalling (xpos-2,ypos);
				 lock (xpos-2,ypos);
                 addFGAnimation (seq_bagleft, xpos-1, ypos, -1,0);
				 animatePlayer (p, p->seq_pushleft, -1,0);
                 addSound(xpos,ypos, snd_pushbag);
              } else {
                 animatePlayer (p, p->seq_pushleft, 0,0);
              }
              goto movedone;

        case bomb: 
              if ( (piece[xpos-2][ypos] == air) &&
                 (! israndom(level->pushprob)) ) {
                 piece[xpos-2][ypos] = bomb;
				 turnfalling (xpos-2,ypos);
				 lock (xpos-2,ypos);
                 addFGAnimation (seq_bombleft, xpos-1, ypos, -1,0);
				 animatePlayer (p, p->seq_pushleft, -1,0);
                 addSound(xpos,ypos, snd_pushbomb);
              } else {
                 animatePlayer (p, p->seq_pushleft, 0,0);
              }
              goto movedone;

        case doorblue:
		case doorred:
		case doorgreen:
		case dooryellow:
			if ( (piece[xpos-2][ypos] == air) && p->hasKeyFor(piece[xpos-1][ypos])) {
    			animatePlayer (p, p->seq_walkleft, -2,0, true);
				switch (piece[xpos-1][ypos]) {
				case doorblue:   addFGAnimation (seq_doorblue, xpos-1,ypos, 0,0); break;
				case doorred:    addFGAnimation (seq_doorred, xpos-1,ypos, 0,0); break;
				case doorgreen:  addFGAnimation (seq_doorgreen, xpos-1,ypos, 0,0); break;
				case dooryellow: addFGAnimation (seq_dooryellow, xpos-1,ypos, 0,0); break;
				}
				lock (xpos-1,ypos);
  				addSound (xpos,ypos, snd_usedoor);
              goto movedone;
			}
			break;

        case box: 
			if ( (piece[xpos-2][ypos] == air) && (! israndom(level->pushprob)) ) {
                 piece[xpos-2][ypos] = box;
				 lock (xpos-2,ypos);
				 addFGAnimation (seq_box, xpos-1,ypos, -1,0);
				 animatePlayer (p, p->seq_pushleft, -1,0);
                 addSound(xpos,ypos, snd_pushbox);
			} else {
				 animatePlayer (p, p->seq_pushleft, 0,0);
            }
            goto movedone;

        case cushion: 
			if ( (piece[xpos-2][ypos] == air) && (! israndom(level->pushprob)) ) {
                 piece[xpos-2][ypos] = cushion;
				 lock (xpos-2,ypos);
				 addFGAnimation (seq_cushion, xpos-1,ypos, -1,0);
				 animatePlayer (p, p->seq_pushleft, -1,0);
                 addSound(xpos,ypos, snd_pcushion);
			} else {
				 animatePlayer (p, p->seq_pushleft, 0,0);
            }
            goto movedone;
		case wheel:
			startwheel (xpos-1,ypos);
			goto movedone;
		} // end switch
		break; // moveleft


    case moveright:
	case bombright:
	   switch (piece[xpos+1][ypos]) {
       case door_opened: 
              piece[xpos][ypos] = air;
              piece[xpos+1][ypos] = door_closing;
			  lock (xpos+1,ypos);
			  addFGAnimation (seq_doorisopen, xpos+1,ypos, 0,0);
              addFGAnimation (p->seq_walkright, xpos,ypos, 1,0);
              addSound (xpos,ypos, snd_walk);
              p->xpos++;
              p->done = true;
              goto movedone;
        case air: 
				animatePlayer (p, p->seq_walkright, 1,0);
			  addSound(xpos,ypos, snd_walk);
              goto movedone;
       CASEPICKUP
              pickup (p,xpos+1, ypos);
				animatePlayer (p, p->seq_walkright, 1,0);
              goto movedone;
        case earth: 
              addFGAnimation (seq_earthright, xpos+1,ypos, 0,0);
			  animatePlayer (p, p->seq_digright, 1,0);
			  diglock (xpos+1,ypos);
              addSound (xpos,ypos, snd_dig);
              goto movedone;
        case stone:
              if ( (piece[xpos+2][ypos] == air) &&
                 (! israndom(level->pushprob)) ) {
                 piece[xpos+2][ypos] = stone;
				 turnfalling (xpos+2,ypos);
				 lock (xpos+2,ypos);
                 addFGAnimation (seq_stoneright, xpos+1, ypos, 1,0);
				 animatePlayer (p, p->seq_pushright, 1,0);
                 addSound(xpos,ypos, snd_push);
              } else {
                 animatePlayer (p, p->seq_pushright, 0,0);
              }
              goto movedone;

        case bag: 
              if ( (piece[xpos+2][ypos] == air) &&
                 (! israndom(level->pushprob)) ) {
                 piece[xpos+2][ypos] = bag;
				 turnfalling (xpos+2,ypos);
				 lock (xpos+2,ypos);
                 addFGAnimation (seq_bagright, xpos+1, ypos, 1,0);
				 animatePlayer (p, p->seq_pushright, 1,0);
                 addSound(xpos,ypos, snd_pushbag);
              } else {
                 animatePlayer (p, p->seq_pushright, 0,0);
              }
              goto movedone;

        case bomb: 
              if ( (piece[xpos+2][ypos] == air) &&
                 (! israndom(level->pushprob)) ) {
                 piece[xpos+2][ypos] = bomb;
				 turnfalling (xpos+2,ypos);
				 lock (xpos+2,ypos);
                 addFGAnimation (seq_bombright, xpos+1, ypos, 1,0);
				 animatePlayer (p, p->seq_pushright, 1,0);
                 addSound(xpos,ypos, snd_pushbomb);
              } else {
                 animatePlayer (p, p->seq_pushright, 0,0);
              }
              goto movedone;

        case doorblue:
		case doorred:
		case doorgreen:
		case dooryellow:
			if ( (piece[xpos+2][ypos] == air) && p->hasKeyFor(piece[xpos+1][ypos])) {
    			animatePlayer (p, p->seq_walkright, 2,0, true);
				switch (piece[xpos+1][ypos]) {
				case doorblue:   addFGAnimation (seq_doorblue, xpos+1,ypos, 0,0); break;
				case doorred:    addFGAnimation (seq_doorred, xpos+1,ypos, 0,0); break;
				case doorgreen:  addFGAnimation (seq_doorgreen, xpos+1,ypos, 0,0); break;
				case dooryellow: addFGAnimation (seq_dooryellow, xpos+1,ypos, 0,0); break;
				}
				lock (xpos+1,ypos);
				addSound (xpos,ypos, snd_usedoor);
              goto movedone;
			}
			break;

        case box: 
			if ( (piece[xpos+2][ypos] == air) && (! israndom(level->pushprob)) ) {
                 piece[xpos+2][ypos] = box;
				 lock (xpos+2,ypos);
				 addFGAnimation (seq_box, xpos+1,ypos, 1,0);
				 animatePlayer (p, p->seq_pushright, 1,0);
                 addSound(xpos,ypos, snd_pushbox);
			} else {
				 animatePlayer (p, p->seq_pushright, 0,0);
            }
            goto movedone;

        case cushion: 
			if ( (piece[xpos+2][ypos] == air) && (! israndom(level->pushprob)) ) {
                 piece[xpos+2][ypos] = cushion;
				 lock (xpos+2,ypos);
				 addFGAnimation (seq_cushion, xpos+1,ypos, 1,0);
				 animatePlayer (p, p->seq_pushright, 1,0);
                 addSound(xpos,ypos, snd_pcushion);
			} else {
				 animatePlayer (p, p->seq_pushright, 0,0);
            }
            goto movedone;
		case wheel:
			startwheel (xpos+1,ypos);
			goto movedone;
		} // end switch
		break; // moveright


   case grabup:  
	   switch (piece[xpos][ypos-1]) {
       CASEPICKUP
              pickup (p, xpos,ypos-1);
              piece[xpos][ypos-1] = air;
              goto movedone;
        case earth: 
              piece[xpos][ypos-1] = air;
              addFGAnimation (seq_earthup, xpos,ypos-1, 0,0);
			  animatePlayer (p, p->seq_digup, 0,0);
			  diglock (xpos,ypos-1);
              addSound (xpos,ypos, snd_dig);
              goto movedone;
		case wheel:
			startwheel (xpos,ypos-1);
			goto movedone;
	   }
		break;

   case grabdown:  
	   switch (piece[xpos][ypos+1]) {
       CASEPICKUP
              pickup (p, xpos,ypos+1);
              piece[xpos][ypos+1] = air;
              goto movedone;
        case earth: 
              piece[xpos][ypos+1] = air;
              addFGAnimation (seq_earthdown, xpos,ypos+1, 0,0);
			  animatePlayer (p, p->seq_digdown, 0,0);
			  diglock (xpos,ypos+1);
              addSound (xpos,ypos, snd_dig);
              goto movedone;
		case wheel:
			startwheel (xpos,ypos+1);
			goto movedone;
	   }
		break;

   case grableft:  
	   switch ( piece[xpos-1][ypos] ) {
       CASEPICKUP
              pickup (p, xpos-1, ypos);
              piece[xpos-1][ypos] = air;
              goto movedone;
        case earth:
              piece[xpos-1][ypos] = air;
              addFGAnimation (seq_earthleft, xpos-1,ypos, 0,0);
			  animatePlayer (p, p->seq_digleft, 0,0);
			  diglock (xpos-1,ypos);
              addSound (xpos,ypos, snd_dig);
              goto movedone;
		case wheel:
			startwheel (xpos-1,ypos);
			goto movedone;
	   }
		break;

   case grabright:  
	   switch (piece[xpos+1][ypos]) {
       CASEPICKUP
              pickup (p, xpos+1, ypos);
              piece[xpos+1][ypos] = air;
              goto movedone;
        case earth: 
              piece[xpos+1][ypos] = air;
              addFGAnimation (seq_earthright, xpos+1,ypos, 0,0);
			  animatePlayer (p, p->seq_digright, 0,0);
			  diglock (xpos+1,ypos);
              addSound (xpos,ypos, snd_dig);
              goto movedone;
		case wheel:
			startwheel (xpos+1,ypos);
			goto movedone;
	   }
		break;

	}  // end of direction switch


	// set animation sequence if nothing else happens
	if (truerandom(10)) {
		animatePlayer (p, p->seq_blink, 0,0);
	}

movedone:
    if ( (m==bombup || m==bombdown || m==bombleft || m==bombright)
		&& ((xpos!=p->xpos) || (ypos!=p->ypos))
		&& (p->bombsready>0) && (piece[xpos][ypos] == air)) {
       p->bombsready--;
       piece[xpos][ypos] = activebomb5;
	   lock (xpos,ypos);
       addFGAnimation (seq_tickbomb, xpos,ypos, 0,0);
       addSound (xpos,ypos, snd_setbomb);
    }


	if (m!=rest) movecounter++;
}


// --------------- MOVEMENT OF PIECES ---------------------


bool Game::blastifnear (int x, int y, bool onlymovingtargets) 
{
	piecetype allvictims[] = {man1,man2,swamp, air};
	piecetype movingvictims[] = {man1,man2, air};
	piecetype* victims = onlymovingtargets ? movingvictims : allvictims;
	int i;

    for (i=0; victims[i] != air; i++) {
      if ( (piece[x-1][y] == victims[i])
        || (piece[x+1][y] == victims[i])
        || (piece[x][y+1] == victims[i])
        || (piece[x][y-1] == victims[i]) ) {
         ignite (x,y);
		 return true;
	  };
	}
	return false;
}

bool Game::blastYamYamIfNecessary(int x, int y, int dx, int dy)
{
	if (piece[x-1][y]==swamp
	||  piece[x+1][y]==swamp
	||  piece[x][y+1]==swamp
	||  piece[x][y-1]==swamp

	||  piece[x+dx][y+dy]==man1
	||  piece[x+dx][y+dy]==man2) {
		ignite (x,y);
		return true;
	}
	return false;
}

piecetype Game::anyyamyam() 
{
	switch (myrnd(4)) {
	case 0:   return yamyamleft;
    case 1:   return yamyamright;
    case 2:   return yamyamup;
    case 3:   return yamyamdown;
    default:  return bomb_explode;   // should not happen! 
	}
}


bool Game::robottarget (int px, int py)
{
	switch (piece[px][py]) {
	CASEMAN
	case air:    return true;
	default:	return false;
	}
}

void Game::robotmovedir (int x, int y, int& dx, int &dy)
{
	int tx=x;
	int ty=y;
	int tdist=9999999;

	for (int pidx=0; pidx<players.size(); pidx++) {
		Player* p = players[pidx];
		if (p->dead || p->done) continue;
		
		int distx = x-p->xpos;  if (distx<0) distx=-distx;
		int disty = y-p->ypos;  if (disty<0) disty=-disty;
		int dist = (distx < disty) ? distx : disty;
		
		if (dist<tdist) {
			tdist=dist;
			tx=p->xpos;
			ty=p->ypos;
		}
	}

	if (wheelendtime>positioncounter && piece[wheelx][wheely]==wheel) {
		tx=wheelx;
		ty=wheely;
	}

	int distx = x-tx;  if (distx<0) distx=-distx;
	int disty = y-ty;  if (disty<0) disty=-disty;

	if (distx>disty) {  // first attempt: go to left or right 
		if (tx<x) { // go to left
			if (robottarget(x-1,y)) { dx=-1; dy=0; return; }
		} else if (tx>x) { // go to right
			if (robottarget(x+1,y)) { dx=1; dy=0; return; }
		}
	}

	if (ty<y) {	 // can not go there, so try up/down (as first or second attempt)
		if (robottarget(x,y-1)) { dx=0; dy=-1; return; }
	} else if (ty>y) {
		if (robottarget(x,y+1)) { dx=0; dy=1; return; }
	}

	if (tx<x) {	 // can not go there, so try up/down (as first or second attempt)
		if (robottarget(x-1,y)) { dx=-1; dy=0; return; }
	} else if (tx>x) {
		if (robottarget(x+1,y)) { dx=1; dy=0; return; }
	}

	dx=0;
	dy=0;
	return;
}
   
void Game::movepieces() 
{
	int wm2=level->width-2;
	int x,y;

	for (y=level->height-2; y>=1; y--) {
		for (x=1; x<=wm2; x++) {

			// if an object has already been moved in this turn, don't do it again
			if (islocked[x][y] && piece[x][y]!=cushion) continue;

			switch (piece[x][y]) {

            case stone:
					if (piece[x][y+1]==air) {
                        piece[x][y] = air;
                        piece[x][y+1] = stone_falling;
						lock (x,y+1);
                        addFGAnimation (seq_stonedown, x,y, 0,1);
                    } else if (isunsupporting(piece[x][y+1])) {
						if ( piece[x-1][y] == air && willfallin(x,y, x-1,y+1) ) {
                           piece[x][y] = air;
                           piece[x-1][y] = stone_falling;
	 					   lock (x-1,y);
                           addFGAnimation (seq_stoneleft, x,y, -1,0);
                           addSound (x,y,snd_stnroll);
						} else if ( piece[x+1][y] == air && willfallin(x,y, x+1,y+1)) {
                           piece[x][y] = air;
                           piece[x+1][y] = stone_falling;
	 					   lock (x+1,y);
                           addFGAnimation (seq_stoneright, x,y, 1,0);
                           addSound (x,y,snd_stnroll);
                        }
                    }
                break;

            case stone_falling:
					switch (piece[x][y+1]) {
	                case air: 
						piece[x][y] = air;
						piece[x][y+1] = stone_falling;
						lock (x,y+1);
						addFGAnimation (seq_stonedown, x,y, 0,1);
						break;
					CASELIVING
						piece[x][y] = air;
						addFGAnimation (seq_stonedown, x,y, 0,1);
						addexplosion (x,y+1, x,y+1, x,y+1, false);
						break;
					case bag: 
					case bag_falling:
						if (!willfallin (x,y+1, x,y+2) ) { // only open bag if lying on something
							if (! islocked[x][y+1]) {
								piece[x][y] = stone;
								piece[x][y+1] = emerald;
								lock(x,y+1);
								addFGAnimation (seq_bagexpl, x,y+1, 0,0);
								addSound (x,y,snd_bagopen);
							} else {
								piece[x][y] = stone;
								piece[x][y+1] = bag_opening;
								addSound (x,y,snd_stnhard);
							}
						}
						break;
					case sapphire: 
					case sapphire_falling:
						if (!willfallin (x,y+1, x,y+2)) { // only crush emerald if lying on something
							if (! islocked[x][y+1]) {
								piece[x][y] = air;
								piece[x][y+1] = stone;
							   lock (x,y+1);
								addFGAnimation (seq_sapphirebreak, x,y+1, 0,0);
								addFGAnimation (seq_stonedown, x,y, 0,1);
								addSound (x,y,snd_sphrbrk);
								emeraldsdestroyed+=3;
							} else {
								piece[x][y] = stone;
								piece[x][y+1] = sapphire_breaking;
				                addSound (x,y,snd_stnhard);
							}
						}
						break;

					case bomb: 
					case bomb_falling: 
						piece[x][y] = stone;
						ignite (x,y+1);
						break;

					case earth:
					case sand:
					case sand_full:
						piece [x][y] = stone;
						addSound (x,y,snd_stnfall);
						break;

					default:
						piece [x][y] = stone;
						addSound (x,y,snd_stnhard);
						break;
					} // end switch

				break;

            case emerald:
					if (piece[x][y+1] == air) {
                        piece[x][y] = air;
                        piece[x][y+1] = emerald_falling;
						lock (x,y+1);
                        addFGAnimation (seq_emeralddown, x,y, 0,1);
					} else if (isunsupporting(piece[x][y+1])) {
						if ( piece[x-1][y] == air && willfallin(x,y, x-1,y+1)) {
                           piece[x][y] = air;
                           piece[x-1][y] = emerald_falling;
						   lock (x-1,y);
                           addFGAnimation (seq_emeraldleft, x,y, -1,0);
						   addSound (x,y,snd_emldroll);
						} else if (piece[x+1][y] == air && willfallin (x,y, x+1,y+1)) {
                           piece[x][y] = air;
                           piece[x+1][y] = emerald_falling;
						   lock (x+1,y);
                           addFGAnimation (seq_emeraldright, x,y, 1,0);
						   addSound (x,y,snd_emldroll);
						} else {
							if (truerandom(20)) {
								lock (x,y);
								addFGAnimation (seq_emeraldglitter, x,y, 0,0);	
							}
						}
					}
				break;

			case emerald_falling:
					switch (piece[x][y+1]) {
					case air: 
						piece[x][y] = air;
						piece[x][y+1] = emerald_falling;
					    lock (x,y+1);
						addFGAnimation (seq_emeralddown, x,y, 0,1);
						break;
					CASELIVING
						piece[x][y] = air;
						addFGAnimation (seq_emeralddown, x,y, 0,1);
						addexplosion (x,y+1, x,y+1, x,y+1, false);
						break;

                    case bomb:                      
					case bomb_falling: 
						piece[x][y] = emerald;
						ignite (x,y+1);
						break;

					default:
						piece [x][y] = emerald;
						addSound (x,y,snd_emldfall);
					}
				break;


            case bag:
					if (piece[x][y+1] == air) {
                        piece[x][y] = air;
                        piece[x][y+1] = bag_falling;
					    lock (x,y+1);
                        addFGAnimation (seq_bagdown, x,y, 0,1);
					} else if (isunsupporting(piece[x][y+1])) {
						if ( piece[x-1][y] == air && willfallin (x,y, x-1,y+1)) {
                           piece[x][y] = air;
                           piece[x-1][y] = bag_falling;
						   lock (x-1,y);
                           addFGAnimation (seq_bagleft, x,y, -1,0);
						   addSound (x,y,snd_bagroll);
						} else if ( piece[x+1][y] == air && willfallin (x,y, x+1,y+1)) {
                           piece[x][y] = air;
                           piece[x+1][y] = bag_falling;
						   lock (x+1,y);
                           addFGAnimation (seq_bagright, x,y, 1,0);
						   addSound (x,y,snd_bagroll);
						}
					}
				break;

			case bag_falling:
					switch (piece[x][y+1]) {
					case air: 
						piece[x][y] = air;
						piece[x][y+1] = bag_falling;
					    lock (x,y+1);
						addFGAnimation (seq_bagdown, x,y, 0,1);
						break;
					CASELIVING
						piece[x][y] = air;
						addFGAnimation (seq_bagdown, x,y, 0,1);
						addexplosion (x,y+1, x,y+1, x,y+1, false);
						break;
                    case bomb:                      
					case bomb_falling: 
						piece[x][y] = bag;
						ignite (x,y+1);
						break;

					default:
						piece [x][y] = bag;
						addSound (x,y,snd_bagfall);
					}
				break;


            case bag_opening:
                  piece[x][y] = emerald;
				  lock (x,y);
                  addFGAnimation (seq_bagexpl, x,y, 0,0);
                  addSound (x,y,snd_bagopen);
                  break;

            case sapphire:
					if (piece[x][y+1] == air) {
                        piece[x][y] = air;
                        piece[x][y+1] = sapphire_falling;
					    lock (x,y+1);
                        addFGAnimation (seq_sapphiredown, x,y, 0,1);
					} else if (isunsupporting(piece[x][y+1])) {
						if (piece[x-1][y] == air && willfallin (x,y, x-1,y+1)) {
                           piece[x][y] = air;
                           piece[x-1][y] = sapphire_falling;
						   lock (x-1,y);
                           addFGAnimation (seq_sapphireleft, x,y, -1,0);
						   addSound (x,y,snd_sphrroll);
						} else if (piece[x+1][y] == air && willfallin(x,y,x+1,y+1) ) {
                           piece[x][y] = air;
                           piece[x+1][y] = sapphire_falling;
						   lock (x+1,y);
                           addFGAnimation (seq_sapphireright, x,y, 1,0);
						   addSound (x,y,snd_sphrroll);
						}
					}
				break;

			case sapphire_falling:
					switch (piece[x][y+1]) {
					case air: 
						piece[x][y] = air;
						piece[x][y+1] = sapphire_falling;
					    lock (x,y+1);
						addFGAnimation (seq_sapphiredown, x,y, 0,1);
						break;
					CASELIVING
						piece[x][y] = air;
						addFGAnimation (seq_sapphiredown, x,y, 0,1);
						addexplosion (x,y+1, x,y+1, x,y+1, false);
						break;
                    case bomb:                      
					case bomb_falling: 
						piece[x][y] = sapphire;
						ignite (x,y+1);
						break;
					
					default:
						piece [x][y] = sapphire;
						addSound (x,y,snd_sphrfall);
					}
				break;

			case sapphire_breaking:
				piece[x][y] = air;
				lock (x,y);
				addFGAnimation (seq_sapphirebreak, x,y, 0,0);
				addSound (x,y,snd_sphrbrk);
				emeraldsdestroyed+=3;
				break;

            case ruby:
					if (piece[x][y+1] == air) {
                        piece[x][y] = air;
                        piece[x][y+1] = ruby_falling;
					    lock (x,y+1);
                        addFGAnimation (seq_rubydown, x,y, 0,1);
					} else if (isunsupporting(piece[x][y+1])) {
						if ( piece[x-1][y] == air && willfallin (x,y, x-1,y+1)) {
                           piece[x][y] = air;
                           piece[x-1][y] = ruby_falling;
						   lock (x-1,y);
                           addFGAnimation (seq_rubyleft, x,y, -1,0);
						   addSound (x,y,snd_rubyroll);
						} else if ( piece[x+1][y] == air && willfallin (x,y, x+1,y+1)) {
                           piece[x][y] = air;
                           piece[x+1][y] = ruby_falling;
						   lock (x+1,y);
                           addFGAnimation (seq_rubyright, x,y, 1,0);
						   addSound (x,y,snd_rubyroll);
						}
					}
				break;

			case ruby_falling:
					switch (piece[x][y+1]) {
					case air: 
						piece[x][y] = air;
						piece[x][y+1] = ruby_falling;
					    lock (x,y+1);
						addFGAnimation (seq_rubydown, x,y, 0,1);
						break;
					CASELIVING
						piece[x][y] = ruby;
						addexplosion (x,y+1, x,y+1, x,y+1, false);
						break;

                    case bomb:                      
					case bomb_falling: 
						piece[x][y] = ruby;
						ignite (x,y+1);
						break;

					default:
						piece [x][y] = ruby;
						addSound (x,y,snd_rubyfall);
					}
				break;


            case bomb:
					if (piece[x][y+1] == air) {
                        piece[x][y] = air;
                        piece[x][y+1] = bomb_falling;
					    lock (x,y+1);
                        addFGAnimation (seq_bombdown, x,y, 0,1);
					} else if (isunsupporting(piece[x][y+1])) {
						if ( piece[x-1][y] == air && willfallin (x,y, x-1,y+1) ) {
                           piece[x][y] = air;
                           piece[x-1][y] = bomb_falling;
						   lock (x-1,y);
                           addFGAnimation (seq_bombleft, x,y, -1,0);
						   addSound (x,y,snd_bombroll);
						} else if ( piece[x+1][y] == air && willfallin (x,y, x+1,y+1) ) {
                           piece[x][y] = air;
                           piece[x+1][y] = bomb_falling;
						   lock (x+1,y);
                           addFGAnimation (seq_bombright, x,y, 1,0);
						   addSound (x,y,snd_bombroll);
						}
					}
				break;

            case bomb_falling:
					switch (piece[x][y+1]) {
                    case air: 
                       piece[x][y] = air;
                       piece[x][y+1] = bomb_falling;
					   lock (x,y+1);
                       addFGAnimation (seq_bombdown, x,y, 0,1);
                       break;
					CASELIVING
						piece[x][y] = air;
						addexplosion (x-1,y-1,x+1,y+1, x,y, false);
						break;
					default:
	                    ignite (x,y);
						break;
					}
				break;

            case bomb_explode:
				piece[x][y] = air;
				addexplosion (x-1,y-1,x+1,y+1, x,y, false);
				break;

            case bigbomb_explode:
				piece[x][y] = air;
				addexplosion (x-1,y-2,x+1,y-2, x,y, false);
				addexplosion (x-1,y+2,x+1,y+2, x,y, false);
				addexplosion (x-2,y-1,x-2,y+1, x,y, false);
				addexplosion (x+2,y-1,x+2,y+1, x,y, false);
				addexplosion (x-1,y-1,x+1,y+1, x,y, false);
				totalexplode (x-1,y-1,x+1,y+1);
				break;

            case door:
				if (emeraldsneeded <= 0) {
                     piece[x][y] = door_opened;
					 lock (x,y);
                     addFGAnimation (seq_dooropen, x,y, 0,0);
					 addSound (snd_exitopen);
                }
				break;

            case door_closing:
				if ((level->totalPlayersInLevel() <= level->totalExitsInLevel())
				|| isDone() ) {
	                piece[x][y] = door_closed;
					lock(x,y);
			        addFGAnimation (seq_doorclose, x,y, 0,0);
					addSound (x,y,snd_exitclos);
				} else {
					piece[x][y] = door_opened;
					addSound (x,y,snd_exitclos);
				}
                break;


			case cushion:
				switch (piece[x][y-1]) {
				case bomb_falling:
					piece[x][y-1] = bomb;
					addSound (x,y,snd_cushion);
					if (!islocked[x][y]) addFGAnimation (seq_cushionbumb, x,y, 0,0);
					lock (x,y);
					break;
				case emerald_falling:
					piece[x][y-1] = emerald;
					addSound (x,y,snd_cushion);
					if (!islocked[x][y]) addFGAnimation (seq_cushionbumb, x,y, 0,0);
					lock (x,y);
					break;
				case stone_falling:
					piece[x][y-1] = stone;
					addSound (x,y,snd_cushion);
					if (!islocked[x][y]) addFGAnimation (seq_cushionbumb, x,y, 0,0);
					lock (x,y);
					break;
				case bag_falling:
					piece[x][y-1] = bag;
					addSound (x,y,snd_cushion);
					if (!islocked[x][y]) addFGAnimation (seq_cushionbumb, x,y, 0,0);
					lock (x,y);
					break;
				case sapphire_falling:
					piece[x][y-1] = sapphire;
					addSound (x,y,snd_cushion);
					if (!islocked[x][y]) addFGAnimation (seq_cushionbumb, x,y, 0,0);
					lock (x,y);
					break;
				case ruby_falling:
					piece[x][y-1] = ruby;
					addSound (x,y,snd_cushion);
					if (!islocked[x][y]) addFGAnimation (seq_cushionbumb, x,y, 0,0);
					lock (x,y);
					break;
				}
				break;

			case elevator:
				if (level->elevatorspeed<=0
				|| (positioncounter % level->elevatorspeed)!=0) break;

				if (piece[x][y-1]==stone || piece[x][y-1]==bag || piece[x][y-1]==emerald
				||  piece[x][y-1]==sapphire || piece[x][y-1]==ruby || piece[x][y-1]==bomb
				||  piece[x][y-1]==bag_opening || piece[x][y-1]==sapphire_breaking) {
					// something moveable lying on top -> triggers upward direction
					if (!islocked[x][y-1] && piece[x][y-2]==air) {
						piece[x][y-2] = piece[x][y-1];
						piece[x][y-1] = elevator;
						piece[x][y] = air;
						lock (x,y-2);
						lock (x,y-1);
						addFGAnimation (seq_elevatorup, x,y,0,-1);
						addSound (x,y, snd_elevator);
						switch (piece[x][y-2]) {
						case stone: 
							addFGAnimation (seq_stonerest, x,y-1,0,-1);
							break;
						case bag: 
							addFGAnimation (seq_bagrest, x,y-1,0,-1);
							break;
						case emerald: 
							addFGAnimation (seq_emeraldrest, x,y-1,0,-1);
							break;
						case sapphire: 
							addFGAnimation (seq_sapphirerest, x,y-1,0,-1);
							break;
						case ruby: 
							addFGAnimation (seq_rubyrest, x,y-1,0,-1);
							break;
						case bomb: 
							addFGAnimation (seq_bombrest, x,y-1,0,-1);
							break;
						}
					}
				} else {
					// otherwise want to go down
					if (piece[x][y+1] == air) {
						piece[x][y] = air;
						piece[x][y+1] = elevator;
						lock (x,y+1);
						addFGAnimation (seq_elevatordown, x,y, 0,1);
						addSound (x,y, snd_elevator);
					}
				}
				break;

			case pusherleft:
				if (piece[x-1][y]==stone || piece[x-1][y]==bag || piece[x-1][y]==emerald
				||  piece[x-1][y]==sapphire || piece[x-1][y]==ruby || piece[x-1][y]==bomb
				||  piece[x-1][y]==box || piece[x-1][y]==cushion
				||  piece[x-1][y]==bag_opening || piece[x-1][y]==sapphire_breaking) {
					// something moveable lying left -> triggers forward direction
					if (!islocked[x-1][y] && piece[x-2][y]==air) {
						piece[x-2][y] = piece[x-1][y];
						piece[x-1][y] = pusherleft;
						piece[x][y] = air;
						lock (x-2,y);
						lock (x-1,y);
						addFGAnimation (seq_pushleftforward, x,y,-1,0);
						switch (piece[x-2][y]) {
						case stone: 
							addFGAnimation (seq_stoneleft, x-1,y,-1,0);
							addSound (x,y, snd_push);
							break;
						case bag: 
							addFGAnimation (seq_bagleft, x-1,y,-1,0);
							addSound (x,y, snd_pushbag);
							break;
						case emerald: 
							addFGAnimation (seq_emeraldleft, x-1,y,-1,0);
							addSound (x,y, 	snd_emldroll);
							break;
						case sapphire: 
							addFGAnimation (seq_sapphireleft, x-1,y,-1,0);
							addSound (x,y, snd_sphrroll);
							break;
						case ruby: 
							addFGAnimation (seq_rubyleft, x-1,y,-1,0);
							addSound (x,y, snd_rubyroll);
							break;
						case bomb: 
							addFGAnimation (seq_bombleft, x-1,y,-1,0);
							addSound (x,y, snd_pushbomb);
							break;
						case box: 
							addFGAnimation (seq_box, x-1,y,-1,0);
							addSound (x,y, snd_pushbox);
							break;
						case cushion: 
							addFGAnimation (seq_cushion, x-1,y,-1,0);
							addSound (x,y, snd_pcushion);
							break;
						}
						turnfalling(x-2,y);
					}
				} else {
					// otherwise want to go back
					if (piece[x+1][y] == air) {
						piece[x][y] = air;
						piece[x+1][y] = pusherleft;
						lock (x+1,y);
						addFGAnimation (seq_pushleftbackward, x,y, 1,0);
					}
				}
				break;

			case pusherright:
				if (piece[x+1][y]==stone || piece[x+1][y]==bag || piece[x+1][y]==emerald
				||  piece[x+1][y]==sapphire || piece[x+1][y]==ruby || piece[x+1][y]==bomb
				||  piece[x+1][y]==box || piece[x+1][y]==cushion
				||  piece[x+1][y]==bag_opening || piece[x+1][y]==sapphire_breaking) {
					// something moveable lying right -> triggers forward direction
					if (!islocked[x+1][y] && piece[x+2][y]==air) {
						piece[x+2][y] = piece[x+1][y];
						piece[x+1][y] = pusherright;
						piece[x][y] = air;
						lock (x+2,y);
						lock (x+1,y);
						addFGAnimation (seq_pushrightforward, x,y,1,0);
						switch (piece[x+2][y]) {
						case stone: 
							addFGAnimation (seq_stoneright, x+1,y,1,0);
							addSound (x,y, snd_push);
							break;
						case bag: 
							addFGAnimation (seq_bagright, x+1,y,1,0);
							addSound (x,y, snd_pushbag);
							break;
						case emerald: 
							addFGAnimation (seq_emeraldright, x+1,y,1,0);
							addSound (x,y, 	snd_emldroll);
							break;
						case sapphire: 
							addFGAnimation (seq_sapphireright, x+1,y,1,0);
							addSound (x,y, snd_sphrroll);
							break;
						case ruby: 
							addFGAnimation (seq_rubyleft, x+1,y,1,0);
							addSound (x,y, snd_rubyroll);
							break;
						case bomb: 
							addFGAnimation (seq_bombleft, x+1,y,1,0);
							addSound (x,y, snd_pushbomb);
							break;
						case box: 
							addFGAnimation (seq_box, x+1,y,1,0);
							addSound (x,y, snd_pushbox);
							break;
						case cushion: 
							addFGAnimation (seq_cushion, x+1,y,1,0);
							addSound (x,y, snd_pcushion);
							break;
						}
						turnfalling(x+2,y);
					}
				} else {
					// otherwise want to go back
					if (piece[x-1][y] == air) {
						piece[x][y] = air;
						piece[x-1][y] = pusherright;
						lock (x-1,y);
						addFGAnimation (seq_pushrightbackward, x,y, -1,0);
					}
				}
				break;

            case swamp: 
				if ( israndom(level->swamprate) ) {
					lock (x,y);
                    addFGAnimation (seq_swamp, x,y, 0,0);
					addSound (x,y,snd_swamp);

					switch (myrnd(4)) {
                    case 0: 
						if ( piece[x][y-1] == air || piece[x][y-1] == earth) {
                           piece[x][y-1] = swamp;
						   lock (x,y-1);
                           addFGAnimation (seq_dropup, x,y-1, 0,0);
						}
                        break;
                     case 1: 
						 if ( piece[x][y+1] == air || piece[x][y+1] == earth) {
                           piece[x][y+1] = drop;
						   lock (x,y+1);
                           addFGAnimation (seq_dropdown, x,y+1, 0,0);
						 }
						break;
                     case 2: 
						 if (piece[x-1][y] == air || piece[x-1][y] == earth) {
                           piece[x-1][y] = drop;
						   lock (x-1,y);
                           addFGAnimation (seq_dropleft, x-1,y, 0,0);
						 }
                        break;
                     case 3: 
						 if (piece[x+1][y] == air || piece[x+1][y] == earth) {
                           piece[x+1][y] = drop;
						   lock (x+1,y);
                           addFGAnimation (seq_dropright, x+1,y, 0,0);
						 }
						break;
					}  
				}
				break;

            case drop: 
				switch (piece[x][y+1]) {
                case air:
                        addFGAnimation (seq_drop, x,y, 0,1);
                        piece[x][y] = air;
                        piece[x][y+1] = drop;
						lock (x,y+1);
                        break;

				CASELIVING
                        piece[x][y] = air;
                        addFGAnimation (seq_drop, x,y, 0,1);
                        addexplosion (x,y+1, x,y+1, x,y+1, false);
                        break;

                case bomb:                      
				case bomb_falling: 
					ignite (x,y+1);
					break;

				default:
					addFGAnimation (seq_drophit, x,y, 0,0);
                    addSound (x,y,snd_drop);
                    piece[x][y] = swamp;
					lock (x,y);
				}
				break;


            case converter: 
                    if ((piece[x][y+1]==air)
						&& (! islocked[x][y-1]) ){
						switch (piece[x][y-1]) {
						case stone:
						case stone_falling:
                          addFGAnimation (seq_stonedown, x,y-1, 0,1);
                          addFGAnimation (seq_emeralddown, x,y, 0,1);
                          addSound (x,y,snd_stnconv);
                          piece[x][y-1] = air;
                          piece[x][y+1] = emerald_falling;
						  lock (x,y+1);
                          break;
						case emerald:
						case emerald_falling:
                          addFGAnimation (seq_emeralddown, x,y-1, 0,1);
                          addFGAnimation (seq_sapphiredown, x,y, 0,1);
                          addSound (x,y,snd_emldconv);
                          piece[x][y-1] = air;
                          piece[x][y+1] = sapphire_falling;
						  lock (x,y+1);
						  break;
						case sapphire:
						case sapphire_falling:
                          addFGAnimation (seq_sapphiredown, x,y-1, 0,1);
                          addFGAnimation (seq_stonedown, x,y, 0,1);
                          addSound (x,y,snd_sphrconv);
                          piece[x][y-1] = air;
                          piece[x][y+1] = stone_falling;
						  lock (x,y+1);
						  break;
						case ruby:
						case ruby_falling:
                          addFGAnimation (seq_rubydown, x,y-1, 0,1);
                          addFGAnimation (seq_bagdown, x,y, 0,1);
                          addSound (x,y,snd_rubyconv);
                          piece[x][y-1] = air;
                          piece[x][y+1] = bag_falling;
						  lock (x,y+1);
						  break;
						case bag:
						case bag_falling:
                          addFGAnimation (seq_bagdown, x,y-1, 0,1);
                          addFGAnimation (seq_rubydown, x,y, 0,1);
                          addSound (x,y,snd_bagconv);
                          piece[x][y-1] = air;
                          piece[x][y+1] = ruby_falling;
						  lock (x,y+1);
						  break;
						}
                    }

					lock (x,y);
					addFGAnimation (seq_convert, x,y, 0,0);
					break;

            case dispenser: 
				if (level->dispenserspeed>0) {
					switch (positioncounter % level->dispenserspeed) {
					case 0: 
                        if (piece[x][y+1] == air) {
	                       addFGAnimation (seq_dispenser1, x,y, 0,0);
							lock (x,y);

                           addFGAnimation (seq_stonedown, x,y, 0,1);
                           piece[x][y+1] = stone_falling;
						   lock (x,y+1);
                        }
						break;
                   case 1: 
                        addFGAnimation (seq_dispenser2, x,y, 0,0);
						lock (x,y);
					}
				}
				break;

            case acid:
				if (!islocked[x][y-1]) {
					switch (piece[x][y-1]) { 
                    case stone:
					case stone_falling: 
                        addBGAnimation (seq_stonedown, x,y-1, 0,1);
                        piece[x][y-1] = air;
						addSound (x,y,snd_acid);
						break;
                    case emerald:
					case emerald_falling: 
                        addBGAnimation (seq_emeralddown, x,y-1, 0,1);
                        piece[x][y-1] = air;
						addSound (x,y,snd_acid);
						emeraldsdestroyed++;
						break;
                    case sapphire:
					case sapphire_falling: 
                        addBGAnimation (seq_sapphiredown, x,y-1, 0,1);
                        piece[x][y-1] = air;
						addSound (x,y,snd_acid);
						emeraldsdestroyed+=3;
						break;
                    case ruby:
					case ruby_falling: 
                        addBGAnimation (seq_rubydown, x,y-1, 0,1);
                        piece[x][y-1] = air;
						addSound (x,y,snd_acid);
						emeraldsdestroyed+=5;
						break;
                    case bag:
					case bag_falling:
                        addBGAnimation (seq_bagdown, x,y-1, 0,1);
                        piece[x][y-1] = air;
						addSound (x,y,snd_acid);
						emeraldsdestroyed++;
						break;
                    case bomb:
                    case bomb_falling:
                        addBGAnimation (seq_bombdown, x,y-1, 0,1);
                        piece[x][y-1] = air;
						addSound (x,y,snd_acid);
						break;
                    case drop:
                        addBGAnimation (seq_drop, x,y-1, 0,1);
                        piece[x][y-1] = air;
						addSound (x,y,snd_acid);
						break;
                    }
				}
				lock (x,y);

				switch (positioncounter % 5) { 
				case 0: addFGAnimation (seq_acid1, x,y, 0,0); break;
				case 1: addFGAnimation (seq_acid2, x,y, 0,0); break;
				case 2: addFGAnimation (seq_acid3, x,y, 0,0); break;
				case 3: addFGAnimation (seq_acid4, x,y, 0,0); break;
				case 4: addFGAnimation (seq_acid5, x,y, 0,0); break;
				}
				if (piece[x-1][y] == acid) {
					if (piece[x+1][y] == acid) {
						// no need to draw a border
					} else {
						addFGAnimation (seq_acidleft, x,y, 0,0);
					}
				} else {
					if (piece[x+1][y] == acid) {
						addFGAnimation (seq_acidright, x,y, 0,0);
					} else {
						addFGAnimation (seq_acidalone, x,y, 0,0);
					}
				}
				break;


			case sand:
				if (!islocked[x][y-1]) {
					if (piece[x][y-1]==stone) { 
                        addFGAnimation (seq_stonedown, x,y-1, 0,1);
                        addFGAnimation (seq_sand, x,y, 0,0);
                        piece[x][y-1] = air;
						piece[x][y] = sand_full;
						lock (x,y);
					}
				}
				break;

			case sand_full:
				if (piece[x][y+1]==air) {
					addFGAnimation (seq_stonedown, x,y, 0,1);
					addFGAnimation (seq_sand, x,y, 0,0);
					piece[x][y+1] = stone_falling;
					piece[x][y] = sand;
					lock(x,y+1);
					lock(x,y);
				} else if (piece[x][y+1]==sand) {
					addFGAnimation (seq_stonedown, x,y, 0,1);
					addFGAnimation (seq_sand, x,y, 0,0);
					addFGAnimation (seq_sand, x,y+1, 0,0);
					piece[x][y+1] = sand_full;
					piece[x][y] = sand;
					lock (x,y+1);
					lock (x,y);
				}
				break;

			case wheel:
				if (wheelendtime > positioncounter && wheelx==x && wheely==y) {
					lock(x,y);
					addFGAnimation (seq_wheel, x,y,0,0);
					addSound (x,y,snd_wheel);
				}
				break;

			case robot:
				if (!islocked[x][y]) { 
					sequencetype rseq = ((positioncounter % 2)==0) ? seq_robot1 : seq_robot2;
					if (israndom(level->robotspeed)) {
						int dx, dy;
						robotmovedir (x,y, dx,dy);
						if (dx!=0 || dy!=0) addSound (x,y,snd_robot);

						switch ( piece[x+dx][y+dy]) {
						CASEMAN
							piece[x][y] = air;
							addFGAnimation (rseq, x,y, dx,dy);
							addexplosion (x+dx,y+dy, x+dx,y+dy, x+dx,y+dy, false);
							break;
						case air:
							piece[x][y] = air;
							piece[x+dx][y+dy] = robot;
							lock (x+dx,y+dy);
							addFGAnimation (rseq, x,y, dx,dy);
							break;
						}
					}
					if (!islocked[x][y] && piece[x][y]==robot) {
						lock (x,y);
						addFGAnimation (rseq, x,y, 0,0);
						break;
					}
				}
				break;

			case lorryleft:
			case lorryleft_fixed:
				if (! blastifnear (x,y, false) ) {
					if (positioncounter % LORRYSOUNDSPEED == 0) addSound (x,y,snd_lorry);
					if ((piece[x][y+1] == air) && (piece[x][y]==lorryleft)) {
						piece[x][y] = lorrydown_fixed;
						lock (x,y);
						addFGAnimation (seq_lorryturnleftdown, x,y, 0,0);
					} else if ( piece[x-1][y] != air) {
						piece[x][y] = lorryup;
						lock (x,y);
						addFGAnimation (seq_lorryturnleftup, x,y, 0,0);
					} else {
						piece[x][y] = air;
						piece[x-1][y] = lorryleft;
						lock (x-1,y);
						addFGAnimation (seq_lorryleft, x,y, -1,0);

						blastifnear (x-1,y, true);
					}
				}
				break;

			case lorryup:
			case lorryup_fixed:  
				if (! blastifnear (x,y, false) ) {
		 			if (positioncounter % LORRYSOUNDSPEED == 0) addSound (x,y,snd_lorry);
						if ((piece[x-1][y] == air) && (piece[x][y]==lorryup)) {
						piece[x][y] = lorryleft_fixed;
						lock (x,y);
					    addFGAnimation (seq_lorryturnupleft, x,y, 0,0);
					} else if (piece[x][y-1] != air) {
						piece[x][y] = lorryright;
						lock (x,y);
						addFGAnimation (seq_lorryturnupright, x,y, 0,0);
					} else {
						piece[x][y] = air;
	                    piece[x][y-1] = lorryup;
						lock (x,y-1);
			            addFGAnimation (seq_lorryup, x,y, 0,-1);

						blastifnear (x,y-1, true);
					}
				}
				break;

			case lorryright:
			case lorryright_fixed:
				if (! blastifnear (x,y, false) ) {
					if (positioncounter % LORRYSOUNDSPEED == 0) addSound (x,y,snd_lorry);
					if ( (piece[x][y-1] == air) && (piece[x][y]==lorryright)) {
						piece[x][y] = lorryup_fixed;
						lock (x,y);
						addFGAnimation (seq_lorryturnrightup, x,y, 0,0);
					} else if (piece[x+1][y] != air) {
						piece[x][y] = lorrydown;
						lock (x,y);
						addFGAnimation (seq_lorryturnrightdown, x,y, 0,0);
					} else {
						piece[x][y] = air;
						piece[x+1][y] = lorryright;
						lock (x+1,y);
						addFGAnimation (seq_lorryright, x,y, 1,0);

						blastifnear (x+1,y, true);
					}
				}	
				break;

			case lorrydown:
			case lorrydown_fixed:
                if (! blastifnear (x,y,false) ) {
					if (positioncounter % LORRYSOUNDSPEED == 0) addSound (x,y,snd_lorry);
                    if ( (piece[x+1][y] == air) && ( piece[x][y]==lorrydown)) {
						piece[x][y] = lorryright_fixed;
						lock (x,y);
						addFGAnimation (seq_lorryturndownright, x,y, 0,0);
					} else if (piece[x][y+1] != air) {
						piece[x][y] = lorryleft;
						lock (x,y);
						addFGAnimation (seq_lorryturndownleft, x,y, 0,0);
					} else {
						piece[x][y] = air;
						piece[x][y+1] = lorrydown;
						lock (x,y+1);
						addFGAnimation (seq_lorrydown, x,y, 0,1);

						blastifnear (x,y+1, true);
					}
				}
				break;


			case bugleft:
			case bugleft_fixed:
				if (! blastifnear (x,y, false) ) {
					if (positioncounter % BUGSOUNDSPEED == 0) addSound (x,y,snd_bug);
					if ((piece[x][y-1] == air) && (piece[x][y]==bugleft)) {
						piece[x][y] = bugup_fixed;
						lock (x,y);
						addFGAnimation (seq_bugturnleftup, x,y, 0,0);
					} else if ( piece[x-1][y] != air) {
						piece[x][y] = bugdown;
						lock (x,y);
						addFGAnimation (seq_bugturnleftdown, x,y, 0,0);
					} else {
						piece[x][y] = air;
						piece[x-1][y] = bugleft;
						lock (x-1,y);
						addFGAnimation (seq_bugleft, x,y, -1,0);

						blastifnear (x-1,y, true);
					}
				}
				break;

			case bugup:
			case bugup_fixed:  
				if (! blastifnear (x,y, false) ) {
		 			if (positioncounter % BUGSOUNDSPEED == 0) addSound (x,y,snd_bug);
						if ((piece[x+1][y] == air) && (piece[x][y]==bugup)) {
						piece[x][y] = bugright_fixed;
						lock (x,y);
					    addFGAnimation (seq_bugturnupright, x,y, 0,0);
					} else if (piece[x][y-1] != air) {
						piece[x][y] = bugleft;
						lock (x,y);
						addFGAnimation (seq_bugturnupleft, x,y, 0,0);
					} else {
						piece[x][y] = air;
	                    piece[x][y-1] = bugup;
						lock (x,y-1);
			            addFGAnimation (seq_bugup, x,y, 0,-1);

						blastifnear (x,y-1, true);
					}
				}
				break;

			case bugright:
			case bugright_fixed:
				if (! blastifnear (x,y, false) ) {
					if (positioncounter % BUGSOUNDSPEED == 0) addSound (x,y,snd_bug);
					if ( (piece[x][y+1] == air) && (piece[x][y]==bugright)) {
						piece[x][y] = bugdown_fixed;
						lock (x,y);
						addFGAnimation (seq_bugturnrightdown, x,y, 0,0);
					} else if (piece[x+1][y] != air) {
						piece[x][y] = bugup;
						lock (x,y);
						addFGAnimation (seq_bugturnrightup, x,y, 0,0);
					} else {
						piece[x][y] = air;
						piece[x+1][y] = bugright;
						lock (x+1,y);
						addFGAnimation (seq_bugright, x,y, 1,0);

						blastifnear (x+1,y, true);
					}
				}	
				break;

			case bugdown:
			case bugdown_fixed:
                if (! blastifnear (x,y,false) ) {
					if (positioncounter % BUGSOUNDSPEED == 0) addSound (x,y,snd_bug);
                    if ( (piece[x-1][y] == air) && ( piece[x][y]==bugdown)) {
						piece[x][y] = bugleft_fixed;
						lock (x,y);
						addFGAnimation (seq_bugturndownleft, x,y, 0,0);
					} else if (piece[x][y+1] != air) {
						piece[x][y] = bugright;
						lock (x,y);
						addFGAnimation (seq_bugturndownright, x,y, 0,0);
					} else {
						piece[x][y] = air;
						piece[x][y+1] = bugdown;
						lock (x,y+1);
						addFGAnimation (seq_bugdown, x,y, 0,1);

						blastifnear (x,y+1, true);
					}
				}
				break;

            case bug_explode: 
				ignite(x,y);
				break;

            case yamyamleft: 
				if (! blastYamYamIfNecessary(x,y, -1,0) ) {
					if (piece[x-1][y] == air) {
						piece[x][y] = air;
						piece[x-1][y] = yamyamleft;
						lock (x-1,y);
						addFGAnimation (seq_yamyamleft, x,y, -1,0);
					 } else {
						 if ((piece[x-1][y] == sapphire) 
						 && ! islocked[x-1][y]) {
                              piece[x-1][y] = air;
                              addFGAnimation (seq_sapphireaway, x-1,y, 0,0);
						} else {
		                     piece[x][y] = anyyamyam();
						}
						if (! level->silentyamyam) addSound (x,y,snd_yamyam);
						addFGAnimation (seq_yamyaming, x,y, 0,0);
						lock (x,y);
					}
				}
				break;

            case yamyamright: 
				if (! blastYamYamIfNecessary(x,y, 1,0) ) {
					if (piece[x+1][y] == air) {
						piece[x][y] = air;
                        piece[x+1][y] = yamyamright;
						lock (x+1,y);
                        addFGAnimation (seq_yamyamright, x,y, 1,0);
					} else {
						if ( (piece[x+1][y] == sapphire)
							   && ! islocked[x+1][y] ) {
							piece[x+1][y] = air;
                            addFGAnimation (seq_sapphireaway, x+1,y, 0,0);
						} else {
                            piece[x][y] = anyyamyam();
                        }
                        if (!level->silentyamyam) addSound (x,y,snd_yamyam);
                        addFGAnimation (seq_yamyaming, x,y, 0,0);
						lock (x,y);
					}
				}
				break;

            case yamyamup: 
				if (! blastYamYamIfNecessary(x,y, 0,-1) ) {
					if (piece[x][y-1] == air) {
						piece[x][y] = air;
                        piece[x][y-1] = yamyamup;
						lock (x,y-1);
                        addFGAnimation (seq_yamyamup, x,y, 0,-1);
					} else {
                        if ( (piece[x][y-1] == sapphire)
							   && ! islocked[x][y-1]) {
							piece[x][y-1] = air;
                            addFGAnimation (seq_sapphireaway, x,y-1, 0,0);
						} else {
							piece[x][y] = anyyamyam();
                        }
                        if (!level->silentyamyam) addSound (x,y,snd_yamyam);
                        addFGAnimation (seq_yamyaming, x,y, 0,0);
						lock (x,y);
					}
				}
				break;

            case yamyamdown:
				if (! blastYamYamIfNecessary(x,y, 0,1) ) {
					if (piece[x][y+1] == air) {
						piece[x][y] = air;
                        piece[x][y+1] = yamyamdown;
						lock (x,y+1);
                        addFGAnimation (seq_yamyamdown, x,y, 0,1);
					} else {
						if ( (piece[x][y+1] == sapphire) 
							   && !islocked[x][y+1]) {
							piece[x][y+1] = air;
							addFGAnimation (seq_sapphireaway, x,y+1, 0,0);
						} else {
							piece[x][y] = anyyamyam();
						}
						if (! level->silentyamyam) addSound (x,y,snd_yamyam);
                        addFGAnimation (seq_yamyaming, x,y, 0,0);
						lock (x,y);
					}
				}
				break;

            case yamyam_explode: 
				ignite(x,y);
				break;


            case explode1:
				piece[x][y] = explode2;
				lock (x,y);
                addFGAnimation (seq_explode2, x,y, 0,0);
                break;
			case explode2: 
                piece[x][y] = explode3;
				lock (x,y);
                addFGAnimation (seq_explode3, x,y, 0,0);
                break;
		    case explode3:
                piece[x][y] = explode4;
				lock (x,y);
                addFGAnimation (seq_explode4, x,y, 0,0);
                break;
			case explode4:
				piece[x][y] = explosionrest[x][y];
				explosionrest[x][y] = air;
				addFGAnimation (seq_explode5, x,y, 0,0);
                break;

            case activebomb1:
            case activebomb2:
            case activebomb3:
            case activebomb4:
			case activebomb5:
				piece[x][y] = (piecetype) ( ((int) piece[x][y]) - 1 );
				lock (x,y);
                addFGAnimation (seq_tickbomb, x,y, 0,0);
                addSound (x,y,snd_bombtick);
                break;

            case activebomb0: 
				piece[x][y] = air;
                addexplosion (x-1,y-1,x+1,y+1, x,y, false);
				break;

            case keyblue:
			case keyred:
			case keygreen:
			case keyyellow:
				lock (x,y);
				switch ( (piece[x][y]-keyblue)*5 + (positioncounter % 5) ) {
				case 0*5+0: addFGAnimation (seq_keyblue1, x,y, 0,0); break;
                case 0*5+1: addFGAnimation (seq_keyblue2, x,y, 0,0); break;
                case 0*5+2: addFGAnimation (seq_keyblue3, x,y, 0,0); break;
                case 0*5+3: addFGAnimation (seq_keyblue4, x,y, 0,0); break;
                case 0*5+4: addFGAnimation (seq_keyblue5, x,y, 0,0); break;
                case 1*5+0: addFGAnimation (seq_keyred1, x,y, 0,0); break;
                case 1*5+1: addFGAnimation (seq_keyred2, x,y, 0,0); break;
                case 1*5+2: addFGAnimation (seq_keyred3, x,y, 0,0); break;
                case 1*5+3: addFGAnimation (seq_keyred4, x,y, 0,0); break;
                case 1*5+4: addFGAnimation (seq_keyred5, x,y, 0,0); break;
                case 2*5+0: addFGAnimation (seq_keygreen1, x,y, 0,0); break;
                case 2*5+1: addFGAnimation (seq_keygreen2, x,y, 0,0); break;
                case 2*5+2: addFGAnimation (seq_keygreen3, x,y, 0,0); break;
                case 2*5+3: addFGAnimation (seq_keygreen4, x,y, 0,0); break;
                case 2*5+4: addFGAnimation (seq_keygreen5, x,y, 0,0); break;
                case 3*5+0: addFGAnimation (seq_keyyellow1, x,y, 0,0); break;
                case 3*5+1: addFGAnimation (seq_keyyellow2, x,y, 0,0); break;
                case 3*5+2: addFGAnimation (seq_keyyellow3, x,y, 0,0); break;
                case 3*5+3: addFGAnimation (seq_keyyellow4, x,y, 0,0); break;
                case 3*5+4: addFGAnimation (seq_keyyellow5, x,y, 0,0); break;
                } 
				break;


			case movie0: lock(x,y); addFGAnimation (seq_movie0_0, x,y,0,0); break;
			case movie1: lock(x,y); addFGAnimation (seq_movie1_0, x,y,0,0); break;
			case movie2: lock(x,y); addFGAnimation (seq_movie2_0, x,y,0,0); break;
			case movie3: lock(x,y); addFGAnimation (seq_movie3_0, x,y,0,0); break;
			case movie4: lock(x,y); addFGAnimation (seq_movie4_0, x,y,0,0); break;
			case movie5: lock(x,y); addFGAnimation (seq_movie5_0 + (positioncounter%2), x,y,0,0); break;
			case movie6: lock(x,y); addFGAnimation (seq_movie6_0 + (positioncounter%2), x,y,0,0); break;
			case movie7: lock(x,y); addFGAnimation (seq_movie7_0 + (positioncounter%2), x,y,0,0); break;
			case movie8: lock(x,y); addFGAnimation (seq_movie8_0 + (positioncounter%2), x,y,0,0); break;
			case movie9: lock(x,y); addFGAnimation (seq_movie9_0 + (positioncounter%2), x,y,0,0); break;
			case movie10:lock(x,y); addFGAnimation (seq_movie10_0 + (positioncounter%4), x,y,0,0); break;
			case movie11:lock(x,y); addFGAnimation (seq_movie11_0 + (positioncounter%4), x,y,0,0); break;
			case movie12:lock(x,y); addFGAnimation (seq_movie12_0 + (positioncounter%4), x,y,0,0); break;
			case movie13:lock(x,y); addFGAnimation (seq_movie13_0 + (positioncounter%4), x,y,0,0); break;
			case movie14:lock(x,y); addFGAnimation (seq_movie14_0 + (positioncounter%4), x,y,0,0); break;
			case movie15:lock(x,y); addFGAnimation (seq_movie15_0 + (positioncounter%8), x,y,0,0); break;
			case movie16:lock(x,y); addFGAnimation (seq_movie16_0 + (positioncounter%8), x,y,0,0); break;
			case movie17:lock(x,y); addFGAnimation (seq_movie17_0 + (positioncounter%8), x,y,0,0); break;
			case movie18:lock(x,y); addFGAnimation (seq_movie18_0 + (positioncounter%8), x,y,0,0); break;
			case movie19:lock(x,y); addFGAnimation (seq_movie19_0 + (positioncounter%8), x,y,0,0); break;

			} // end switch
		}
   }

   // add clock sound for warning of time-out
   if (availabletime > 0) {
	   int t = availabletime - positioncounter;
	   if (t==40 || t==12 || t==8 || t==4) {
		   addSound (snd_clock);
	   }
	}
}


int Game::myrnd(int range)
{
   randseed = (
	            randseed
            +  (randseed << 2)
            +  (randseed << 10)
            +  (randseed << 15)
            +  (randseed << 19)
            +  (randseed << 27)
            +  1 )   & 0xffffffff;

   return (randseed >> 16) % range;
}

int Game::israndom (int i)
{
   if (i==0) return false;
   else return (myrnd(i) == 0) ? true : false;
}

bool Game::truerandom (int num)
{
	return (rand() % num) == 0;
}




KeyboardInputHandler::KeyboardInputHandler (int layout)
{
	keyboard = new Keyboard();
	bombs = false;
	
	switch (layout) {
	case 0:
	default:
		upkey = KEY_UP;
		downkey = KEY_DOWN;
		leftkey = KEY_LEFT;
		rightkey = KEY_RIGHT;
		bombkey = KEY_SHIFT;
		grabkey = KEY_CONTROL;
		break;
	case 1:
		upkey =    KEY_R;
		downkey =  KEY_F;
		leftkey =  KEY_D;
		rightkey = KEY_G;
		bombkey =  KEY_Q;
		grabkey =  KEY_A;
		break;
	case 2:
		upkey = KEY_JOY0UP;
		downkey = KEY_JOY0DOWN;
		leftkey = KEY_JOY0LEFT;
		rightkey = KEY_JOY0RIGHT;
		bombkey = KEY_JOY0BUTTON1;
		grabkey = KEY_JOY0BUTTON0;
		break;
	case 3:
		upkey = KEY_JOY1UP;
		downkey = KEY_JOY1DOWN;
		leftkey = KEY_JOY1LEFT;
		rightkey = KEY_JOY1RIGHT;
		bombkey = KEY_JOY1BUTTON1;
		grabkey = KEY_JOY1BUTTON0;
		break;
	}
}

KeyboardInputHandler::~KeyboardInputHandler ()
{
	delete keyboard;
}

void KeyboardInputHandler::recordMove (Walkthrough *walk, int channel, int needmoveforposition)
{
	bool keydown;
	int keycode;

	while (keyboard->getEvent (keydown, keycode)) {
		if (!keydown) continue;

		if (keycode == upkey || keycode == downkey
	 	 || keycode == leftkey || keycode == rightkey) {

			movetype move = getState();
			walk->addMove (channel, move);

			if (move==bombright || move==bombleft || move==bombup || move==bombdown) bombs=false;

		} else if (keycode == bombkey) {
			bombs = true;
		}
	}

	if (walk->numberOfMoves (channel) <= needmoveforposition) {
		movetype move = getState();
		walk->addMove (channel, move );

		if (move==bombright || move==bombleft || move==bombup || move==bombdown) bombs=false;
	}
}

movetype KeyboardInputHandler::getState ()
{
	movetype move = rest;
		
	unsigned long int thistimestamp = 0;
	if (keyboard->isKeyPressed(upkey) && keyboard->keyTimeStamp(upkey)>thistimestamp) {
		move = moveup;
		thistimestamp = keyboard->keyTimeStamp(upkey);
	}
	if (keyboard->isKeyPressed(downkey) && keyboard->keyTimeStamp(downkey)>thistimestamp) {
		move = movedown;
		thistimestamp = keyboard->keyTimeStamp(downkey);
	}
	if (keyboard->isKeyPressed(leftkey) && keyboard->keyTimeStamp(leftkey)>thistimestamp) {
		move = moveleft;
		thistimestamp = keyboard->keyTimeStamp(leftkey);
	}
	if (keyboard->isKeyPressed(rightkey) && keyboard->keyTimeStamp(rightkey)>thistimestamp) {
		move = moveright;
		thistimestamp = keyboard->keyTimeStamp(rightkey);
	}

	if ( keyboard->isKeyPressed(grabkey) && move!=rest) {
		move = (movetype) (grabup + (move - moveup));
	} else if ( (keyboard->isKeyPressed(bombkey) || bombs) && move!=rest) {
		move = (movetype) (bombup + (move - moveup));
	}

	return move;
}
