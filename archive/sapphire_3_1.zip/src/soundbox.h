#ifndef _SOUNDBOX_H 
#define _SOUNDBOX_H

#include "types.h"
#include "windows.h"
#include <dsound.h>

class Sound;

bool initSoundBox (HWND hwnd);
void closeSoundBox ();
bool reloadSoundBox ();

void activateSound();
void deactivateSound();

Sound*   loadSound (charstring& filename, double repeatspersecond);

class Sound {
public:
	charstring filename;
	double repeatspersecond;

	enum { maxsoundbuffers=40 };
	int numsoundbuffers;
	LPDIRECTSOUNDBUFFER lpDSB[maxsoundbuffers];

	int nextplayposition;

	Sound(charstring& fname, double rps);
	virtual ~Sound();

	void doconvert (BYTE* in_buffer, WORD in_channels, WORD in_bitspersample,
						DWORD in_totalsamples, BYTE* out_buffer);
	bool reload();

	void play(int volume);
};


#endif
