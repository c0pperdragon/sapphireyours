
#ifndef _INPUTBOX_H 
#define _INPUTBOX_H

#include "types.h"
#include "windows.h"
#include "dinput.h"

bool initInputBox (HINSTANCE inst, HWND hwnd);
void closeInputBox ();

void addCommandEvent(int event, int parameter);
bool getCommandEvent(int& cmd, int& parameter);
bool getCommandEvent(int& cmd);
void clearCommandEvents();
void clearDeviceEvents();

int numberJoystickPresent();

void handleLetterEvent (int letter);
void handleKeyEvent (bool keydown, int scancode);
void handleMouseButtonEvent(bool down, int button);
void handleMouseMove(int dx, int dy);
void pollInput (double timeexpired);

#define COMMAND_LETTER		1
#define COMMAND_ESCAPE		2
#define COMMAND_YES			3
#define COMMAND_NO			4
#define COMMAND_CONTINUE	5
#define COMMAND_UP			10
#define COMMAND_DOWN		11
#define COMMAND_LEFT		12
#define COMMAND_RIGHT		13
#define COMMAND_PRIOR		14
#define COMMAND_NEXT		15
#define COMMAND_HOME		16
#define COMMAND_END			17
#define COMMAND_DELETE		18
#define COMMAND_F1			31
#define COMMAND_F2			32
#define COMMAND_F3			33
#define COMMAND_F4			34
#define COMMAND_F5			35
#define COMMAND_F6			36
#define COMMAND_F7			37
#define COMMAND_F8			38
#define COMMAND_F9			39
#define COMMAND_F10			40
#define COMMAND_F11			41
#define COMMAND_F12			42
#define COMMAND_F3F1		50
#define COMMAND_F3F2		51
#define COMMAND_F3F3		52
#define COMMAND_F3F4		53
#define COMMAND_F3F5		54
#define COMMAND_ENTERKEY    60
#define COMMAND_BACKSPACE   61

#define KEY_UP				VK_UP
#define KEY_DOWN			VK_DOWN
#define KEY_LEFT			VK_LEFT
#define KEY_RIGHT			VK_RIGHT
#define KEY_CONTROL			VK_CONTROL
#define KEY_SHIFT			VK_SHIFT
#define KEY_R               'R';
#define KEY_F               'F';
#define KEY_D               'D';
#define KEY_G               'G';
#define KEY_Q               'Q';
#define KEY_A               'A';

#define KEY_JOY0UP          240
#define KEY_JOY0DOWN		241
#define KEY_JOY0LEFT		242
#define KEY_JOY0RIGHT		243
#define KEY_JOY0BUTTON0		244
#define KEY_JOY0BUTTON1		245
#define KEY_JOY0BUTTON2		246
#define KEY_JOY1UP          250
#define KEY_JOY1DOWN		251
#define KEY_JOY1LEFT		252
#define KEY_JOY1RIGHT		253
#define KEY_JOY1BUTTON0		254
#define KEY_JOY1BUTTON1		255
#define KEY_JOY1BUTTON2		256


class InternalJoystick {
	LPDIRECTINPUTDEVICE2 device;
	int codeb0,codeb1,codeb2;
	int codeleft,coderight;
	int codeup,codedown;

	bool prevb0,prevb1,prevb2;
	double prevx, prevy;

	double uprepeattime,downrepeattime,leftrepeattime,rightrepeattime;

public:
	InternalJoystick(LPDIRECTINPUTDEVICE2 dev, int index);
	~InternalJoystick();

	void CheckEvent(double timeexpired);
};




class Keyboard {
	enum { buffersize = 200 };
	
	bool down[buffersize];
	int code[buffersize];

	int writecursor;
	int readcursor;
	int eventsinbuffer;
	unsigned long int timestamp;

	bool iskeypressed[256];
	int keytimestamp[256];

public:
	Keyboard();
	~Keyboard();

	void addEvent (bool keydown, int scancode);
	void clearEvents();

	bool getEvent (bool &keydown, int &scancode, bool getrepeats=false);
	bool isKeyPressed (int scancode);
	unsigned long int keyTimeStamp(int scancode);
};

class Mouse {
	int mousex;
	int mousey;

	int left;
	int top;
	int right;
	int bottom;

	int borderpushx;
	int borderpushy;

	enum {maxbuttons=3};
	bool buttondown[maxbuttons];
	bool buttonnew[maxbuttons];

public:
	Mouse();
	~Mouse();

	void addButtonEvent(bool down, int button);
	void addMoveEvent(int dx, int dy);
	void resetCoordinates(int x, int y, int l, int t, int r, int b);
	void resetBorderPush();

	bool isButtonDown(int button);
	bool isButtonNew(int button);
	void forgetButton(int button);

	int getMouseX() { return mousex; };
	int getMouseY() { return mousey; };
	int getBorderPushX() { return borderpushx; }
	int getBorderPushY() { return borderpushy; }
};




#endif
