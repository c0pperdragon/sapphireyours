
#include "framework.h"
#include "viewbox.h"
#include "toolbox.h"
#include "viewextension.h"

// member functions: ImageFrame

ImageFrame::ImageFrame (int l, int t, bool transp, Image* i)
: Frame (l,t,l+i->width,t+i->height,transp) 
{
	img = i;
}

ImageFrame::~ImageFrame () 
{
}
	
void ImageFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	theScreen.draw (img, x1-left,y1-top, x1,y1,x2,y2, transparency);
}

// member functions: CoordiantesFrame


CoordinatesFrame::CoordinatesFrame (int l, int t, bool transp, Image* i,int clength)
: Frame (l,t,l+(i->width/11)*coordlength,t+i->height,transp)
{
	img = i;
	coordx=-1;
	coordy=-1;
	coordlength = clength;
}

CoordinatesFrame::~CoordinatesFrame ()
{
}

void CoordinatesFrame::update (int currentpage, int l, int t, int r, int b)
{
	if (coordx<0 || coordy<0) return;

	char buffer[100];
	int digitw = img->width/11;
	int digith = img->height;
	sprintf (buffer, "%d,%d", coordx, coordy);
	for (int i=0; i<coordlength && buffer[i]!='\0'; i++) {
		int sx=0;
		if (buffer[i]>='0' && buffer[i]<='9') {
			sx = ((buffer[i]-'0')+1) * digitw;
		}
		theScreen.drawClipped (img, sx,0, left+i*digitw,top, left+(i+1)*digitw, top+digith,
					 l,t,r,b, transparency);
	}
}

void CoordinatesFrame::setCoords (int x, int y)
{
	if (coordx!=x || coordy!=y) {
		coordx = x;
		coordy = y;
		invalidateArea(left,top, right,bottom);
	}
}


// member functions: TileFrame

TileFrame::TileFrame (int l, int t, int r, int b, bool transp, Image* i)
: Frame (l,t,r,b,transp) 
{
	img = i;
}

TileFrame::~TileFrame () 
{
}

void TileFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	theScreen.drawTile (img, x1,y1,x2,y2);
}


// member functions: ColorFrame

ColorFrame::ColorFrame (int l, int t, int r, int b, int col)
: Frame (l,t,r,b,false) 
{
	color = col;
}

ColorFrame::~ColorFrame () 
{
}

void ColorFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	theScreen.fill (color, x1,y1,x2,y2);
}

BackgroundColorFrame::BackgroundColorFrame (int color)
: ColorFrame (0,0, getScreenWidth(), getScreenHeight(), color)
{
}

BackgroundColorFrame::~BackgroundColorFrame ()
{
}


BufferedTransparentFrame::BufferedTransparentFrame (int l, int t, int r, int b, 
													int _transparentcolor)
	: Frame (l,t,r,b,true)
{
	transparentcolor = _transparentcolor;
	buffer = createSurface(right-left,bottom-top, transparentcolor);
}

BufferedTransparentFrame::~BufferedTransparentFrame ()
{
	if (buffer) delete buffer;
}


void BufferedTransparentFrame::setAllDirty()
{
	setDirty(left,top,right,bottom);
}

void BufferedTransparentFrame::setDirty (int l,int t, int r, int b)
{
	cleanbuffer[0].subtractRect(l,t,r,b);
	cleanbuffer[1].subtractRect(l,t,r,b);
	if (buffer) updateBuffer (l,t,r,b);
}


void BufferedTransparentFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	if (buffer) {
		RectangleList usedarea;
		usedarea.init (x1,y1,x2,y2);

		subtractFreeArea (usedarea);
		for (int r=0; r<usedarea.rectnum; r++) {
			theScreen.draw (buffer, 
				usedarea.rect[r].left-left, usedarea.rect[r].top-top,
				usedarea.rect[r].left, usedarea.rect[r].top,
				usedarea.rect[r].right, usedarea.rect[r].bottom,
				true);
		}
	}
}

void BufferedTransparentFrame::computeChanges (int currentpage, list<Frame*>::reverse_iterator& revit)
{
	if (!buffer) return;
	if (buffer->isdestroyed) {
		setAllDirty();
		buffer->isdestroyed=false;
	}

	RectangleList invalid;
	invalid.init(left,top,right,bottom);
	invalid.subtract (cleanbuffer[currentpage]);

	for (int r=0; r<invalid.rectnum; r++) {
		invalidateLower (currentpage, revit, 
			invalid.rect[r].left, invalid.rect[r].top,
			invalid.rect[r].right, invalid.rect[r].bottom );
	}
}

void BufferedTransparentFrame::drawChanges (int currentpage, list<Frame*>::iterator& it)
{
	RectangleList invalid;
	invalid.init(valid[currentpage]);
	invalid.subtract (cleanbuffer[currentpage]);

	for (int r=0; r<invalid.rectnum; r++) {
		update (currentpage, invalid.rect[r].left, invalid.rect[r].top,
							 invalid.rect[r].right, invalid.rect[r].bottom);

		invalidateHigher (currentpage, it, 
			invalid.rect[r].left, invalid.rect[r].top,
			invalid.rect[r].right, invalid.rect[r].bottom );
	}

	cleanbuffer[currentpage].init(left,top,right,bottom);
}



FrameCaller::FrameCaller ()
{
	frame = NULL;
}

FrameCaller::~FrameCaller()
{
}

void FrameCaller::setFrame(Frame* f)
{
	frame = f;
}

void FrameCaller::run()
{
	if (frame) frame->call();
}





MouseCursor::MouseCursor (int startx, int starty, Image* i, 
						  Image* digits, int _hotx, int _hoty)
: SelfRunner()
, frame(startx-_hotx, starty-_hoty, true, i)
, coordframe(startx-_hotx, starty-_hoty+i->height, true, digits, 5)
{
	mouse.resetCoordinates(startx,starty,0,0,getScreenWidth(),getScreenHeight());
	hotx = _hotx;
	hoty = _hoty;
	width = i->getWidth();
	height = i->getHeight();
	enabled = true;
}

MouseCursor::~MouseCursor()
{
}

int MouseCursor::getMouseX()
{
	return mouse.getMouseX();
};

int MouseCursor::getMouseY()
{
	return mouse.getMouseY();
};

int MouseCursor::getBorderPushX()
{
	return mouse.getBorderPushX();
}

int MouseCursor::getBorderPushY()
{
	return mouse.getBorderPushY();
}

void MouseCursor::resetBorderPush()
{
	mouse.resetBorderPush();
}

bool MouseCursor::isButtonDown(int button)
{
	return mouse.isButtonDown(button);
}

bool MouseCursor::isButtonNew(int button)
{
	return mouse.isButtonNew(button);
}

void MouseCursor::forgetButton(int button)
{
	mouse.forgetButton(button);
}

void MouseCursor::enable(bool yesno)
{
	enabled = yesno;
	resetBorderPush();

	if (!enabled) {
		frame.resize(0,0,0,0);
		coordframe.resize(0,0,0,0);
	} else {
		run();
	}
}

void MouseCursor::run()
{
	if (!enabled) return;
	int x=mouse.getMouseX() - hotx;
	int y=mouse.getMouseY() - hoty;
	if (x!=frame.getLeft() || y!=frame.getTop()) {
		frame.resize (x,y, x+width,y+height);

		coordframe.resize (frame.getLeft(),frame.getBottom(),
			frame.getLeft()+(coordframe.img->getWidth()/11)*coordframe.coordlength,
			frame.getBottom()+coordframe.img->getHeight());
	}
}

void MouseCursor::setDisplayedCoordinates(int x, int y)
{
	coordframe.setCoords(x,y);
}

ToolbarFrame::ToolbarFrame (int l, int t, Image* i, 
		int _cols, int _rows, int _iconsize, int _xoffset, int _yoffset,
		int _selectcolor, int _selectcolor2)
: ImageFrame (l,t,false, i)
{
	rows = _rows;
	cols = _cols;
	iconsize = _iconsize;
	xoffset = _xoffset;
	yoffset = _yoffset;
	selectcolor[0] = _selectcolor;
	selectcolor[1] = _selectcolor2;

	for (int s=0; s<maxselections; s++) {	
		selectedrow[s] = 0;
		selectedcol[s] = 0;
	}
}

ToolbarFrame::~ToolbarFrame()
{
}

void ToolbarFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	theScreen.draw (img, x1-left,y1-top, x1,y1,x2,y2, transparency);

	for (int s=maxselections-1; s>=0; s--) {	
		int l=left+xoffset+iconsize*selectedcol[s];
		int t=top+yoffset+iconsize*selectedrow[s];
		theScreen.drawBorder (selectcolor[s],
			l-1,t-1, l+iconsize+2,t+iconsize+2, 2, x1,y1,x2,y2);
	}
}

bool ToolbarFrame::selectIcon(int s, int x, int y)
{
	x = (x-left)-xoffset;
	y = (y-top)-yoffset;
	if (x<0 || y<0 || x>=cols*iconsize || y>=rows*iconsize) return false;

	selectedcol[s] = x/iconsize;
	selectedrow[s] = y/iconsize;

	invalidateArea(left,top,right,bottom);
	return true;
}
