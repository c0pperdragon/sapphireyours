#ifndef _TOOLBOX_H
#define _TOOLBOX_H

#include <stdio.h>
#include <windows.h>
#include "types.h"

bool initToolBox();
void closeToolBox();

void readsubdirectorylist(vector<charstring> &v, const char* path);
void sortstringlist(vector<charstring> & v);

typedef HANDLE findhandle;

char *findfirstfile (findhandle* h, const char* path);
char *findfile (findhandle* h);
void stopfindfile (findhandle* h);
//int isdirectory (const char* fname);
bool fileexists (const char* fname);
//bool samefile(const char* f1, const char* f2);
bool stringcontains (const char* s, char c);

int minimum(int a, int b);
int maximum(int a, int b);
void doDownCase(charstring& str);
void doCapitalize(charstring& str);

int randomnumber (int range);

FILE* openinifile (char* filename, char* mode);

double getTimer();

bool scancmdline (char* line, char* option, int& param);

#endif
