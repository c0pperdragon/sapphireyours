#include "musicbox.h"
#include "framework.h"

#include <mmsystem.h>


static HWND musicBoxMasterWindow = NULL;


// MIDI support


static int midiplaying=0;
static MCIDEVICEID mcidevice=0;
static charstring thismidi = "no_midi_playing";
static int thismidistart = 0;

static bool midididrestart = false;

bool initMusicBox (HWND hwnd)
{
	musicBoxMasterWindow = hwnd;
	midiplaying = 0;
	return true;
}

void closeMusicBox ()
{
	stopMIDI();
}


bool didMIDIrestart()
{
	return midididrestart;
}

void playMIDI (charstring& file, int playstart)
{
	if (midiplaying && (_stricmp(thismidi.data(),file.data())==0) ) {
		return;
	}

	if (midiplaying) {
		stopMIDI();
	}

	thismidi = file;
	thismidistart = playstart;

	restartMIDI();
	midididrestart = false;
}


static void resetpichbend()
{
	MCIDEVICEID mcidevice=0;
    MCI_OPEN_PARMS openparams; 
	MCI_PLAY_PARMS playparams;
	MCI_GENERIC_PARMS genericparams;
	char errstr[500];
	int res;
	genericparams.dwCallback = 0;

    openparams.dwCallback = 0; 
    openparams.wDeviceID = 0; 
    openparams.lpstrDeviceType = (LPCSTR) MCI_DEVTYPE_SEQUENCER; 
    openparams.lpstrElementName = "reset.mid";
    openparams.lpstrAlias = ""; 
	res = mciSendCommand(0, 
		MCI_OPEN,
		MCI_OPEN_TYPE | MCI_OPEN_TYPE_ID | MCI_OPEN_ELEMENT |
		MCI_WAIT ,  (DWORD) (&openparams) );
	mciGetErrorString(res,errstr,500);
	doLog (2, "result: %d  %s", res, errstr);
	if (res!=0) return;
	mcidevice = openparams.wDeviceID;

	playparams.dwCallback = 0;
	playparams.dwFrom = 0;
	playparams.dwTo = 0;
	res = mciSendCommand(mcidevice, 
		MCI_PLAY, MCI_FROM |
		MCI_WAIT ,  (DWORD) (&playparams) );
	mciGetErrorString(res,errstr,500);
	doLog (2, "result: %d  %s", res, errstr);

	mciSendCommand(mcidevice, MCI_STOP, MCI_WAIT, (DWORD) (&genericparams));
	mciSendCommand(mcidevice, MCI_CLOSE, MCI_WAIT, (DWORD) (&genericparams));
}


void restartMIDI()
{
	char errstr[500];
	int res;
    MCI_OPEN_PARMS openparams; 
	MCI_PLAY_PARMS playparams;

	midididrestart = true;

	// just restart already playing midi
	if (midiplaying) {
		MCI_GENERIC_PARMS genericparams;
		genericparams.dwCallback = 0;
		mciSendCommand(mcidevice, MCI_STOP, MCI_WAIT, (DWORD) (&genericparams));
		
		playparams.dwCallback = (DWORD) musicBoxMasterWindow;
		playparams.dwFrom = thismidistart;
		playparams.dwTo = 0;
		res = mciSendCommand(mcidevice, 
		MCI_PLAY, MCI_FROM |
		MCI_NOTIFY ,  (DWORD) (&playparams) );	

		return;
	}

	// do full start
	doLog (2,"trying to start midi playback: %s",thismidi.data());

	resetpichbend();


    openparams.dwCallback = 0;; 
    openparams.wDeviceID = 0; 
    openparams.lpstrDeviceType = (LPCSTR) MCI_DEVTYPE_SEQUENCER; 
    openparams.lpstrElementName = thismidi.data(); 
    openparams.lpstrAlias = ""; 
	res = mciSendCommand(0, 
		MCI_OPEN,
		MCI_OPEN_TYPE | MCI_OPEN_TYPE_ID | MCI_OPEN_ELEMENT |
		MCI_WAIT ,  (DWORD) (&openparams) );
	mcidevice = (res==0) ? openparams.wDeviceID : 0;
	mciGetErrorString(res,errstr,500);
	doLog (2,"result: %d  %s", res, errstr);

	if (mcidevice != 0) {
		playparams.dwCallback = (DWORD) musicBoxMasterWindow;
		playparams.dwFrom = thismidistart;
		playparams.dwTo = 0;
		res = mciSendCommand(mcidevice, 
			MCI_PLAY, MCI_FROM |
			MCI_NOTIFY ,  (DWORD) (&playparams) );
		mciGetErrorString(res,errstr,500);
		doLog (2, "result: %d  %s", res, errstr);
	}

	midiplaying = (mcidevice != 0);
}


void stopMIDI ()
{
	MCI_GENERIC_PARMS genericparams;
	genericparams.dwCallback = 0;

	if (midiplaying) {
		
		mciSendCommand(mcidevice, MCI_STOP, MCI_WAIT, (DWORD) (&genericparams));
		mciSendCommand(mcidevice, MCI_CLOSE, MCI_WAIT, (DWORD) (&genericparams));

		midiplaying = 0;
		mcidevice = 0;
	}
}

