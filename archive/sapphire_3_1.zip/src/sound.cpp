#include "framework.h"
#include "sound.h"


static vector<Sound*> soundcache;


static char* soundname[snd_end] = {
"walk", 
"dig", 
"win",
"lose", 
"die",
"push",
"pushbomb",
"pushbag", 
"pushbox", 
"cushion",
"pcushion",
"elevator",
"grabemld",
"grabsphr",
"grabruby",
"grabbomb",
"grabkey",
"setbomb",
"usedoor",
"stnroll",
"stnfall",
"stnhard", 
"stnconv",
"emldroll",
"emldfall",
"emldconv",
"sphrroll",
"sphrfall",
"sphrbrk",
"sphrconv",
"rubyroll",
"rubyfall",
"rubyconv",
"bagroll",
"bagfall",
"bagopen",
"bagconv",
"bombroll",
"exitopen",
"exitclos",
"bombtick",
"blastvip",
"explode",
"swamp",
"drop",
"lorry",
"bug",
"yamyam",
"acid",
"clock",
"laser",
"wheel",
"robot"
};


void releaseSoundCache()
{
	for (int i=0; i<soundcache.size(); i++) {
		delete soundcache[i];
	}
	soundcache.clear();
}


SoundSet::SoundSet() 
{
	for (int i=0; i<snd_end; i++) sound[i]=NULL;
	activateSound();
}


SoundSet::~SoundSet ()
{
	deactivateSound();
	unload();
}

void SoundSet::load(charstring& name)
{
	for (int s=0; s<snd_end; s++) {
		char fname[200];

		sprintf (fname, "sound\\%s.zip#%s.wav", name.data(), soundname[s]);
		if ( loadOrReuseSound (charstring(fname),s)) continue;

		sprintf (fname, "sound\\%s\\%s.wav", name.data(), soundname[s]);
		if ( loadOrReuseSound (charstring(fname),s)) continue;

		sprintf (fname, "sound\\standard.zip#%s.wav", soundname[s]);
		if ( loadOrReuseSound (charstring(fname),s)) continue;

		sprintf (fname, "sound\\standard\\%s.wav", soundname[s]);
		if ( loadOrReuseSound (charstring(fname),s)) continue;

		doLog (2, "could not load sound: %s", name.data());
	}

	releaseSoundCache();
}

void SoundSet::unload () 
{
	releaseSoundCache();

	for (int i=0; i<snd_end; i++) {
		if (sound[i]) {
			soundcache.resize(i+1, NULL);
			soundcache[i] = sound[i];
			sound[i] = NULL;
		}
	}
}

bool SoundSet::loadOrReuseSound (charstring& fname, int index)
{
	// check, if we already have the sound in our cache
	if (soundcache.size()>index) {
		Sound* s = soundcache[index];
		if (s) {
			if (_stricmp (s->filename.data(), fname.data())==0) {
				soundcache[index] = NULL;
				sound[index] = s;
				return true;
			}
		}
	}

	// otherwise try to load it from the file
	return ( (sound[index] = loadSound (fname, 4.5)) != NULL);
}

SoundPlayer::SoundPlayer (Game* g, charstring& defaultsound)
{
	game = g;
	soundset = new SoundSet;

	if (game->level->soundwork != "") soundset->load(game->level->soundwork);
	else						      soundset->load(defaultsound);
}

SoundPlayer::~SoundPlayer()
{
	if (soundset) delete soundset;
}


void SoundPlayer::run()
{
	if (!game->isSoundTime()) return;

	for (int s=0; s<snd_end; s++) {
		int v = game->getSound( (soundtype) s);
		if (v>Game::volume_silence) {
			Sound* snd = soundset->sound[s];
			if (snd!=NULL) snd->play(v);
		}
	}
}

