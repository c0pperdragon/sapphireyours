#include <stdio.h>
#include "lang.h"
#include "toolbox.h"
#include "framework.h"


static charstring currentlanguage = DEFAULTLANGUAGE;
static vector<charstring*> strings;
static vector<bool> unfinished;


int getavailablelanguages(vector<charstring>& languagelist)
{
	char* n;
	findhandle h;

	languagelist.clear();

	n = findfirstfile (&h,"language\\*");
	while (n!=NULL) {
//		charstring txt = charstring ("language\\") + n;
//		if (n[0] != '.' && !isdirectory (txt.data())) {
			// cut away the trailing ".txt" of the filename
			charstring txt = n;
			if (txt.size()>4 && _stricmp (txt.data()+txt.size()-4, ".txt") == 0) {
				txt.resize(txt.size()-4);
				languagelist.push_back(txt);
			}
//		}
		n = findfile (&h);
	}
	stopfindfile (&h);
	sortstringlist (languagelist);

	int languageidx = 0;
	for (int lidx=0; lidx<languagelist.size(); lidx++) {
		if (_stricmp (languagelist[lidx].data(), getcurrentlanguage()->data()) == 0) {
			languageidx = lidx;
		}
	}
	return languageidx;
}


void setcurrentlanguage(charstring& lang) 
{
	currentlanguage = lang;
	doDownCase(currentlanguage);
}

charstring* getcurrentlanguage() 
{
	return &currentlanguage;
}



void loadlanguagefromfile(char* langname)
{
	char fname[200];
	char line[5000];
	char *value;
	FILE *f;
	int i;

	sprintf (fname, "language\\%s.txt", langname);
	for (int uidx=0; uidx<unfinished.size(); uidx++) unfinished[uidx]=false;

	// load texts from the file
	f = fopen (fname, "r");
	if (!f) return;

	while (!feof(f)) {
		fgets (line, 5000, f);
		for (i=0; ((unsigned char)line[i]) >= ' ' && line[i] != '='; i++) {
			if (line[i] >= 'A' && line[i] <= 'Z') line[i] += ('a' - 'A');
		}
		if (line[i] == '=') {
			value = line+i+1;
			line[i] = '\0';

			int vlen = strlen(value);
			while (vlen>0 && ((unsigned char)value[vlen-1])<=' ') vlen--;
			value[vlen] = '\0';

			if (vlen>0 && value[vlen-1]=='�') {  // cut off trailing '�'
				value[--vlen] = '\0';
			}

			int num = atoi (line);
			if (num>0) {
				if (strings.size() <= num) {
					strings.resize(num+1, NULL);
					unfinished.resize(num+1, false);
				}
			}

			if (strings[num] && unfinished[num]) {
				(*strings[num]) += "\n";
				(*strings[num]) += value;
			} else {
				if (!strings[num]) strings[num] = new charstring(value);
				else *(strings[num]) = value;
			}
			unfinished[num] = true;
		}
	}

	fclose (f);
}



void loadlanguage()
{
	unloadlanguage();
	loadlanguagefromfile (DEFAULTLANGUAGE);
	if (currentlanguage != DEFAULTLANGUAGE) 
		loadlanguagefromfile ( (char*) (currentlanguage.data()) );
}

void unloadlanguage()
{
	for (int i=0; i<strings.size(); i++) {
		if (strings[i]) delete strings[i];
	}
	strings.clear();
}

charstring* getstring(int id)
{
	if (id>=strings.size() || id<0 || strings[id]==NULL) return &currentlanguage;
	return strings[id];
}

char* getstringdata(int id)
{
	return (char*) (getstring(id)->data());
}



mlangstring::mlangstring()
{
	languages.resize(1);
	languages[0] = DEFAULTLANGUAGE;
	contents.resize(1);
	contents[0] = "";
}

void mlangstring::setstring (charstring& language, charstring& str)
{
	// if we want to clear a string of a non-default language
	if (str=="" && _stricmp(language.data(),DEFAULTLANGUAGE)!=0) {
		for (int i=0; i<languages.size(); i++) {
			if (_stricmp(languages[i].data(), language.data())==0) {
				languages.erase(&languages[i]);
				contents.erase(&contents[i]);
				return;
			}
		}
		return;
	}

	// find the entry we want to overwrite
	for (int i=0; i<languages.size(); i++) {
		if (_stricmp(languages[i].data(), language.data())==0) {
			contents[i] = str;
			return;
		}
	}

	// if no existing entry was found, we create a new one
	languages.resize(i+1);
	languages[i] = language;
	contents.resize(i+1);
	contents[i] = str;
}

charstring* mlangstring::getdefault ()
{
	return &(contents[0]);
}

charstring* mlangstring::get(charstring& language)
{
	for (int i=0; i<languages.size(); i++) {
		if (_stricmp (languages[i].data(), language.data())==0) {
			return &(contents[i]);
		}
	}
	return NULL;
}

charstring* mlangstring::get ()
{
	charstring*s = get(currentlanguage);
	if (s) return s;
	return getdefault();
}


void mlangstring::copy (mlangstring& m)
{
	languages = m.languages;
	contents = m.contents;
}



mlangstringlist::mlangstringlist()
{
	clear();
}

void mlangstringlist::addstring (charstring& language, charstring& str)
{
	// try to find an existing entry
	for (int i=0; i<languages.size(); i++) {
		if (_stricmp (languages[i].data(), language.data())==0) {
			contents[i].push_back(str);
			return;
		}
	}

	// create new entry
	languages.resize(i+1);
	languages[i] = language;
	contents.resize(i+1);
	contents[i].clear();
	contents[i].push_back (str);
}

void mlangstringlist::setlist (charstring& language, vector<charstring>& strlist)
{
	// if we want to erase a nondefault language entry
	if (strlist.size()==0 && _stricmp(language.data(),DEFAULTLANGUAGE)!=0) {
		for (int i=0; i<languages.size(); i++) {
			if (_stricmp(languages[i].data(), language.data())==0) {
				languages.erase(&languages[i]);
				contents.erase(&contents[i]);
				return;
			}
		}
		return;
	}

	// find existing entry to overwrite
	for (int i=0; i<languages.size(); i++) {
		if (_stricmp (languages[i].data(), language.data())==0) {
			contents[i] = strlist;
			return;
		}
	}

	// create new entry
	languages.resize(i+1);
	languages[i] = language;
	contents.resize(i+1);
	contents[i] = strlist;
}

vector<charstring>* mlangstringlist::getdefaultlist ()
{
	return &(contents[0]);
}

vector<charstring>* mlangstringlist::getlist(charstring& language)
{
	for (int i=0; i<languages.size(); i++) {
		if (_stricmp (languages[i].data(), language.data())==0) {
			return &(contents[i]);
		}
	}
	return NULL;
}

vector<charstring>* mlangstringlist::getlist()
{
	vector<charstring>* v = getlist(currentlanguage);
	if (v) return v;
	return getdefaultlist();
};


void mlangstringlist::clear()
{
	languages.resize(1);
	languages[0] = DEFAULTLANGUAGE;
	contents.resize(1);
	contents[0] . clear();
}

void mlangstringlist::copy (mlangstringlist& m)
{
	languages = m.languages;
	contents = m.contents;
}
