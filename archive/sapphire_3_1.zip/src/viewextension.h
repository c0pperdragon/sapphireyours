#ifndef _VIEWEXTENSION_H
#define _VIEWEXTENSION_H

#include "viewbox.h"
#include "inputbox.h"

// -------------- non system dependent extensions to the graphics ------------


class ImageFrame : public Frame {
public:
	Image* img;

public:
	ImageFrame (int l, int t, bool transp, Image* i);
	virtual ~ImageFrame ();

	virtual void update (int currentpage, int l, int t, int r, int b);
};

class CoordinatesFrame : public Frame {
public:
	Image* img;
	int coordlength;
	int coordx;
	int coordy;

public:
	CoordinatesFrame (int l, int t, bool transp, Image* i, int clength);
	virtual ~CoordinatesFrame ();

	virtual void update (int currentpage, int l, int t, int r, int b);
	void setCoords (int x, int y);
};

class TileFrame : public Frame {
private:
	Image* img;

public:
	TileFrame (int l, int t, int r, int b, bool transp, Image* i);
	virtual ~TileFrame ();

	virtual void update (int currentpage, int l, int t, int r, int b);
};


class ColorFrame : public Frame {
private:
	int color;

public:
	ColorFrame (int l, int t, int r, int b, int color);
	virtual ~ColorFrame ();

	virtual void update (int currentpage, int l, int t, int r, int b);
};

class BackgroundColorFrame : public ColorFrame
{
public:
	BackgroundColorFrame (int color);
	virtual ~BackgroundColorFrame ();
};


class BufferedTransparentFrame : public Frame {
private:
	RectangleList cleanbuffer[2];
protected:
	Surface* buffer;
	int transparentcolor;

public:
	BufferedTransparentFrame (int l, int t, int r, int b, int _transparentcolor);
	virtual ~BufferedTransparentFrame ();

	virtual void updateBuffer (int x1, int y1, int x2, int y2) = 0;
	virtual void subtractFreeArea (RectangleList& usedarea) = 0;

	void setAllDirty();
	void setDirty (int l,int t, int r, int b);
	virtual void update (int currentpage, int x1, int y1, int x2, int y2);
	virtual void computeChanges (int currentpage, list<Frame*>::reverse_iterator& revit);
	virtual void drawChanges (int currentpage, list<Frame*>::iterator& it);
};


class FrameCaller : public SelfRunner {
public:
	Frame* frame;

	FrameCaller ();
	~FrameCaller ();

	void setFrame(Frame* f);
	virtual void run();
};



class MouseCursor : SelfRunner {
	Mouse mouse;
	ImageFrame frame;
	CoordinatesFrame coordframe;

	int hotx;
	int hoty;
	int width;
	int height;

	bool enabled;

public:
	MouseCursor (int startx, int starty, Image* i, Image* digits, int hotx, int hoty);
	virtual ~MouseCursor();
	
	Frame* getFrame() { return &frame; };

	int getMouseX();
	int getMouseY();
	
	int getBorderPushX();
	int getBorderPushY();
	void resetBorderPush();
	bool isButtonDown(int button);
	bool isButtonNew(int button);
	void forgetButton(int button);

	void enable(bool yesno);
	void setDisplayedCoordinates(int x, int y);

	virtual void run();
};


class ToolbarFrame : public ImageFrame {
	int rows;
	int cols;
	int iconsize;
	int xoffset;
	int yoffset;

	enum {maxselections=2};
	int selectcolor[maxselections];

	int selectedcol[maxselections];
	int selectedrow[maxselections];

public:
	ToolbarFrame (int l, int t, Image* i, 
		int _cols, int _rows, int _iconsize, int _xoffset, int _yoffset,
		int _selectcolor, int _selectcolor2);
	virtual ~ToolbarFrame();

	virtual void update (int currentpage, int l, int t, int r, int b);

	bool selectIcon(int s, int x, int y);
	int getColumn(int s) { return selectedcol[s]; };
	int getRow(int s) { return selectedrow[s]; };
};


#endif

