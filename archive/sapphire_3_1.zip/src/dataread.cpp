#include "dataread.h"
#include "framework.h"

static list<ZipFile*> allzips;


// -------------------- object factory ----------------------------

ZipFile* createZip(charstring& fname)
{
	// check, if we already have read the file
	for (list<ZipFile*>::iterator it=allzips.begin(); it!=allzips.end(); it++) {
		if ( (*it)->filename == fname) return *it;
	}

	// try to read and memorize a new zip
	ZipFile* zip = new ZipFile();
	if (zip->open(fname)) {
		allzips.push_front(zip);
		return zip;
	}
	delete zip;
	return NULL;
}

void closeZipFiles()
{
	for (list<ZipFile*>::iterator it=allzips.begin(); it!=allzips.end(); it++) {
		delete *it;
	}
	allzips.clear();
}

DataReader* openDataReader(charstring& fname)
{
	// if the filename contains a '#' we want to read something from a ZIP
	for (int i=0; i<fname.size(); i++) {
		if (fname[i]=='#') {
			ZipFile* zip = createZip (fname.substr(0,i));
			if (!zip) return NULL;
			if (! (zip->startRead(fname.substr(i+1,fname.size()-i-1)) )) return NULL;
			return new ZipReader(zip);
		}
	}

	// normal file read
	FILE* f = fopen(fname.data(),"rb");
	if (!f) return NULL;
	return new FileReader(f);
}


// --------------------- exported access objects --------------------

DataReader::DataReader()
{
}

DataReader::~DataReader()
{
}

void DataReader::skipBytes(int length)
{
	unsigned char buffer[100];
	while (length>100) {
		readBytes(buffer,100);
		length-=100;
	}
	readBytes (buffer,length);
}

unsigned long DataReader::readInt32()
{
	unsigned char b[4];
	if (readBytes (b, 4) < 4) return 0;
	return     ((unsigned long) b[0]) 
		   + ( ((unsigned long) b[1]) << 8 )
		   + ( ((unsigned long) b[2]) << 16 )
		   + ( ((unsigned long) b[3]) << 24 );
}

unsigned long DataReader::readInt16()
{
	unsigned char b[2];
	if (readBytes (b, 2) < 2) return 0;
	return     ((unsigned long) b[0]) 
		   + ( ((unsigned long) b[1]) << 8 );
}

FileReader::FileReader(FILE* f)
{
	file = f;
}

FileReader::~FileReader()
{
	if (file) fclose(file);
}

int FileReader::readBytes(unsigned char* buffer, int bufferlength)
{
	return fread(buffer,1,bufferlength,file);
}

ZipReader::ZipReader(ZipFile* zip)
{
	zipfile = zip;
}

ZipReader::~ZipReader()
{
	zipfile->stopRead();
}

int ZipReader::readBytes(unsigned char* buffer, int bufferlength)
{
	return zipfile->readBytes(buffer,bufferlength);
}


// ------------------------ internal objects ------------------------------

HuffmanTree::HuffmanTree()
{
	clear();
}

HuffmanTree::~HuffmanTree()
{
}

void HuffmanTree::clear()
{
	numvalues=0;
	highestbitlength=0;
}

void HuffmanTree::addBitLength(int codebitsize)
{
	bitlength[numvalues++] = codebitsize;
	if (codebitsize>highestbitlength) highestbitlength=codebitsize;
}

void HuffmanTree::constructTree()
{
	numstates=0;

	currentbitlength=1;
	currentvalue=-1;
	findNextValue();

	buildTree (0);
}

void HuffmanTree::startRetrieval()
{
	currentstate = 0;
}

int	HuffmanTree::continueRetrieval(int bit)
{
	int v = follower[currentstate][bit];
	currentstate = -v;
	return v;
}

int HuffmanTree::buildTree(int level)
{
	if (currentbitlength==level) 
	{
		int v = currentvalue;
		findNextValue();
		return v;
	}
	int s = numstates++;
	follower[s][0] = buildTree(level+1);
	follower[s][1] = buildTree(level+1);
	return -s;
}

void HuffmanTree::findNextValue()
{
	for (;;) 
	{
		currentvalue++;
		if (currentvalue>=numvalues) 
		{
			currentbitlength++;
			currentvalue=-1;
			if (currentbitlength>highestbitlength) {  // no more values there
				currentvalue=0;
				return;
			}
		} 
		else 
		{
			if (bitlength[currentvalue] == currentbitlength) return;
		}
	}
}



ZipFile::ZipFile()
{
	current=NULL;
	file=NULL;
}

ZipFile::~ZipFile()
{
	for (std::list<ZipContent*>::iterator it=contents.begin(); it!=contents.end(); it++)
	{
		delete *it;
	}
	if (file) fclose(file);
}

bool ZipFile::open(charstring& _filename)
{
	filename = _filename;
	if ((file = fopen (_filename.data(), "rb"))==NULL) return false;

	currentoffset = 0;

	// read all local file headers
	for (;;)
	{
		unsigned char sig[4];
		if (fread (sig, 1,4, file) < 4) return false;
		currentoffset+=4;

		if (sig[0]==0x50 && sig[1]==0x4b && sig[2]==0x03 && sig[3]==0x04) 
		{
			// read one local file header
			ZipContent* c = new ZipContent(this);
			contents.push_back(c);
			if (!c->readHeader()) return false;
		} 
		else if (sig[0]==0x50 && sig[1]==0x4b && sig[2]==0x07 && sig[3]==0x08) 
		{
			// skip one data descriptor
			unsigned char dummy[3*4];
			fread (dummy, 3,4,file);
			currentoffset += 3*4;
		}
		else return true;  // begin of central directory
	}

	return true;
}



bool ZipFile::startRead(charstring& _contentname)
{
	if (current) return false;

	for (std::list<ZipContent*>::iterator it=contents.begin(); it!=contents.end(); it++) 
	{
		ZipContent* c = *it;
		if ( _stricmp(c->contentname.data(),_contentname.data())==0 ) 
		{
			fseek (file, c->offset, SEEK_SET);

			switch (c->compressionmethod)
			{
			case 0x0000:
				current = new ZipDecoderStored(c);
				return true;
			case 0x0008:
				current = new ZipDecoderDeflated(c);
				return true;
			default:
				return false;
			}
		}
	}
	return false;
}

void ZipFile::stopRead()
{
	delete current;
	current = NULL;
}


int ZipFile::readBytes(unsigned char* buffer, int bufferlength)
{
	if (!current) return 0;
	return current->readBytes(buffer,bufferlength);
}





ZipContent::ZipContent(ZipFile* _owner)
{
	owner = _owner;
}

ZipContent::~ZipContent()
{
}

bool ZipContent::readHeader()
{
	unsigned char buffer[1001];
	int filenamelength;
	int extrafieldlength;
	int i;
	
	fread (buffer, 2+2,1,owner->file);

	fread (buffer, 2,1,owner->file);
	compressionmethod = ((int)buffer[0]) + ( ((int)buffer[1])<<8 );
	
	fread (buffer, 2+2+4,1,owner->file);

	fread (buffer, 4,1,owner->file);
	compressedsize =  ((int)buffer[0]) +        (((int)buffer[1])<<8)
		  			+ (((int)buffer[2])<<16) +  (((int)buffer[3])<<24);

	fread (buffer, 4,1,owner->file);

	fread (buffer, 2,1,owner->file);
	filenamelength = ((int)buffer[0]) + ( ((int)buffer[1])<<8 );

	fread (buffer, 2,1,owner->file);
	extrafieldlength = ((int)buffer[0]) + ( ((int)buffer[1])<<8 );

	if (filenamelength>1000) return false;
	if (fread (buffer, 1,filenamelength, owner->file) < filenamelength) return false;
	buffer[filenamelength] = '\0';
	contentname = (char*) buffer;

	for (i=0; i<extrafieldlength; i++) fread(buffer,1,1,owner->file);

	owner->currentoffset += 26+filenamelength+extrafieldlength;
	offset = owner->currentoffset;

	owner->currentoffset += compressedsize;
	if (fseek (owner->file, owner->currentoffset, SEEK_SET) != 0) return false;

	return true;
}



ZipDecoder::ZipDecoder(ZipContent* _content)
{
	content = _content;
	bitbufferlength=0;
}

ZipDecoder::~ZipDecoder()
{
}

inline void ZipDecoder::readRawBytes(unsigned char* buffer, int bufferlength)
{
	fread (buffer, 1,bufferlength, content->owner->file);
}

inline int ZipDecoder::readRawBit()
{
	if (bitbufferlength==0) {
		readRawBytes (&bitbuffer,1);
		bitbufferlength=8;
	}
	int bit = bitbuffer & 1;
	bitbuffer >>= 1;
	bitbufferlength--;

	return bit;
}

inline int ZipDecoder::readRawBits(int numberofbits)
{
	int bits=0;
	for (int i=0; i<numberofbits; i++) 
	{
		bits |= (readRawBit() << i);
	}
	return bits;
}

inline void ZipDecoder::skipRawBitsToAlign()
{
	bitbufferlength=0;
}


ZipDecoderStored::ZipDecoderStored(ZipContent* _content)
: ZipDecoder(_content)
{	
	bytesleft = content->compressedsize;
}

ZipDecoderStored::~ZipDecoderStored()
{
}

int ZipDecoderStored::readBytes(unsigned char *buffer, int bufferlength)
{
	int b = (bytesleft<bufferlength) ? bytesleft : bufferlength;
	readRawBytes(buffer,bufferlength);
	
	bytesleft-=b;
	return b;
}




ZipDecoderDeflated::ZipDecoderDeflated(ZipContent* _content)
: ZipDecoder(_content)
{
	endoffile = false;
	dictionarypointer = 0;
	readBlockStart();
}

ZipDecoderDeflated::~ZipDecoderDeflated()
{
}

int ZipDecoderDeflated::readBytes(unsigned char *buffer, int bufferlength)
{
	if (endoffile) return 0;

	int i;
	for (i=0; i<bufferlength; i++) {
		if (!readOneByte(buffer+i)) {
			endoffile=true; return i;
		}

		dictionary[dictionarypointer++] = *(buffer+i);
		dictionarypointer %= DICTIONARYSIZE;
	}
	return i;
}




void ZipDecoderDeflated::readBlockStart()
{
	unsigned char buffer[2];
	int i;

	lastblock = (readRawBit()!=0);
	uncompressed = false;
	lookuplength = 0;

	switch (readRawBits(2)) {
	default:
		skipRawBitsToAlign();
		readRawBytes (buffer,2);
		uncompressed = true;
		uncompressedbytesleft = ((int)buffer[0]) + ( ((int)buffer[1])<<8 );
		readRawBytes (buffer,2);
		break;

	case 1:
		literalcodes.clear();
		for (i=0; i<=143; i++) literalcodes.addBitLength(8);
		for (i=144; i<=255; i++) literalcodes.addBitLength(9);
		for (i=256; i<=279; i++) literalcodes.addBitLength(7);
		for (i=280; i<=287; i++) literalcodes.addBitLength(8);
		literalcodes.constructTree();

		distancecodes.clear();
		for (i=0; i<=31; i++) distancecodes.addBitLength(5);
		distancecodes.constructTree();
		break;

	case 2:
		readHuffmanTrees();
		break;
	}
}


void ZipDecoderDeflated::readHuffmanTrees()
{
	int literalcodenum   = readRawBits(5) + 257;
	int distancecodenum  = readRawBits(5) + 1;
	int bitlengthcodenum = readRawBits(4) + 4;
	static int bitcodeorder[19] = { 16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15 };

	int bitlengthbuffer[19];
	int i;
	for (i=0; i<bitlengthcodenum; i++) bitlengthbuffer[bitcodeorder[i]] = readRawBits(3);
	for (; i<19; i++) bitlengthbuffer[bitcodeorder[i]]=0;
	bitlengthcodes.clear();
	for (i=0; i<19; i++) bitlengthcodes.addBitLength (bitlengthbuffer[i]);
	bitlengthcodes.constructTree();

	readHuffmanTree (&literalcodes,  literalcodenum);
	readHuffmanTree (&distancecodes, distancecodenum);
}

void ZipDecoderDeflated::readHuffmanTree (HuffmanTree* tree,int codenum)
{
	tree->clear();

	int prevlen=0;
	while (tree->numberOfBitLengths() < codenum) {
		int len = readHuffmanValue(&bitlengthcodes);

		if (len<=15) 
		{
			tree->addBitLength(len);
			prevlen=len;
		}
		else if (len==16) 
		{
			len = readRawBits(2) + 3;
			for (int j=0; j<len; j++) tree->addBitLength(prevlen);
		}
		else if (len==17) 
		{
			len = readRawBits(3) + 3;
			for (int j=0; j<len; j++) tree->addBitLength(0);
		}
		else if (len==18) 
		{
			len = readRawBits(7) + 11;
			for (int j=0; j<len; j++) tree->addBitLength(0);
		}
	}
	tree->constructTree();
}

int ZipDecoderDeflated::readHuffmanValue (HuffmanTree* tree)
{
	tree->startRetrieval();
	for (;;) {
		int val = tree->continueRetrieval (readRawBit());
		if (val>=0) return val;
	}
}


bool ZipDecoderDeflated::readOneByte(unsigned char* buffer)
{
readagain:
	// handle uncompressed blocks
	if (uncompressed) {
		if (uncompressedbytesleft>0) {
			uncompressedbytesleft--;
			readRawBytes (buffer,1);
			return true;
		}
		if (lastblock) return false;
		readBlockStart();
		goto readagain;
	}

	// handle situation when we are in the middle of a dictionary look-up
	if (lookuplength>0) {
		*buffer = dictionary[lookupposition++];
		lookupposition %= DICTIONARYSIZE;
		lookuplength--;
		return true;
	}

	// read data from compressed stream
	int lit =  readHuffmanValue (&literalcodes);
	if (lit<256) {
		*buffer = (unsigned char) (lit & 0xff);
		return true;
	}

	// end of block
	if (lit==256) {
		if (lastblock) return false;
		readBlockStart();
		goto readagain;
	}

	// cause dictionary lookup
	static int lengthvalue[31] = 
		{3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,
		51,59,67,83,99,115,131,163,195,227,258,0,0 };
	static int lengthextra[31] = 
		{0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0};
	static int distancevalue[32] = 
		{1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,
		257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0};
	static int distanceextra[32] = 
		{0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0};

	int len = lengthvalue[lit-257] + readRawBits(lengthextra[lit-257]);
	
	lit = readHuffmanValue (&distancecodes);
	int dist = distancevalue[lit] + readRawBits(distanceextra[lit]);

	lookuplength = len;
	lookupposition = (dictionarypointer+DICTIONARYSIZE-dist) % DICTIONARYSIZE;

	goto readagain;
}
