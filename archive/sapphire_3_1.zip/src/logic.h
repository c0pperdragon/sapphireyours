#ifndef _LOGIC_H
#define _LOGIC_H

#include "types.h"
#include "lang.h"
#include "inputbox.h"

void initLogic();

class LevelHeader;
class Level;
class Game;
class InputHandler;

enum { maxlevelwidth=128 };
enum { maxlevelheight=128 };
enum { maxinputchannels = 4 };
enum { checkpointintervall = 50 };
enum { maxyamyamnum=50 };

#define DEFAULTSWAMPRATE		30
#define DEFAULTPUSHPROB			4
#define DEFAULTDISPENSERSPEED	5
#define DEFAULTELEVATORSPEED    1
#define DEFAULTWHEELTURNTIME	30
#define DEFAULTROBOTSPEED		3

#define MAXCATEGORIES 8

typedef unsigned char tiletype;
enum {
	tile_invalid=0, tile_air,
	
	tile_earth,   tile_earthr,  tile_earthl,   tile_earthlr,
	tile_earthd,  tile_earthdr, tile_earthdl,  tile_earthdlr,  
	tile_earthu,  tile_earthur, tile_earthul,  tile_earthulr,  
	tile_earthud, tile_earthudr,tile_earthudl, tile_earthudlr,  

	tile_wall, tile_stonewall, tile_glasswall, tile_invisiblewall, tile_wallemerald,
	tile_stone, tile_bag, tile_bomb, tile_roundwall, tile_sand, tile_sandfull,
    tile_door, tile_door_opened,
    tile_doorblue, tile_doorred, tile_doorgreen, tile_dooryellow,
    tile_emerald, tile_sapphire, tile_ruby, tile_timebomb, tile_tickbomb, tile_timebomb10,

    tile_keyblue1, tile_keyblue2, tile_keyblue3, tile_keyblue4, tile_keyblue5,
	tile_keyred1, tile_keyred2, tile_keyred3, tile_keyred4, tile_keyred5,
	tile_keygreen1, tile_keygreen2, tile_keygreen3, tile_keygreen4, tile_keygreen5,
	tile_keyyellow1, tile_keyyellow2, tile_keyyellow3, tile_keyyellow4, tile_keyyellow5,

    tile_box, tile_cushion, tile_elevator, tile_convert, tile_dispenser1, tile_dispenser2,
	tile_pusherleft, tile_pusherright,

	tile_acid1, tile_acid2, tile_acid3, tile_acid4, tile_acid5,
	tile_acidright1, tile_acidright2, tile_acidright3, tile_acidright4, tile_acidright5,
	tile_acidleft1, tile_acidleft2, tile_acidleft3, tile_acidleft4, tile_acidleft5,
	tile_acidalone1, tile_acidalone2, tile_acidalone3, tile_acidalone4, tile_acidalone5,

    tile_swamp, tile_drop,

	tile_explode1, tile_explode2, tile_explode3, tile_explode4, tile_explode5,
                  
    tile_lorryleft,
    tile_lorryright,
    tile_lorryup,  
    tile_lorrydown, 
                  
	tile_bugleft,  
    tile_bugright, 
    tile_bugup,  
    tile_bugdown,

    tile_yamyamleft,tile_yamyamright,
    tile_yamyamup, tile_yamyamdown, tile_yamyam,

	tile_robot1, tile_robot2, tile_wheel,

	tile_1rest,
	tile_1walkup,tile_1walkdown,tile_1walkleft,tile_1walkright,
	tile_1digup,tile_1digdown,tile_1digleft,tile_1digright,
	tile_1pushup,tile_1pushdown,tile_1pushleft,tile_1pushright,
	tile_2rest,
	tile_2walkup,tile_2walkdown,tile_2walkleft,tile_2walkright,
	tile_2digup,tile_2digdown,tile_2digleft,tile_2digright,
	tile_2pushup,tile_2pushdown,tile_2pushleft,tile_2pushright,

	tile_movie0_0,
	tile_movie1_0,
	tile_movie2_0, 
	tile_movie3_0, 
	tile_movie4_0,
	tile_movie5_0, tile_movie5_1, 
	tile_movie6_0, tile_movie6_1, 
	tile_movie7_0, tile_movie7_1, 
	tile_movie8_0, tile_movie8_1, 
	tile_movie9_0, tile_movie9_1, 
	tile_movie10_0, tile_movie10_1, tile_movie10_2, tile_movie10_3,
	tile_movie11_0, tile_movie11_1, tile_movie11_2, tile_movie11_3,
	tile_movie12_0, tile_movie12_1, tile_movie12_2, tile_movie12_3,
	tile_movie13_0, tile_movie13_1, tile_movie13_2, tile_movie13_3,
	tile_movie14_0, tile_movie14_1, tile_movie14_2, tile_movie14_3,
	tile_movie15_0, tile_movie15_1, tile_movie15_2, tile_movie15_3, tile_movie15_4, tile_movie15_5, tile_movie15_6, tile_movie15_7, 
	tile_movie16_0, tile_movie16_1, tile_movie16_2, tile_movie16_3, tile_movie16_4, tile_movie16_5, tile_movie16_6, tile_movie16_7, 
	tile_movie17_0, tile_movie17_1, tile_movie17_2, tile_movie17_3, tile_movie17_4, tile_movie17_5, tile_movie17_6, tile_movie17_7, 
	tile_movie18_0, tile_movie18_1, tile_movie18_2, tile_movie18_3, tile_movie18_4, tile_movie18_5, tile_movie18_6, tile_movie18_7, 
	tile_movie19_0, tile_movie19_1, tile_movie19_2, tile_movie19_3, tile_movie19_4, tile_movie19_5, tile_movie19_6, tile_movie19_7
};

typedef unsigned char sequencetype;
enum {
	seq_earthup, seq_earthdown, seq_earthleft, seq_earthright,
	seq_stonerest, seq_stonedown, seq_stoneleft, seq_stoneright, seq_sand,
	seq_emeraldrest, seq_emeralddown, seq_emeraldleft, seq_emeraldright,
	seq_emeraldglitter, seq_emeraldaway,
	seq_sapphirerest,seq_sapphiredown, seq_sapphireleft, seq_sapphireright,
	seq_sapphireglitter, seq_sapphirebreak, seq_sapphireaway,
	seq_rubyrest, seq_rubydown, seq_rubyleft, seq_rubyright, seq_rubyaway,
	seq_bagrest, seq_bagdown, seq_bagleft, seq_bagright, seq_bagexpl,
	seq_bombrest, seq_bombdown, seq_bombleft, seq_bombright,
	seq_dooropen, seq_doorclose, seq_doorisopen,
	seq_cushion, seq_cushionbumb, seq_elevatorup, seq_elevatordown,
	seq_pushleftforward, seq_pushleftbackward, seq_pushrightforward, seq_pushrightbackward,
	seq_box,
	seq_laserbr, seq_lasertl, seq_laserbl, seq_lasertr, seq_laserv, seq_laserh,
	seq_tickbomb,
	seq_explode1, seq_explode2, seq_explode3, seq_explode4, seq_explode5,
	seq_swamp, seq_dropup, seq_dropdown, seq_dropleft, seq_dropright, seq_drop, seq_drophit,
	seq_convert, 
	seq_dispenser1, seq_dispenser2,
	seq_acid1, seq_acid2, seq_acid3, seq_acid4, seq_acid5,
	seq_acidleft, seq_acidright, seq_acidalone,
	seq_lorryleft, seq_lorryright, seq_lorryup, seq_lorrydown,
	seq_lorryturnleftdown, seq_lorryturnleftup, 
	seq_lorryturnupleft, seq_lorryturnupright,
	seq_lorryturnrightup, seq_lorryturnrightdown,
	seq_lorryturndownleft, seq_lorryturndownright,
	seq_bugleft, seq_bugright, seq_bugup, seq_bugdown,
	seq_bugturnleftdown, seq_bugturnleftup, 
	seq_bugturnupleft, seq_bugturnupright,
	seq_bugturnrightup, seq_bugturnrightdown,
	seq_bugturndownleft, seq_bugturndownright,
	seq_yamyamleft, seq_yamyamright, seq_yamyamup, seq_yamyamdown, seq_yamyaming,
	seq_robot1, seq_robot2, seq_wheel,
	seq_doorblue, seq_doorred, seq_doorgreen, seq_dooryellow,
	seq_keyblue1, seq_keyblue2, seq_keyblue3, seq_keyblue4, seq_keyblue5,
	seq_keyred1, seq_keyred2, seq_keyred3, seq_keyred4, seq_keyred5,
	seq_keygreen1, seq_keygreen2, seq_keygreen3, seq_keygreen4, seq_keygreen5,
	seq_keyyellow1, seq_keyyellow2, seq_keyyellow3, seq_keyyellow4, seq_keyyellow5,

	seq_1rest,
	seq_1walkup,seq_1walkdown,seq_1walkleft,seq_1walkright,
	seq_1digup,seq_1digdown,seq_1digleft,seq_1digright,
	seq_1pushup,seq_1pushdown,seq_1pushleft,seq_1pushright,
	seq_1blink,
	seq_2rest,
	seq_2walkup,seq_2walkdown,seq_2walkleft,seq_2walkright,
	seq_2digup,seq_2digdown,seq_2digleft,seq_2digright,
	seq_2pushup,seq_2pushdown,seq_2pushleft,seq_2pushright,
	seq_2blink,

	seq_movie0_0,
	seq_movie1_0,
	seq_movie2_0, 
	seq_movie3_0, 
	seq_movie4_0,
	seq_movie5_0, seq_movie5_1, 
	seq_movie6_0, seq_movie6_1, 
	seq_movie7_0, seq_movie7_1, 
	seq_movie8_0, seq_movie8_1, 
	seq_movie9_0, seq_movie9_1, 
	seq_movie10_0, seq_movie10_1, seq_movie10_2, seq_movie10_3,
	seq_movie11_0, seq_movie11_1, seq_movie11_2, seq_movie11_3,
	seq_movie12_0, seq_movie12_1, seq_movie12_2, seq_movie12_3,
	seq_movie13_0, seq_movie13_1, seq_movie13_2, seq_movie13_3,
	seq_movie14_0, seq_movie14_1, seq_movie14_2, seq_movie14_3,
	seq_movie15_0, seq_movie15_1, seq_movie15_2, seq_movie15_3, seq_movie15_4, seq_movie15_5, seq_movie15_6, seq_movie15_7, 
	seq_movie16_0, seq_movie16_1, seq_movie16_2, seq_movie16_3, seq_movie16_4, seq_movie16_5, seq_movie16_6, seq_movie16_7, 
	seq_movie17_0, seq_movie17_1, seq_movie17_2, seq_movie17_3, seq_movie17_4, seq_movie17_5, seq_movie17_6, seq_movie17_7, 
	seq_movie18_0, seq_movie18_1, seq_movie18_2, seq_movie18_3, seq_movie18_4, seq_movie18_5, seq_movie18_6, seq_movie18_7, 
	seq_movie19_0, seq_movie19_1, seq_movie19_2, seq_movie19_3, seq_movie19_4, seq_movie19_5, seq_movie19_6, seq_movie19_7,

	seq_end
};

typedef unsigned char soundtype;
enum {
	snd_walk = 0, 
	snd_dig, 
	snd_win, 
	snd_lose,
	snd_die, 
	snd_push, 
	snd_pushbomb,
	snd_pushbag, 
	snd_pushbox, 
	snd_cushion, 
	snd_pcushion, 
	snd_elevator,
	snd_grabemld, 
	snd_grabsphr, 
	snd_grabruby, 
	snd_grabbomb, 
	snd_grabkey, 
	snd_setbomb, 
	snd_usedoor, 
	snd_stnroll, 
	snd_stnfall, 
	snd_stnhard, 
	snd_stnconv, 
	snd_emldroll, 
	snd_emldfall, 
	snd_emldconv, 
	snd_sphrroll, 
	snd_sphrfall, 
	snd_sphrbrk, 
	snd_sphrconv, 
	snd_rubyroll, 
	snd_rubyfall, 
	snd_rubyconv, 
	snd_bagroll, 
	snd_bagfall, 
	snd_bagopen, 
	snd_bagconv, 
	snd_bombroll, 
	snd_exitopen, 
	snd_exitclos, 
	snd_bombtick, 
	snd_blastvip, 
	snd_explode, 
	snd_swamp, 
	snd_drop, 
	snd_lorry, 
	snd_bug, 
	snd_yamyam, 
	snd_acid,  
	snd_clock,
	snd_laser,
	snd_wheel,
	snd_robot,

	snd_end
}; 

typedef unsigned char piecetype;
enum {
	outlineborder = 0,
	wall, stonewall, glasswall, invisiblewall, 
	wallemerald, air, earth, sand, sand_full,
	stone, bag, bomb, roundwall,
    door, door_opened, door_closing, door_closed,
    doorblue, doorred, doorgreen, dooryellow,
    emerald, sapphire, ruby, timebomb, timebomb10,
    keyblue, keyred, keygreen, keyyellow,
    box, cushion, elevator, pusherleft, pusherright,
    converter, dispenser, acid,
    swamp, drop,

    activebomb0, activebomb1, activebomb2, activebomb3,
    activebomb4, activebomb5,

    emerald_falling, stone_falling, bag_falling, bag_opening,
    sapphire_falling, sapphire_breaking, bomb_falling, 
	ruby_falling,
				  
	bomb_explode, bigbomb_explode,
    explode1, explode2, explode3, explode4,
                  
    lorryleft, lorryleft_fixed, 
    lorryright, lorryright_fixed,
    lorryup, lorryup_fixed, 
    lorrydown, lorrydown_fixed,
                  
	bugleft, bugleft_fixed, 
    bugright, bugright_fixed,
    bugup, bugup_fixed, 
    bugdown, bugdown_fixed, bug_explode,

    yamyamleft,yamyamright,
    yamyamup, yamyamdown, yamyam_explode,

	robot,wheel,

    man1, man2,

	movie0, movie1, movie2, movie3, movie4,
	movie5, movie6, movie7, movie8, movie9,
	movie10, movie11, movie12, movie13, movie14,
	movie15, movie16, movie17, movie18, movie19,

	piece_end
};

typedef unsigned char movetype;
enum {
	rest=0, 
	moveup, movedown, moveleft, moveright, 
	grabup, grabdown, grableft, grabright,
	bombup, bombdown, bombleft, bombright
};


#define PLAYBACKFLAG_SECRETDEMO		1
#define PLAYBACKFLAG_SUSPENDED		2
#define PLAYBACKFLAG_BACKGROUNDDEMO	4
#define PLAYBACKFLAG_REPLAY			8

class Walkthrough {
public:
	mlangstring name;
	int flags;
	unsigned long int randseed;
	int channelnum;

	vector<movetype> channels[maxinputchannels];
	int writecursor[maxinputchannels];

	Walkthrough() { flags=0; channelnum=0; randseed=0; };
	Walkthrough(int _channelnum);
	~Walkthrough();

	void clearReplayFlag() { flags &= ~PLAYBACKFLAG_REPLAY; }
	void reset();
	void cut(int len);
	void cutOneMove(int channel, int position);
	int numberOfMoves (int channel);
	int numberOfMoves ();
	int firstWriteCursor ();
	void addMove (int channel, movetype move);
	movetype getMove (int channel, int position);
	void setWriteCursor (int channel, int position);
	int getWriteCursor (int channel);

	void addFromFile (char c);
	char move2char (movetype move);
	void insertRests();

	bool operator < (const Walkthrough& other) const { return false; };
	bool operator == (const Walkthrough& other) const { return false; }
	operator= (const Walkthrough& other) {
		name = other.name;
		flags = other.flags;
		randseed = other.randseed;
		channelnum = other.channelnum;
		for (int i=0; i<channelnum; i++) channels[i]=other.channels[i];
	};
};

class YamYamInfo {
public:
	piecetype piece[3][3];

	YamYamInfo() { for(int i=0;i<9;i++) piece[i/3][i%3]=air; };
	~YamYamInfo() {};
	bool operator < (const YamYamInfo& other) const { return false; };
	bool operator == (const YamYamInfo& other) const { return false; }
};

class Level {
public:
	int emeraldsneeded;
	int emeraldsdestructable;
	int availabletime;
	int availablemoves;
	int swamprate;
	int pushprob;
	int dispenserspeed;
	int elevatorspeed;
	int wheelturntime;
	int	robotspeed;
	bool silentyamyam;
	bool silentlaser;

	charstring filename;
	mlangstring longname;
	int difficulty;
	int category;

	charstring artwork;
	charstring movieset;
	charstring soundwork;
	charstring songname;
	int   songplaystart;
	charstring nextlevel;

	mlangstringlist infolines;
	charstring authorname;
	charstring firstfinisher;

	int width;
	int height;
	piecetype piece[maxlevelwidth][maxlevelheight];
	vector<YamYamInfo> yamyaminfo;

	vector<Walkthrough> walkthroughs;

public:
	Level();
	~Level();

	bool load (charstring &filename, bool loadalldetails=true);
	bool save ();
	int differentPlayersInLevel ();
	int totalPlayersInLevel();
	int totalExitsInLevel();
	bool allDemosOK();
	void lockDemos();
	tiletype getTile (int x, int y);
	tiletype getYamYamTile(int b, int x, int y);

	int getDifficulty() { return difficulty; };
	int getCategory() { return category; };
	mlangstring* getLongname() { return &longname; };
	charstring getFilename() { return filename; };
	mlangstringlist* getInfoLines() { return &infolines; };
	charstring getAuthorName() { return authorname; };
	charstring getFirstFinisher() { return firstfinisher; };
	charstring getNextLevel() { return nextlevel; };
	void getWalkthroughName (int walkidx, charstring& name);
	void deleteWalkthrough (int walkthroughindex);
	int findSuspended();
	void deleteSuspended();
	int countEmeralds();
};

class Animation {
public:
	sequencetype seq;
	int x,y,dx,dy;

	Animation() {};
	~Animation() {};
	bool operator < (const Animation& other) const { return false; };
	bool operator == (const Animation& other) const { return false; }
};


class Checkpoint {
	class CheckpointPlayer {
	public:
		int  xpos,ypos;
		bool dead,done;
	    int  bombsready;
		bool haveredkey,havegreenkey;
		bool havebluekey,haveyellowkey;
	}; 
	vector<CheckpointPlayer> players;

	int positioncounter;
	int emeraldsneeded;
	int availabletime;
	unsigned long int randseed;
	int emeraldsdestroyed;
	int yamyamskilled;
	int wheelendtime,wheelx,wheely;
	int gamewintime;
	int movecounter;

	piecetype* piece;
	piecetype* explosionrest;

	public:
	Checkpoint(Game* g);
	~Checkpoint();
	void reactivate(Game* g);
};



class Player {
	friend class Checkpoint;

public:
	// constant while in same level
	int channel;
	int startxpos,startypos;
	piecetype piece;
	sequencetype seq_rest,
		seq_walkup,seq_walkdown,seq_walkleft,seq_walkright,
		seq_digup,seq_digdown,seq_digleft,seq_digright,
		seq_pushup,seq_pushdown,seq_pushleft,seq_pushright,
		seq_blink;

	// status for player
	int  xpos,ypos;
    bool dead,done;
    int  bombsready;
    bool haveredkey,havegreenkey;
	bool havebluekey,haveyellowkey;

	// temporary variables
	int prevxpos,prevypos;
	sequencetype previoussequence;
	int  runawayspeed;

	Player (int _channel, int startx, int starty);
	~Player ();
	bool hasKeyFor (piecetype p);
};


class Game {
	friend class Checkpoint;

public:
	// constant while in same level
	Level* level;
	Walkthrough thiswalk;

	vector<Player*> players;
	InputHandler* inputhandler[maxinputchannels];

	int microstepsperstep;
	bool needcheckpoints;
	vector<Checkpoint*> checkpoints;

protected:

	// variables for level state
	int microcounter;
	int positioncounter;
	int emeraldsneeded;
	int availabletime;
	unsigned long int randseed;
	int emeraldsdestroyed;
	int yamyamskilled;
	int wheelendtime,wheelx,wheely;
	int gamewintime;
	int movecounter;

	piecetype piece[maxlevelwidth][maxlevelheight];
	piecetype explosionrest[maxlevelwidth][maxlevelheight];

	// temporary variables
	enum locklevel { unlocked=0, normallocked=1, diglocked=2 };
	unsigned char islocked[maxlevelwidth][maxlevelheight];

public:
	enum {background=0, foreground=1, toplayer=2, layers=3};
	vector<Animation> animations[layers];
	enum {volume_silence=-100};
	enum {volume_full=0};
	int soundvolume[snd_end];
	bool soundsconsumed;

	Game (Level* l, int micros);
	Game (Level* l, int micros, int walkthroughindex);
	void init();
	void setInputHandler (int channel, InputHandler* handler);
	~Game();

	int getWidth() { return level->width; };
	int getHeight() { return level->height; };
	int getMicroCounter() { return microcounter; };
	int getMicroStepsPerStep() { return microstepsperstep; }; 

	int getAvailableTime() { return availabletime; };
	int getAvailableMoves() { return level->availablemoves; };
	int getPositionCounter() { return positioncounter; };
	int getMoveCounter() { return movecounter; };
	int getEmeraldsNeeded() { return emeraldsneeded; };
	int getTimeBombsLeft(int channel); 
	bool getHasKey(int channel, int kidx); 
	int getWalkthroughLength() { return thiswalk.numberOfMoves(); }
	bool hasReplayWalkthrough() { return (thiswalk.flags & PLAYBACKFLAG_REPLAY) != 0; }
	void setReplayFlag() { thiswalk.flags |= PLAYBACKFLAG_REPLAY; }
	void clearSuspendedFlag() { thiswalk.flags &= ~PLAYBACKFLAG_SUSPENDED; }

	tiletype getFixedTile (int x, int y);
	int getAnimationNumber (int layer);
	Animation* getAnimation (int layer, int index);
	void getFocusPoint (int tilesize, int channel, int &x, int &y);
	Animation* createAnimation (int layer);
	void addBGAnimation (sequencetype seq, int x, int y, int dx, int dy);
	void addFGAnimation (sequencetype seq, int x, int y, int dx, int dy);
	void addTOPAnimation (sequencetype seq, int x, int y, int dx, int dy);
	void forgetAnimations ();

	bool isSoundTime();
	int getSound(soundtype snd);
	void addSound(int x, int y, soundtype snd);
	void addSound(soundtype snd);
	void forgetSounds();

	void setNeedCheckPoints (bool need) { needcheckpoints=need;};
	void setCheckPointIfNeeded();
	void flushCheckPoints (int position);

	bool saveWalkthrough (int& walkidx, charstring& name);
	bool saveSuspended ();
	void resetAndClearWalkthrough();
	void reset ();
	void resetLogic ();
	void microStepRecord ();
	void microStepRecordSingle ();
	bool microStepForward ();
	bool microStepBackward ();
	bool microStepDelete ();
	bool fastForward();
	bool fastBackward();
	void nStepsFromBegin (int steps);
	void singleStepForward ();
	bool endOfWalkthrough();
	void cutWalkthrough();
	void setWriteCursor();
	bool deleteWriteBuffers();
	void insertRests();
	bool isDone();
	bool isDone(int channel);
	bool isLost();
	bool isDead();

	void lock (int x, int y);
	void diglock (int x, int y);
	void followlaser (int startx, int starty, int startdx, int startdy);
	void laserbeam (int startx, int starty, int centerx, int centery);
	void addexplosion (int x1,int y1,int x2,int y2, int centerx, int centery, 
				   bool yamyamtriggered);
	void totalexplode (int x1, int y1, int x2, int y2);
	void ignite (int x, int y);
	void startwheel(int piecex, int piecey);
	bool willfallin (int piecex, int piecey, int holex, int holey);
	void turnfalling (int x, int y);
	bool blastifnear (int x, int y, bool onlymovingtargets);
	bool blastYamYamIfNecessary(int x, int y, int dx, int dy);
	piecetype anyyamyam();
	void pickup (Player* p, int x, int y);
	void animatePlayer (Player* p, sequencetype seq, int dx, int dy, bool foreground=true);
	void moveplayer(Player* p);
	bool robottarget (int px, int py);
	void robotmovedir (int x, int y, int& dx, int &dy);
	void movepieces();

	int myrnd(int range);
	int israndom (int i);
	bool truerandom (int num);
};


class InputHandler {
public:
	virtual void recordMove (Walkthrough *walk, int channel, int needmoveforposition) = 0;
	virtual ~InputHandler() {};
};

class KeyboardInputHandler : public InputHandler {
	Keyboard* keyboard;
	bool bombs;

	int upkey,downkey,leftkey,rightkey,bombkey,grabkey;

public:
	virtual void recordMove (Walkthrough *walk, int channel, int needmoveforposition);
	movetype getState ();

	KeyboardInputHandler (int layout);
	virtual ~KeyboardInputHandler ();
};


#endif

