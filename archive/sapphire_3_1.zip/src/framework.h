#ifndef _FRAMEWORK_H
#define _FRAMEWORK_H

#include "types.h"

// entry function to be exported by game engine
bool GameMain(bool accepttrial, char* cmdline);


// functions to be used by the game engine
void doLog (int level, char* format, ...);
bool anyLevel0Error();
#define DOLOG doLog

// functions for the registration dialogs
bool isRegistered();
bool checkIfRegistered();
long int checkTrialPeriod();
bool registrationDialog();

// functions for game processing and self-runner objects
void gameTick();

class SelfRunner {
public:
	SelfRunner();
	virtual ~SelfRunner();

	virtual void run() = 0;
};

#endif
