#ifndef _LANG_H
#define _LANG_H

#include "types.h"

#define DEFAULTLANGUAGE "english"

int getavailablelanguages(vector<charstring>& languagelist);

void setcurrentlanguage(charstring& lang);
charstring* getcurrentlanguage();

void loadlanguage();
void unloadlanguage();
charstring* getstring(int id);
char* getstringdata(int id);



class mlangstring {
public:
	vector<charstring> languages;
	vector<charstring> contents;

	mlangstring();
	
	void setstring (charstring& language, charstring& str);

	charstring* getdefault ();
	charstring* get(charstring& language);
	charstring* get ();

	void copy (mlangstring& m);
};

class mlangstringlist {
public:
	vector<charstring> languages;
	vector<charstringvector> contents;

	mlangstringlist();
	void clear();

	void addstring (charstring& language, charstring& str);
	void setlist (charstring& language, vector<charstring>& strlist);

	vector<charstring>* getdefaultlist ();
	vector<charstring>* getlist(charstring& language);
	vector<charstring>* getlist();

	void copy (mlangstringlist& m);
};


#endif
