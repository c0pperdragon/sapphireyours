#include "framework.h"
#include "soundbox.h"
#include "dataread.h"


static LPDIRECTSOUND lpDS = NULL;
static LPDIRECTSOUNDBUFFER lpPrimary = NULL;
static HWND soundBoxMasterWindow = NULL;

static list<Sound*> allsounds;

#define BITSPERSAMPLE 8


bool initSoundBox (HWND hwnd)
{
	soundBoxMasterWindow = hwnd;

	// create a DirectSound object
	doLog (2,"creating direct sound object");
    if ( FAILED( DirectSoundCreate( NULL, &lpDS, NULL ) ) )
	{
       doLog (1,"Couldn't create DirectSound object." );
	   lpDS = NULL;
	   return true;
    } else {
	// set cooperative level
		if (FAILED( lpDS->SetCooperativeLevel (hwnd, DSSCL_PRIORITY))) {
			doLog (1,"Could not set cooperative level");
		} else {

		// set up the format of the primary sound buffer
			DSBUFFERDESC dsbdesc;
			WAVEFORMATEX wfm;

			memset (&dsbdesc, 0, sizeof(DSBUFFERDESC));
			dsbdesc.dwSize = sizeof(DSBUFFERDESC);
			dsbdesc.dwFlags = DSBCAPS_PRIMARYBUFFER;
			dsbdesc.dwBufferBytes = 0;
			dsbdesc.lpwfxFormat = NULL;

			memset (&wfm, 0, sizeof(WAVEFORMATEX) );
			wfm.wFormatTag = WAVE_FORMAT_PCM;
			wfm.nChannels = 2;
			wfm.nSamplesPerSec = 22050;
			wfm.wBitsPerSample = BITSPERSAMPLE;
			wfm.nBlockAlign = (wfm.wBitsPerSample / 8) * wfm.nChannels;
			wfm.nAvgBytesPerSec = wfm.nSamplesPerSec * wfm.nBlockAlign;

			HRESULT hr = lpDS->CreateSoundBuffer (&dsbdesc, &lpPrimary, NULL );
			if (SUCCEEDED (hr)) {
				// set primary buffer to the format, ignore any error...
				hr = lpPrimary->SetFormat (&wfm);
			}

		}
	}

	allsounds.clear();
	return true;
}

void closeSoundBox ()
{
	if (lpPrimary != NULL) {
		lpPrimary->Release();
		lpPrimary=NULL;
	}
	if ( lpDS != NULL ) {
		lpDS ->Release();
		lpDS = NULL;
	}
}

bool reloadSoundBox ()
{
	for (list<Sound*>::iterator it=allsounds.begin(); it!=allsounds.end(); it++) {
		if (! (*it)->reload() ) return false;
	}
	return true;
}


void activateSound()
{
	if (lpPrimary==NULL) return;
	for (int i=0; i<10000; i++) {
		if (SUCCEEDED(lpPrimary->Play(0,0,DSBPLAY_LOOPING))) return;
	}
}

void deactivateSound() 
{
	if (lpPrimary==NULL) return;
	lpPrimary->Stop();
}


Sound* loadSound (charstring& filename, double repeatspersecond)
{
	Sound* s = new Sound (filename, repeatspersecond);
	doLog (2, "loading sound: %s", filename.data());
	if (!s->reload()) {
		delete s;
		return NULL;
	}

	return s;
}

Sound::Sound(charstring& fname, double rps)
{
	filename = fname;
	repeatspersecond = rps;
	numsoundbuffers = 0;
	nextplayposition = 0;

	allsounds.push_back(this);
}

Sound::~Sound()
{
	allsounds.remove (this);

	for (int b=0; b<numsoundbuffers; b++) {
		lpDSB[b]->Release();
	}

}


void Sound::play(int volume)
{
	if (numsoundbuffers<=0) return;
	if (volume>0) volume=0;

	LPDIRECTSOUNDBUFFER b = lpDSB[nextplayposition];

    b->SetCurrentPosition( 0 );
	b->SetVolume (100*volume);

    HRESULT hr = b->Play( 0, 0, 0 );    // OK if redundant.
	if (FAILED (hr)) doLog (3,"error on playing sound");
  
	nextplayposition++;
	if (nextplayposition>=numsoundbuffers) nextplayposition=0;
}



// convert to 8 or 16-bit, stereo
void Sound::doconvert (BYTE* in_buffer, WORD in_channels, WORD in_bitspersample,
						DWORD in_totalsamples, BYTE* out_buffer)
{
	DWORD s;

	for (s=0; s<in_totalsamples; s++) {
		WORD c1=0;
		WORD c2=0;

		switch (in_channels) {
		case 1:
			switch (in_bitspersample) {
			case 8:	
				c1 = (((WORD) in_buffer[1*s + 0]) << 8) - (WORD) 0x8000;
				c2 = c1;
				break;
			case 16:	
				c1 = (WORD) (in_buffer[2*s + 0]) + ((WORD) (in_buffer[2*s + 1]) << 8);
				c2 = c1;
				break;
			}
		break;
		case 2:
			switch (in_bitspersample) {
			case 8:	
				c1 = (((WORD) in_buffer[2*s + 0]) << 8) - (WORD) 0x8000;
				c2 = (((WORD) in_buffer[2*s + 1]) << 8) - (WORD) 0x8000;
				break;
			case 16:	
				c1 = (WORD) (in_buffer[4*s + 0]) + ((WORD) (in_buffer[4*s + 1]) << 8);
				c2 = (WORD) (in_buffer[4*s + 2]) + ((WORD) (in_buffer[4*s + 3]) << 8);
				break;
			}
		break;
		}

#if BITSPERSAMPLE==16   // use 16-bit primary buffer
		out_buffer[4*s + 0] = (BYTE) (c1 & 0xff);
		out_buffer[4*s + 1] = (BYTE) ((c1 >> 8) & 0xff);
		out_buffer[4*s + 2] = (BYTE) (c2 & 0xff);
		out_buffer[4*s + 3] = (BYTE) ((c2 >> 8) & 0xff);
#else   // use 8-bit primary buffer
		out_buffer[2*s + 0] = (BYTE) ( (c1 + (WORD) 0x8000) >> 8 );
		out_buffer[2*s + 1] = (BYTE) ( (c2 + (WORD) 0x8000) >> 8 );
#endif
	} // end for
}



bool Sound::reload()
{
	WAVEFORMATEX         wfx;
    DSBUFFERDESC         dsbdesc;
	LPDIRECTSOUNDBUFFER  lpdsbStatic = NULL;
    DWORD  dwBytes1;

	WORD  in_channels = 0;
	WORD  in_bitspersample = 0;
	DWORD in_samplespersecond = 0;
	BYTE* in_buffer = NULL;
	int   in_buffersize = 0;

	WORD  out_channels;
	WORD  out_bitspersample;
	DWORD out_samplespersecond;
	WORD  out_samplesize;
	DWORD out_totalsamples;
	BYTE* out_buffer; 

	DataReader* f;
	

	// if we have not opened a DirectSound, we can not load any sound data
	if (lpDS==NULL) return false;

	// clear previously allocated sound data
	for (int b=0; b<numsoundbuffers; b++) {
		lpDSB[b]->Release();
	}
	numsoundbuffers = 0;
	nextplayposition = 0;

	// open file to load
	f = openDataReader (filename);
	if (!f) {
		doLog (2,"can not open file: %s",filename.data());
		return false;
	}
	if (f->readInt32() != 0x46464952) {
		doLog (1,"file not a RIFF-file: %s", filename.data());
		delete f;
		return false;
	}
	f->skipBytes(4);
	if (f->readInt32() != 0x45564157) {
		doLog (1,"RIFF-file not a WAVE format: %s", filename.data());
		delete f;
		return false;
	}

	// scan all contained chunks
	for (;;) {
		unsigned long chunkid = f->readInt32();
		unsigned long chunksize = f->readInt32();

		if (chunkid == 0) break;  // end of file reached
		if (chunksize > 10000000) break; // chunk size is only gibberish

		switch (chunkid) {
		case 0x20746d66:    // "fmt "
			if (f->readInt16() != 0x0001 || chunksize<16) {
				doLog (1, "unknown format in WAVE file: %s", filename.data());
				delete f;
				delete [] in_buffer;
				return false;
			}
			in_channels = f->readInt16();
			in_samplespersecond = f->readInt32();
			f->readInt32();
			f->readInt16();
			in_bitspersample = f->readInt16();

			if (chunksize>16) f->skipBytes(chunksize-16);
			break;

		case 0x61746164:    // "data"
			if (in_buffer==NULL) {
				in_buffersize = chunksize;
				in_buffer = new BYTE[in_buffersize];
				f->readBytes(in_buffer,in_buffersize);
				break;
			}

		default:
			f->skipBytes(chunksize);
		}

//		if ((chunksize%2) != 0) f->skipBytes(1); // skip padding at end of chunk
	}

	// delete file after we have read everything
	delete f;

	// check, if we could gather all necessary information
	if (in_channels<1 || in_buffer==NULL) {
		doLog (1, "WAVE-file misses necessary information: %s",filename.data());
		delete[] in_buffer;
		return false;
	}
	if (in_channels<1 || in_channels>2 || (in_bitspersample!=8 && in_bitspersample!=16) ) {
		doLog (1, "WAVE-file contains data of unknown format: %s",filename.data());
		delete[] in_buffer;
		return false;
	}

	// Do a few recomputations to get the correct format for the DirectSound buffer
	out_channels = 2;
	out_bitspersample = BITSPERSAMPLE;
	out_samplespersecond = in_samplespersecond;
	out_samplesize = out_channels * (out_bitspersample / 8);
	out_totalsamples = in_buffersize / ((in_channels*in_bitspersample)/8);
	
	// Create the DirectSound buffer.

	memset( &dsbdesc, 0, sizeof( DSBUFFERDESC ) ); 
	dsbdesc.dwSize = sizeof( DSBUFFERDESC ); 
	dsbdesc.dwFlags = DSBCAPS_STATIC | DSBCAPS_CTRLVOLUME;
	dsbdesc.dwBufferBytes = out_samplesize * out_totalsamples;
	dsbdesc.lpwfxFormat = &wfx; 

	wfx.wFormatTag = WAVE_FORMAT_PCM; 
    wfx.nChannels = out_channels;  
    wfx.nSamplesPerSec = out_samplespersecond; 
    wfx.nAvgBytesPerSec = out_samplespersecond * out_samplesize;
    wfx.nBlockAlign = out_samplesize; 
    wfx.wBitsPerSample = out_bitspersample; 
    wfx.cbSize = 0; 

    if ( FAILED( lpDS->CreateSoundBuffer( &dsbdesc, &lpdsbStatic, NULL ) ) )
    {
		doLog (1,"failed to create sound buffer");
		delete[] in_buffer;
        return false; 
    }

	// do the conversion from internal buffer to direct sound buffer

    if ( FAILED( lpdsbStatic->Lock(
            0,              // Offset of lock start.
            out_samplesize * out_totalsamples, // Size of lock
            (void**) &out_buffer,    // Address of lock start.
            &dwBytes1,      // Number of bytes locked.
            NULL,           // Address of wraparound start.
            NULL,           // Number of wraparound bytes.
            0 ) ) )// DSBLOCK_FROMWRITECURSOR ) ) )  // Flag.
    {
        // Error handling.
		doLog (1,"could not lock buffer");
		lpdsbStatic->Release();
		delete[] in_buffer;
        return false;
    }

	if (dwBytes1 != out_samplesize * out_totalsamples ) {
		doLog (1,"locked area: %d bytes = %d samples", 
			dwBytes1, dwBytes1 / out_samplesize);
		lpdsbStatic->Release();
		delete[] in_buffer;
        return false;
	}

	// convert input format to internal sound buffer format
	doconvert (in_buffer, in_channels, in_bitspersample, out_totalsamples,
		       out_buffer);

    lpdsbStatic->Unlock(out_buffer, dwBytes1, NULL, 0 );

	// release internal buffer
	delete[] in_buffer;


	// now set up the list of sound objects
	lpDSB[0] = lpdsbStatic;  
	numsoundbuffers=1;

	double samplelength = ((double) out_totalsamples) / ((double) out_samplespersecond);
	int necessarysamples = (int) (samplelength * repeatspersecond) + 1;
	while (numsoundbuffers<necessarysamples && numsoundbuffers<maxsoundbuffers) {
		LPDIRECTSOUNDBUFFER newsound;
		if ( FAILED(lpDS -> DuplicateSoundBuffer (lpdsbStatic, &newsound)) ) {
			break;
		}
		lpDSB[numsoundbuffers++] = newsound;
	}
    
	return true;
}

