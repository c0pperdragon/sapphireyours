#ifndef _MUSICBOX_H 
#define _MUSICBOX_H

#include "types.h"
#include "windows.h"

bool initMusicBox (HWND hwnd);
void closeMusicBox ();

bool didMIDIrestart();
void playMIDI (charstring& file, int playstart);
void restartMIDI();
void stopMIDI();


#endif
