#ifndef _DISPLAY_H
#define _DISPLAY_H

#include "types.h"
#include "inputbox.h"
#include "viewbox.h"
#include "logic.h"


enum imageid { 
img_bag=0,
img_bagexpl,
img_bomb,
img_bomb10,
img_box,
img_bugdwn,
img_buglft,
img_bugrgt,
img_bugtdr,
img_bugtld,
img_bugtru,
img_bugtul,
img_bugup,
img_convert,
img_cushion,
img_dispen1,
img_dispen2,
img_doorblue,
img_doorgree,
img_dooropen,
img_doorred,
img_doorylow,
img_drop,
img_dropdwn,
img_drophit,
img_droplft,
img_droprgt,
img_dropup,
img_earth,
img_earthdwn,
img_earthlft,
img_earthrgt,
img_earthup,
img_sand,
img_elevator,
img_pushlft,
img_pushrgt,
img_emerald,
img_emeraway,
img_emglitt,
img_explode,
img_glaswall,
img_invisi,
img_keyblue,
img_keyellow,
img_keygreen,
img_keyred,
img_laserbl,
img_laserbr,
img_laserh,
img_lasertl,
img_lasertr,
img_laserv,
img_lorrydwn,
img_lorrylft,
img_lorryrgt,
img_lorrytdl,
img_lorrytlu,
img_lorrytrd,
img_lorrytur,
img_lorryup,
img_rndwall,
img_ruby,
img_rubyaway,
img_saphaway,
img_saphbrk,
img_sapphire,
img_stone,
img_stonewll,
img_swamp,
img_timebomb,
img_tickbomb,
img_wall,
img_wallemer,
img_yamyam,
img_yamyamdn,
img_yamyamrt,
img_yamyamlt,
img_yamyamup,
img_robot,
img_wheel,
img_acid,
img_acidalne,
img_acidleft,
img_acidrgt,
img_1digdwn,
img_1digrgt,
img_1diglft,
img_1digup,
img_1man,
img_1pushrgt,
img_1pushlft,
img_1walkdwn,
img_1walkrgt,
img_1walklft,
img_1walkup,
img_2digdwn,
img_2digrgt,
img_2diglft,
img_2digup,
img_2man,
img_2pushrgt,
img_2pushlft,
img_2walkdwn,
img_2walkrgt,
img_2walklft,
img_2walkup,

img_movie0,
img_movie1,
img_movie2,
img_movie3,
img_movie4,
img_movie5,
img_movie6,
img_movie7,
img_movie8,
img_movie9,
img_movie10,
img_movie11,
img_movie12,
img_movie13,
img_movie14,
img_movie15,
img_movie16,
img_movie17,
img_movie18,
img_movie19,

img_end
};

void releaseImageCache();

class Artwork {
	friend class GameFrame;
	friend class LevelFrame;

	int tilesize;
	int backgroundcolor;
	Image* image[img_end];

public:
	Artwork ();
	virtual ~Artwork ();

	void load (charstring &name, charstring& movieset, int shrinkfactor);
	void unload();
	bool loadOrReuseImage(charstring& fname, int shrinkfactor,  int index);

	Image* getImageForSequence (sequencetype seq, int step, int totalsteps, int &x1);
	Image* getImageForTile (tiletype tile, int &x1);
	Image* getImage2ForTile (tiletype tile, int &x1);

	int getBackgroundColor () { return backgroundcolor; };

private:
	Image* Artwork::sequenceRest (Image* img, int &x1);
	Image* Artwork::sequenceForward (Image* img, int step, int totalsteps, int &x1);
	Image* Artwork::sequenceBackward (Image* img, int step, int totalsteps, int &x1);
	Image* Artwork::nthMoviePicture (Image* img, int step, int totalsteps, int &x1);
	Image* Artwork::nthMovieSequenceOfm (Image* img, int n, int m, int step, int totalsteps, int& x1);
	Image* Artwork::nthSequenceOf5 (Image* img, int n, int step, int totalsteps, int& x1);
	Image* Artwork::nthOf5 (Image* img, int n, int& x1);
	Image* Artwork::nthPicture (Image* img, int n, int& x1);
	Image* Artwork::lastPicture (Image* img, int& x1);
};

typedef tiletype tileraster[maxlevelwidth][maxlevelheight];

class GameFrame : public Frame {
	Game* game;
	int mainplayer;
	Artwork* artwork;
	int scrollx;
	int scrolly;

	int tilesize;
	tileraster raster[2];
	int rasterscrollx[2];
	int rasterscrolly[2];

	Mouse mouse;

	void computeScrollRegion();
	void setDirtyRect (int r, int x1, int y1, int x2, int y2);
	void setCleanRect (int r, int x1, int y1, int x2, int y2);

	void refreshTiles (int r, int x1, int y1, int x2, int y2, 
							  bool transparent, bool onlyincremental,
							  list<Frame*>::iterator &it);
	void refreshSequences (int r, int x1, int y1, int x2, int y2,
								  list<Frame*>::iterator &it);
	virtual void drawChanges (int currentpage, list<Frame*>::iterator& it);
	virtual void updateInvalid (int currentpage, list<Frame*>::iterator& it, RectangleList& invalid);

public:
	GameFrame (int l, int t, int w, int h, Game* g, int main, Artwork* a, 
		double toright=0.5, double tobottom=0.5);
	virtual ~GameFrame();

	int getMainPlayer() { return mainplayer; }
	void setMainPlayer(int m) { mainplayer=m; };
};


class StatusFrame : public Frame {
protected:
	enum { statusheight = 40 };

	Game* game;
	Image* panel;

	void writeNumber (int num, int len, int dx, int dy, int x1,int y1, int x2, int y2);
	virtual void update (int currentpage, int x1, int y1, int x2, int y2) = 0;

public:
	StatusFrame (int l, int t, int w, int h, Game* g, Image* p);
	virtual ~StatusFrame() {};
};

class StatusFrame1 : public StatusFrame {
protected:
	enum { statuswidth = 4*20+4*40+(3+3+4+4)*16 };

	virtual void update (int currentpage, int x1, int y1, int x2, int y2);
public:
	StatusFrame1 (int x, int y, Game* g, Image* p);
	virtual ~StatusFrame1() {};
};

class StatusFrame2 : public StatusFrame {
protected:
	enum { statuswidth = 4*20+1*40+(3)*16 };

	virtual void update (int currentpage, int x1, int y1, int x2, int y2);
public:
	StatusFrame2 (int x, int y, Game* g, Image* p);
	virtual ~StatusFrame2() {};
};



class VCRFrame : public Frame {
protected:
	Game* game;
	Image* vcr;
	int* recordermode;
	int moves;

	virtual void update (int currentpage, int x1, int y1, int x2, int y2);

public:
	VCRFrame (int x, int y, Game* g, int* recmode, Image* v, int mv);
	virtual ~VCRFrame() {};
};



class ReplayFrame : public Frame {
protected:
	Game* game;
	Image* vcr;
	int speed;
	int blink;

	virtual void update (int currentpage, int x1, int y1, int x2, int y2);

public:
	ReplayFrame (int x, int y, Game* g, Image* v, int blinkspeed);
	virtual ~ReplayFrame() {};

	void heartbeat();
};



#endif
