
#include "framework.h"
#include "viewbox.h"
#include "viewextension.h"
#include "inputbox.h"
#include "toolbox.h"
#include "musicbox.h"
#include "soundbox.h"

#include "logic.h"
#include "display.h"
#include "sound.h"
#include "editor.h"
#include "gamemain.h"

#define BESTTURNSPERSECOND    (3.7)
#define AFTERFINISHED 2.0
#define SLOWMOTIONFACTOR 5
#define BIGTUTORLEVELINTERVAL 4
#define MAXIMUMTUTORRUN 200

#define BESTTEXTSCROLLSPEED 30
#define SCROLLTEXTENDDELAY 600

#define MAXNUMPLAYER 2

#define NECESSARYFORRANKING  (0.9)


static Image* theMenuBackground;
static Image* theTitle = NULL;
static Image* thePanel = NULL;
static Image* theVCR = NULL;

#define MAXFONTS 3
static Image* allFonts[MAXFONTS] = {NULL,NULL,NULL};
static Image* theFont = NULL;
static int letterwidth,letterheight;

#define LETTER_LEFTARROW  '\020'
#define LETTER_RIGHTARROW '\021'
#define LETTER_CHECKMARK  '\022'
#define LETTER_DEMOMARK	  '\023'
#define LETTER_2PLAYERS   '\024'
#define LETTER_IMPOSSIBLE '\025'
#define LETTER_UNKNOWN    '\026'
#define LETTER_SUSPENDED  '\027'
#define LETTER_DOTS       '\030'

int color_neutral;
int color_menu;
int color_playernum;
int color_black;
int color_white;
int color_grey;
int color_darkgrey;
int color_green;
int color_red;
int color_diff[DIFFICULTIES];


vector<LevelHeader*> levellist;

int maxxresolution;
int maxyresolution;
int defaultshrinkfactor;
int defaultfont=1;
int tutorshowmode=0;
charstring usedtitlemusic;
charstring usedbackgroundmusic;
charstring defaultbackgroundmusic[MAXCATEGORIES];
charstring trailermusic;
charstring defaultartwork;
charstring defaultsoundwork;

static int p1control;
static int p2control;

static list<charstring> additionalknown;
static list<charstring> additionalfinished;

#define CONTROLLER_KEY1      0
#define CONTROLLER_KEY2		 1
#define CONTROLLER_JOYSTICK1 2


#define ACTION_QUIT   (-3)
#define ACTION_PLAY	  (-4)
#define ACTION_PLAYDEMO (-5)
#define ACTION_NEWDEMO (-12)
#define ACTION_REDRAW    (-6)
#define ACTION_SETTINGS (-19)
#define ACTION_CHECKDEMOS (-7)
#define ACTION_CONTINUE (-8)
#define ACTION_RETURN  (-9)
#define ACTION_RESTART (-10)
#define ACTION_NEXTLEVEL (-11)
#define ACTION_SAVEDEMO (-13)
#define ACTION_SAVENEWDEMO (-14)
#define ACTION_DELETEDEMO (-18)
#define ACTION_SUSPEND  (-15)
#define ACTION_CONTINUESUSPENDED (-16)
#define ACTION_DELETESUSPENDED   (-17)
#define ACTION_TITLEMUSIC (-20)
#define ACTION_BACKGROUNDMUSIC (-21)
#define ACTION_NONE (-22)
#define ACTION_ABOUT (-23)
#define ACTION_NUMPLAYER (-24)
#define ACTION_RANKINGINFO (-25)
#define ACTION_RESTARTPROGRAM (-26)
#define ACTION_SCREENRES (-27)
#define ACTION_CONTROLS (-28)
#define ACTION_RELOADLANGUAGE (-29)
#define ACTION_EDITOR (-30)
#define ACTION_SCREENCENTER (-31)
#define ACTION_TOGGLESPLIT  (-32)
#define ACTION_VCR          (-33)
#define ACTION_CONTROLLER1  (-34)
#define ACTION_CONTROLLER2  (-35)


bool GameMain(bool accepttrial, char* cmdline)
{
	bool registrationok = true;
	bool didrestart=false;
	bool restart;
	charstring startuplevel;
	
	// the basic startup (only done once)
	initLogic();
	
	loadFundamentalConfigurationParameter();
	
	// scan command line
	DOLOG (1, "Program parameter: [%s]", cmdline);
	scancmdline (cmdline, "-x", maxxresolution);
	scancmdline (cmdline, "-y", maxyresolution);
	
	if (cmdline[0]!='"') startuplevel=cmdline;
	else {
		startuplevel=cmdline+1;
		if (startuplevel.length()>0 && startuplevel.at(startuplevel.length()-1)=='"') 
			startuplevel.resize(startuplevel.length()-1);
	}
	
	
	// the main loop that restarts for various changes in artwork and such
	do {
		
		PerformanceMonitor* pm = NULL;
		LevelHeader* selectedlevel=NULL;
		Image* splashImage = NULL;
		int walkthrough;
		int action;
		int numplayer=1;
		
		
		restart = false;
		if (! openScreen (maxxresolution,maxyresolution, 640,480) ) goto cleanup;

		// check for registration information
		if (!checkIfRegistered()) {
			doLog (1, "No registered version");
			if (!accepttrial || checkTrialPeriod()<=0) {
				registrationok = false;
				goto cleanup;
			}
		}

		if (! loadPalette (charstring("art\\palette.bmp")) ) goto cleanup;
		
		color_white     = findColor(255,255,255);
		color_grey		= findColor(150,150,150);
		color_darkgrey	= findColor(100,100,100);
		color_black		= findColor(0,0,0);
		color_neutral	= color_grey;	
		color_menu		= findColor(255,255,255);
		color_playernum = findColor(255,200,100);
		color_green		= findColor(50,250,0);
		color_red		= findColor(255,0,0);
		color_diff[0]	= findColor(87,179,255);
		color_diff[1]	= findColor(2,120,253);
		color_diff[2]	= findColor(0,20,255);
		color_diff[3]	= findColor(1,136,1);
		color_diff[4]	= findColor(50,250,0);
		color_diff[5]	= findColor(250,250,0);
		color_diff[6]	= findColor(254,139,0);
		color_diff[7]	= findColor(255,50,0);
		color_diff[8]	= findColor(253,0,0);
		color_diff[9]	= findColor(195,0,0);
		color_diff[10]	= findColor(155,155,155);
		
		// loading fonts
		switch (defaultfont) {
		case 1:
			if (allFonts[1] = loadImage (charstring("art\\fontbig.bmp"),1,true) ) {
				setActiveFont(1);
				break;
			}
		case 2:
			if (allFonts[2] = loadImage (charstring("art\\fontsmll.bmp"),1,true) ) {
				setActiveFont(2);
				break;
			}
		default: 
			if (allFonts[0] = loadImage (charstring("art\\font.bmp"),1,true) ) {
				setActiveFont(0);
				break;
			}
			doLog (0, "Could not open file to read font image");
			goto cleanup;  // if no font could be loaded
		}
		
		DOLOG (2, "loading language strings");
		loadlanguage();
		
		// open splash screen
		splashImage = loadArtworkImage ( "splash" );
		if (splashImage) {
			ColorFrame bw (0,0, getScreenWidth(), getScreenHeight(), color_black);
			bw.moveToBack();
			
			ImageFrame splash ( 
				getScreenWidth()/2 - splashImage->getWidth()/2,
				getScreenHeight()/2 - splashImage->getHeight()/2,
				false, splashImage);
			
			charstring* txt = getstring(didrestart ? 191 : 190);
			TextFrame txtfrm( 
				getScreenWidth()/2  + (txt->length()*letterwidth)/7, 
				splash.getBottom()+30, *txt, color_white);
			
			for (int i=0; i<2; i++) {
				gameTick();
			}
			delete splashImage;
		}
		
		// load graphics info. most important images first
		if (1) {
			Artwork a;
			a.load (defaultartwork, charstring(""), defaultshrinkfactor); // fill the artwork cache

			SoundSet s;
			s.load (defaultsoundwork); // fill the soundset cache
		}
		
		if (! (theMenuBackground = loadArtworkImage("backgrnd") )) {
			doLog (0, "Could not load menu background");
			goto cleanup;
		}
		if (! (thePanel = loadArtworkImage("panel") )) {
			doLog (0, "Could not load status panel image");
			goto cleanup;
		}
		if (! (theVCR = loadImage (charstring("art\\vcr.bmp")) )) {
			doLog (0, "Could not read VCR images");
			goto cleanup;
		}
		if (! (theTitle = loadArtworkImage ( "title") )) {
			doLog (0, "Could not read game title image");
			goto cleanup;
		}

		doLog (1, "basic load complete");
		if (startuplevel.size()>0) {
			if (!didrestart) selectedlevel = addLevel( startuplevel.data(), NULL );
			else                             addLevel (startuplevel.data(), NULL);
		} 
		loadLevelDirectory ("levels", selectedlevel);
		DOLOG (1, "level list load complete");
		
		loadLevelKnownInfo();
		DOLOG (1, "configuration parameter loaded");
		
		int dummy;
		if (scancmdline (cmdline, "-performance", dummy)) {
			pm = new PerformanceMonitor (getScreenWidth(),0 );
		}
		
		DOLOG (1,"sorting levels");
		sortLevels();
		
		

		clearCommandEvents();
		if (selectedlevel) {
			numplayer = selectedlevel->playersinlevel;
			addCommandEvent(COMMAND_YES, 0);
		}
		
		if (!selectedlevel) {
			int rank = computeRanking (numplayer);
			if(rank>2) {
				for (int i=0; i<levellist.size(); i++) {
					LevelHeader* lh = levellist[i];
					if (lh->difficulty==rank && lh->playersinlevel==numplayer) {
						selectedlevel=lh;
						break;
					}
				}
			}
		}
		if (!selectedlevel) {
			selectedlevel = findLevelHeader ("Welcome to the Game");
		}


		// main loop of menu selection
		do {
			checkTrialPeriod();
			
			starttitlemusic();
			
			action = mainMenu(selectedlevel, walkthrough, numplayer);
			
			switch (action) {
			case ACTION_CONTINUESUSPENDED:
				playGame (selectedlevel, true);
				break;
			case ACTION_PLAY: 
				playGame (selectedlevel, false);
				break;
				
			case ACTION_NUMPLAYER:
				numplayer++;
				if (numplayer>MAXNUMPLAYER) numplayer=1;
				selectedlevel=NULL;
				break;
				
			case ACTION_PLAYDEMO:
				playDemo (selectedlevel, walkthrough);
				break;
			case ACTION_NEWDEMO:
				playDemo (selectedlevel, -1);
				break;
				
			case ACTION_EDITOR:
				selectedlevel = startEditor(selectedlevel);
				sortLevels();
				break;

			case ACTION_RESTARTPROGRAM:
				restart = true;
				goto cleanup;
				
			case ACTION_RELOADLANGUAGE:
				loadlanguage();
				sortLevels();
				break;
			}
		} while (action!=ACTION_QUIT);

cleanup:
		stopMIDI();
		// release all possible resource _before_ drawing the scrolltext trailer
		releaseImageCache();
		releaseSoundCache();
		delete theTitle; theTitle=NULL;
		delete thePanel; thePanel=NULL;
		delete theVCR; theVCR=NULL;
		delete theMenuBackground; theMenuBackground=NULL;
		DOLOG (2, "delete level list");
		deleteLevelList();
		DOLOG (2, "unload language");
		unloadlanguage();
		
		if (!restart && registrationok &&!anyLevel0Error()) {
			// prepare scolltext trailer
			delete allFonts[2]; allFonts[2]=NULL; 
			if (!allFonts[0]) allFonts[0] = loadImage(charstring("art\\font.bmp"),1,true);
			if (!allFonts[1]) allFonts[1] = loadImage(charstring("art\\fontbig.bmp"),1,true);
			setActiveFont(0);
			showTrailer();
		}
		
		// delete everything else now
		DOLOG (2, "close performance monitor");
		delete pm; pm=NULL;
		DOLOG (2, "close fonts");
		for (int fidx=0; fidx<MAXFONTS; fidx++) {
			delete allFonts[fidx]; allFonts[fidx]=NULL; 
		}
		
		// re-activeate blank screen background 
		if (screenIsOpen()) {
			fillScreen(0);
			fillScreen(0);
		}
		DOLOG (2, "close screen");
		closeScreen();
		
		didrestart = restart;
	} while (restart);

	return registrationok;
}



int mainMenu(LevelHeaderPtr& selectedlevel, int& walkthroughindex, int numplayer)
{
	BackgroundContainer bc (true);

	int mwidth = (MainMenuFrame::catwidth+MainMenuFrame::columnwidth*20)*letterwidth;
	while (mwidth>getScreenWidth()-10) mwidth-=MainMenuFrame::columnwidth*letterwidth;
	int mleft = (getScreenWidth()-mwidth)/2;
	int mheight = (MainMenuFrame::levelspacing+letterheight)*100;
	while (mheight+theTitle->getHeight()+50 > getScreenHeight()) 
		mheight-=letterheight+MainMenuFrame::levelspacing;

	MainMenuFrame mainframe (mleft,theTitle->getHeight(), 
		mleft+mwidth, theTitle->getHeight()+mheight);

	ImageFrame title ( 
		getScreenWidth()/2 - theTitle->getWidth()/2,  0,
		true, theTitle);

	TutorManager tm (numplayer,	&mainframe);
	tm.run();


	int rank=computeRanking(numplayer);
	int firstidx=2;
	char cname[50];
	sprintf (cname, "   %s", getstringdata(1) );
	mainframe.addCategory (0, cname,  color_menu, ACTION_NONE);
	sprintf (cname, " %s", (numplayer==1) ? getstringdata(2) : getstringdata(3));
	mainframe.addCategory (1, cname, color_playernum, ACTION_NUMPLAYER);
	sprintf (cname, "\022  %s", getstringdata(10) );
	mainframe.addCategory (firstidx+0, cname,   color_diff[0], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(11) );
	mainframe.addCategory (firstidx+1, cname,     color_diff[1], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(12) );
	mainframe.addCategory (firstidx+2, cname,       color_diff[2], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(13) );
	mainframe.addCategory (firstidx+3, cname,   color_diff[3], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(14) );
	mainframe.addCategory (firstidx+4, cname,     color_diff[4], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(15) );
	mainframe.addCategory (firstidx+5, cname,     color_diff[5], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(16) );
	mainframe.addCategory (firstidx+6, cname,      color_diff[6], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(17) );
	mainframe.addCategory (firstidx+7, cname,  color_diff[7], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(18) );
	mainframe.addCategory (firstidx+8, cname,       color_diff[8], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(19) );
	mainframe.addCategory (firstidx+9, cname,    color_diff[9], ACTION_NONE);
	sprintf (cname, "\022  %s", getstringdata(20) );
	mainframe.addCategory (firstidx+10,cname,   color_neutral, ACTION_NONE);

	mainframe.addMenuItem (0,ACTION_SETTINGS, getstringdata(30), color_neutral);
	mainframe.addMenuItem (0,ACTION_CONTROLS, getstringdata(34), color_neutral);
	mainframe.addMenuItem (0,ACTION_EDITOR,   getstringdata(35), color_neutral);
	mainframe.addMenuItem (0,ACTION_CHECKDEMOS, getstringdata(32), color_neutral);
	mainframe.addMenuItem (0,ACTION_ABOUT, getstringdata(31), color_neutral);
	mainframe.addMenuItem (0,ACTION_QUIT, getstringdata(33), color_neutral);

	sprintf (cname, "   (%s)", getstringdata(40+(numplayer-1)*10+rank-1) );
	mainframe.addMenuItem (1,ACTION_RANKINGINFO, cname, color_diff[rank]);
	

	walkthroughindex = -1;

	for (int levelid=0; levelid<levellist.size(); levelid++) {
		LevelHeader* h = levellist[levelid];

		if ( (numplayer!=2) != (h->playersinlevel!=2) ) continue;


		int d = h->difficulty;
		if (d<0 || d>=DIFFICULTIES) d=DIFFICULTIES-1;

		charstring* catsym = mainframe.getCategoryName(firstidx+d);
		charstring symbols = "    ";

		if (h->category>0) symbols[2] = 24+h->category;

		if (h->isfinished) {
			symbols[0] = LETTER_CHECKMARK;
		} else {
			if ((*catsym)[0]==LETTER_CHECKMARK) (*catsym)[0]=' ';
		}
		if (!h->isknown) {
			symbols[0] = LETTER_UNKNOWN;
			(*catsym)[0] = LETTER_UNKNOWN;
		}

		if (h->hasAllowedDemos()) {
			symbols[1] = LETTER_DEMOMARK;
			if ((*catsym)[1]==' ') (*catsym)[1]=LETTER_DEMOMARK;
		}
		if (h->hasSuspendGame()) {
			symbols[1] = LETTER_SUSPENDED;
			if ((*catsym)[1]==' ' || (*catsym)[1]==LETTER_DEMOMARK) (*catsym)[1]=LETTER_SUSPENDED;
		}
		if (h->hasImpossibleDemo()) {
			symbols[1] = LETTER_IMPOSSIBLE;
			(*catsym)[1] = LETTER_IMPOSSIBLE;
		}

		mainframe.addMenuItem (firstidx+ d, levelid, symbols+*(h->longname.get()), h->getColor() );
	}

	mainframe.selectCategory(1);
	for (int hidx=0; hidx<levellist.size(); hidx++) {
		if (selectedlevel==levellist[hidx]) mainframe.selectItem(hidx);
	}

	for (int s=0; s<2; s++) {
		gameTick();
	}
	resetFrequencyDivide();

	do {
		for (;;) {	
			gameTick();

			int selectedid;
			if (mainframe.processSelection(selectedid)) {
				switch (selectedid) {
				case ACTION_CHECKDEMOS:
					{
						int result;
						{
							DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
								*getstring(70), color_neutral, color_black);
							d.addTextLine (*getstring(71), color_neutral);
							d.addBlankLine ();
							d.addActionLine (*getstring(72), color_neutral, ACTION_OK);
							d.addActionLine (*getstring(60), color_neutral, ACTION_CANCEL);
							result = d.doModal();
						}
						if (result == ACTION_OK) {
							checkDemos();
							return ACTION_REDRAW;
						}
					}
					break;

				case ACTION_RANKINGINFO:
					{
						int col = color_diff[rank];
						DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
							*getstring(75), color_neutral, color_black);
						d.addTextLine(*getstring(76), color_neutral);
						for (int ra=1; ra<=9; ra++) {
							d.addTextLine (charstring("    ") + 
								*getstring(40+(numplayer-1)*10+ra-1), 
								(ra==rank) ? col : color_neutral);
						}
						d.addBlankLine ();
						d.addActionLine (*getstring(61), color_neutral, ACTION_CANCEL);
						d.doModal();
					}
					break;

				case ACTION_SETTINGS:
					{ int returnvalue;
					if (settings(&tm, returnvalue)) return returnvalue;
					}
					break;

				case ACTION_CONTROLS:
					{ int returnvalue;
					if (controlsettings(&tm, returnvalue)) return returnvalue;
					}
					break;

				case ACTION_EDITOR:
					selectedlevel = NULL;
					return ACTION_EDITOR;

				case ACTION_ABOUT:
					about();
					break;

				case ACTION_CANCEL:
				case ACTION_QUIT:  
					DOLOG (2, "quit selected");
					{
						DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
							*getstring(80), color_neutral, color_black);

						d.addTextLine (*getstring(81), color_neutral);
						d.addBlankLine ();
						d.addActionLine (*getstring(82), color_neutral, ACTION_QUIT);
						d.addActionLine (*getstring(83), color_neutral, ACTION_CANCEL);
						
						if (d.doModal () == ACTION_QUIT) return ACTION_QUIT;
					}
					break;

				case ACTION_NUMPLAYER:
					return ACTION_NUMPLAYER;

				default:
					DOLOG (2, "level selected");

					if (selectedid>=0 && selectedid<levellist.size()) {
						LevelHeader* h = levellist[selectedid];
						int col = h->getColor();
						DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
							charstring(""), col, color_black);

						d.addLevelInfo (h);

						d.addBlankLine();
						if (h->hasSuspendGame()) {
							d.addActionLine (*getstring (85), col, ACTION_CONTINUESUSPENDED);
						}
						d.addActionLine (*getstring(86), col, ACTION_PLAY);

						for (int j=0;j<h->walkthroughnames.size(); j++) {
							if (h->mayViewDemo(j)) {
								d.addActionLine (*getstring(87)+" "+*(h->walkthroughnames[j].get()), col, j);
							}
						}
						d.addBlankLine();
						d.addActionLine (*getstring(88), col, ACTION_NEWDEMO);
						d.addActionLine (*getstring(240), col,ACTION_EDITOR);

						int action = d.doModal();

						switch (action) {
						case ACTION_PLAY:
						case ACTION_NEWDEMO:
						case ACTION_CONTINUESUSPENDED:
						case ACTION_EDITOR:
							selectedlevel = h;
							return action;
						default: 
							if (action>=0) {
								selectedlevel = h;
								walkthroughindex = action;
								return ACTION_PLAYDEMO;
							}
							break;
						}
					}
					break;
				}
			}
		}
	} while (0);

	return ACTION_QUIT;
}


void starttitlemusic() {
	if (usedtitlemusic=="") {
		stopMIDI();
	} else {
		playMIDI (charstring("songs\\")+usedtitlemusic+".mid", 0);
	}
}

// ---------------------- SETTINGS MENU --------------------------------------

void selectmusic (char* prompt, charstring& music)
{
	vector<charstring> mlist;

	// read list of all music files
	findhandle h;
	char *n;
	n = findfirstfile (&h,"songs\\*");
	while (n!=NULL) {
//		charstring txt = charstring ("songs\\") + n;
//		if (n[0] != '.' && !isdirectory (txt.data())) {
			// cut away the trailing ".mid" of the filename
			charstring txt = n;
			if (txt.size()>4 && _stricmp (txt.data()+txt.size()-4, ".mid") == 0) {
				txt.resize(txt.size()-4);
				mlist.push_back(txt);
			}
//		}
		n = findfile (&h);
	}
	stopfindfile (&h);
	sortstringlist (mlist);

	// open dialog to ask user
	DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
						charstring(prompt), color_green, color_black);
	d.setMaxLines (20);

	for (int midx=0; midx<mlist.size(); midx++) {
		d.addActionLine (mlist[midx],color_green, midx);
	}
	d.addActionLine (*getstring (90), color_green, ACTION_NONE);
	d.addBlankLine();
	d.addActionLine (*getstring(60), color_green, ACTION_CANCEL);

	midx = d.doModal();
	if (midx>=0) {
		music = mlist[midx];
	} else if (midx==ACTION_NONE) music = "";
}		

void selectscreenresolution (int &x, int &y)
{
	enum {MAXMODES=100};
	twoint modes[MAXMODES];
	int nummodes = getPossibleScreenModes(modes,MAXMODES);

	// open dialog to ask user
	DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
						*getstring(111), color_green, color_black);

	for (int midx=0; midx<nummodes; midx++) {
		if (modes[midx][0]>=640 && modes[midx][1]>=480) {
			char line[100];
			sprintf (line, "%dx%d", modes[midx][0], modes[midx][1]);
			d.addActionLine (charstring(line), color_green, midx);
		}
	}
	d.addBlankLine();
	d.addActionLine (*getstring(60), color_green, ACTION_CANCEL);

	midx = d.doModal();
	if (midx>=0) {
		x = modes[midx][0];
		y = modes[midx][1];
	};
}		


bool settings(TutorManager* tm, int &returnvalue)
{
	returnvalue = 0;

	// read setting values from configuration options
	int newscreenx = maxxresolution;
	int newscreeny = maxyresolution;
	int imagesize = defaultshrinkfactor-1;  // normalize index to base 0
	int newdefaultfont = defaultfont;
	int newtutorshowmode = tutorshowmode;

	int refreshrate = getDefaultFrequencyDivide();
	if (refreshrate<0 || refreshrate>5) refreshrate=1;

	int artworkidx=0;
	vector<charstring> artworklist;

	int soundworkidx=0;
	vector<charstring> soundworklist;

	int languageidx=0;
	vector<charstring> languagelist;

	charstring newtitlemusic = usedtitlemusic;
	charstring newbackgroundmusic = usedbackgroundmusic;

	// determine available artworks
	readsubdirectorylist(artworklist, "art\\");
	for (int aidx=0; aidx<artworklist.size(); aidx++) {
		if (_stricmp (artworklist[aidx].data(), defaultartwork.data()) == 0) {
			artworkidx = aidx;
		}
	}

	// determine available soundworks
	readsubdirectorylist(soundworklist, "sound\\");
	soundworkidx = soundworklist.size();
	for (int sidx=0; sidx<soundworklist.size(); sidx++) {
		if (_stricmp (soundworklist[sidx].data(), defaultsoundwork.data()) == 0) {
			soundworkidx = sidx;
		}
	}
	soundworklist.push_back(getstringdata(90));

	// determine available languages
	languageidx = getavailablelanguages(languagelist);

	// do user input
	for (;;) {
		// create the dialog frame for the options
		DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
						*getstring(91), color_neutral, color_black);

		d.addSelectionLine (getstringdata(92), color_neutral, &languageidx);
		for (int lidx=0; lidx<languagelist.size(); lidx++) {
			charstring s = languagelist[lidx];
			doCapitalize(s);
			d.addSelectionOption (s.data());
		}
		d.addBlankLine();

		d.addActionLine(*getstring(93) + 
			((newtitlemusic=="") ? getstringdata(90) : newtitlemusic), 
			color_neutral, ACTION_TITLEMUSIC);
		d.addActionLine(*getstring(94) + 
			((newbackgroundmusic=="") ? getstringdata(90) : newbackgroundmusic),
			color_neutral, ACTION_BACKGROUNDMUSIC);
		d.addBlankLine();
		d.addSelectionLine(getstringdata(95), color_neutral, &artworkidx);
		for (int aidx=0; aidx<artworklist.size(); aidx++) {
			charstring s = artworklist[aidx];
			doCapitalize(s);
			d.addSelectionOption(s.data());
		}
		d.addSelectionLine(getstringdata(96), color_neutral, &soundworkidx);
		for (int sidx=0; sidx<soundworklist.size(); sidx++) {
			charstring s = soundworklist[sidx];
			doCapitalize(s);
			d.addSelectionOption(s.data());
		}
		d.addBlankLine();

		char line[100];
		sprintf (line, "%s %dx%d",getstringdata(110), newscreenx,newscreeny);
		d.addActionLine(line,color_neutral, ACTION_SCREENRES);

		d.addSelectionLine(getstringdata(115),color_neutral, &imagesize);
		d.addSelectionOption(getstringdata(116));
		d.addSelectionOption(getstringdata(117));

		d.addSelectionLine(getstringdata(119), color_neutral, &newdefaultfont);
		d.addSelectionOption(getstringdata(118));
		d.addSelectionOption(getstringdata(116));
		d.addSelectionOption(getstringdata(117));

		d.addSelectionLine(getstringdata(100),color_neutral, &refreshrate);
		d.addSelectionOption(getstringdata(101));
		d.addSelectionOption(getstringdata(102));
		d.addSelectionOption(getstringdata(103));
		d.addSelectionOption(getstringdata(104));
		d.addSelectionOption(getstringdata(105));
		d.addSelectionOption(getstringdata(106));

		d.addSelectionLine(getstringdata(125),color_neutral, &newtutorshowmode);
		d.addSelectionOption(getstringdata(126));
		d.addSelectionOption(getstringdata(127));
		d.addSelectionOption(getstringdata(128));

		d.addBlankLine();
		d.addActionLine(getstringdata(62),color_neutral, ACTION_OK); 
		d.addActionLine(getstringdata(60),color_neutral, ACTION_CANCEL);
		
		int res = d.doModal();

		switch (res) {
		case ACTION_OK:
			{
			bool dosave=false;
			bool dorestart=false;

			if (refreshrate != getDefaultFrequencyDivide() ) {
				setDefaultFrequencyDivide(refreshrate);
				dosave=true;
			}

			charstring newlanguage=""; 
			if (languageidx<languagelist.size()) newlanguage=languagelist[languageidx];
			if (_stricmp (newlanguage.data(), getcurrentlanguage()->data()) != 0) {
				setcurrentlanguage(newlanguage);
				dosave = true;
				dorestart = true;
				returnvalue = ACTION_RELOADLANGUAGE;
			}

			charstring newartwork = "";
			if (artworkidx<artworklist.size()) newartwork = artworklist[artworkidx];
			if (_stricmp(newartwork.data(),defaultartwork.data()) != 0) {
				defaultartwork = newartwork;
				dosave = true;
				dorestart = true;
				returnvalue = ACTION_RESTARTPROGRAM;
			}	

			charstring newsoundwork=""; 
			if (soundworkidx<soundworklist.size()) newsoundwork=soundworklist[soundworkidx];
			if (_stricmp(newsoundwork.data(),defaultsoundwork.data())!=0) {
				defaultsoundwork = newsoundwork;
				dosave = true;
			}

			if (_stricmp(newtitlemusic.data(),usedtitlemusic.data())!=0) {
				usedtitlemusic = newtitlemusic;
				starttitlemusic();
				dosave = true;
			}
			if (_stricmp(newbackgroundmusic.data(),usedbackgroundmusic.data())!=0) {
				usedbackgroundmusic = newbackgroundmusic;
				dosave = true;
			}
			if (newscreenx != maxxresolution || newscreeny != maxyresolution) {
				maxxresolution = newscreenx;
				maxyresolution = newscreeny;
				dosave = true;
				dorestart = true;
				returnvalue = ACTION_RESTARTPROGRAM;
			}

			if (defaultshrinkfactor != imagesize+1) {
				defaultshrinkfactor = imagesize+1;
				dosave = true;
				dorestart = true;
				returnvalue = ACTION_RESTARTPROGRAM;
			}

			if (newdefaultfont != defaultfont) {
				defaultfont = newdefaultfont;
				dosave = true;
				dorestart = true;
				returnvalue = ACTION_RESTARTPROGRAM;
			}

			if (newtutorshowmode != tutorshowmode) {
				tutorshowmode = newtutorshowmode;
				dosave = true;
				tm->restart();
			}

			if (dosave) saveConfigurationParameter();
			return dorestart;
			}

		case ACTION_TITLEMUSIC:
			selectmusic (getstringdata(97), newtitlemusic);
			break;

		case ACTION_BACKGROUNDMUSIC:
			selectmusic (getstringdata(98), newbackgroundmusic);
			break;

		case ACTION_SCREENRES:
			selectscreenresolution(newscreenx, newscreeny);
			break;

		default:
			return false;
		}
	}

	return false;
}

void about()
{
	// create the dialog frame for the about box
	int col=color_diff[0];
	DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
						*getstring(120), col, color_black);
	d.addTextLine  (getstringdata(121));
	d.addBlankLine();
	d.addActionLine (*getstring(61), col, ACTION_OK);
	d.doModal();
}


bool controlsettings(TutorManager* tm, int &returnvalue)
{
	// read setting values from configuration options
	int newcontrol[2];
	newcontrol[0] = p1control;
	newcontrol[1] = p2control;
	int i,p;
	char buffer[100];
	int selectnext=0;

	// do user input
	for (;;) {
		// create the dialog frame for the options
		DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
						*getstring(170), color_neutral, color_black);
		d.setMaxLines(14);

		for (p=0; p<2; p++) {
			d.addTextLine (getstringdata(171+p));

			switch (newcontrol[p]) {
			case 0:
				d.addActionLine (*getstring(173),color_neutral, 
					(p==0) ? ACTION_CONTROLLER1 : ACTION_CONTROLLER2);
				d.addBlankLine ();
				for (i=178; i<=183; i++) d.addTextLine (getstringdata(i));
				break;
			case 1:
				d.addActionLine (*getstring(174),color_neutral, 
					(p==0) ? ACTION_CONTROLLER1 : ACTION_CONTROLLER2);
				d.addBlankLine ();
				for (i=184; i<=189; i++) d.addTextLine (getstringdata(i));
				break;
			default:
				sprintf (buffer,"%s %d", getstringdata(175), newcontrol[p]-1);
				d.addActionLine (charstring(buffer), color_neutral,
					(p==0) ? ACTION_CONTROLLER1 : ACTION_CONTROLLER2);
				for (i=0; i<7; i++) d.addBlankLine();
			}

			d.addBlankLine();
			if (p==0) {
				for (i=0; i<4; i++)	d.addBlankLine();
			} else {
				d.addActionLine(getstringdata(62),color_neutral, ACTION_OK); 
				d.addActionLine(getstringdata(60),color_neutral, ACTION_CANCEL);
			}
		}
		
		int res = d.doModal(selectnext);
		selectnext=0;

		switch (res) {
		case ACTION_OK:
			{
			bool dosave=false;

			if (newcontrol[0] != p1control || newcontrol[1]!=p2control) {
				p1control = newcontrol[0];
				p2control = newcontrol[1];
				dosave=true;
			}

			if (dosave) saveConfigurationParameter();
			return false;
			}

		case ACTION_CONTROLLER1:
		case ACTION_CONTROLLER2:
			p = (res==ACTION_CONTROLLER1) ? 0 : 1;
			newcontrol[p]++;
			if (newcontrol[p] > 1+numberJoystickPresent()) {
				newcontrol[p] = 0;
			}

			if (res==ACTION_CONTROLLER2) selectnext = 17;
			break;

		case ACTION_CANCEL:
			return false;
		}
	}

	return false;
}




// ---------------------------- PLAY AND DEMO EDITOR ------------------------

void playGame(LevelHeaderPtr& lh, bool continuesuspended)
{
doitagain:
{
	Level* l = NULL;
	Game* g = NULL;
	Artwork* a = NULL;
	BackgroundColorFrame *bcf = NULL;
	GameFrame* gf = NULL;
	GameFrame* gf2 = NULL;
	SoundPlayer* sp = NULL;
	StatusFrame* sf = NULL;
	StatusFrame* sf2 = NULL;
	InputHandler* ih = NULL;
	InputHandler* ih2 = NULL;
	LevelHeader *nextlh = NULL;
	double finishedtime=0;
	double killedtime=0;


	if (! (l = lh->load()) ) goto cleanup;

	if (continuesuspended) {
		g = new Game (l, computeStepsPerTurn(), l->findSuspended());
		while (g->fastForward());
		g->setWriteCursor();
		g->clearSuspendedFlag();
	} else {
		g = new Game (l, computeStepsPerTurn());
	}

	a = new Artwork;
	if (g->level->artwork != "") a->load(g->level->artwork,g->level->movieset,defaultshrinkfactor);
	else					     a->load(defaultartwork,g->level->movieset,defaultshrinkfactor);

	bcf = new BackgroundColorFrame (a->getBackgroundColor());

	gf = new GameFrame (0,0,getScreenWidth(),getScreenHeight(), 
		g, -1, a);

	sf = new StatusFrame1 (getScreenWidth(), getScreenHeight(), 
		g, thePanel);

	ih = createInputHandler(0);
	g->setInputHandler (0, ih);
	if (lh->playersinlevel > 1) {
		InputHandler* ih2 = createInputHandler (1);
		g->setInputHandler (1, ih2);
		sf2 = new StatusFrame2 (0, getScreenHeight(), 
			g, thePanel);
	}


	if (defaultsoundwork!="") sp = new SoundPlayer (g, defaultsoundwork);

	lh->setKnown();
	startLevelMusic(l);


	while (finishedtime < AFTERFINISHED && killedtime < AFTERFINISHED) {
	  gameTick ();
		
	  for (int s=getFrequencyDivide(); s>0; s--) {
		g -> microStepRecord();

		if (g->isDone()) finishedtime += computeTimePerStep();
	    if (g->isDead()) killedtime += computeTimePerStep();

		int cmdcode;
		if ( getCommandEvent (cmdcode) ) {
			switch (cmdcode) {
			case COMMAND_F9:
				toggleScreenMode (g, &gf, &gf2, a);
				break;
			case COMMAND_F8:
				toggleScreenCenter (g, &gf, &gf2);
				break;
			case COMMAND_ESCAPE:
				if (finishedtime > 0) {
					finishedtime = AFTERFINISHED;
				} else {
					int col = lh->getColor();

					DialogFrame df (getScreenWidth()/2,getScreenHeight()/2, 
						*getstring(130), col, color_black);
 
					df.addLevelInfo (lh);
					df.addBlankLine();
					df.addActionLine (*getstring(132), col, ACTION_RETURN);
					df.addActionLine (*getstring(131), col, ACTION_RESTART);
					if(continuesuspended) {
						df.addActionLine (*getstring(137), col, ACTION_CONTINUESUSPENDED);
					}
					df.addActionLine (*getstring(133), col, ACTION_SUSPEND);
					if (continuesuspended) {
						df.addActionLine (*getstring(134), col, ACTION_DELETESUSPENDED);
					}
					if (lh->playersinlevel>1) {
						df.addBlankLine();
						df.addActionLine(*getstring(160), col, ACTION_SCREENCENTER);
						df.addActionLine(*getstring(161), col, ACTION_TOGGLESPLIT);
					}

					int r = df.doModal();

					switch (r) {
					case ACTION_RETURN: goto cleanup;
					case ACTION_RESTART:
						g->resetAndClearWalkthrough();
						break;
					case ACTION_CONTINUESUSPENDED:
						nextlh = lh;
						goto cleanup_againsuspended;
					case ACTION_SUSPEND:
						if (g->saveSuspended()) {
							lh->extractLevel(l);
							goto cleanup;
						} else {
							DialogFrame err (getScreenWidth()/2,getScreenHeight()/2, 
								*getstring(135), color_menu, color_black);
							err.addTextLine (*getstring(136), color_menu);
							err.addBlankLine();
							err.addActionLine (*getstring(61), color_menu, 0);
							err.doModal();
						}
						break;
					case ACTION_DELETESUSPENDED:
						l->deleteSuspended();
						if (l->save()) {
							lh->extractLevel(l);
						}
						goto cleanup;
						break;

					case ACTION_SCREENCENTER:
						addCommandEvent (COMMAND_F8,0);
						break;
					case ACTION_TOGGLESPLIT:
						addCommandEvent (COMMAND_F9,0);
						break;
					}
				}
				break;
			}
		} // end if

		if (sp) sp->run();
	  }
	}

	if (finishedtime>0) {
	// the player has finished the game!!
		lh->setFinished();
		if (l->nextlevel != "") nextlh = findLevelHeader (l->nextlevel.data());
		if (nextlh == NULL) nextlh = findNextLevelHeader(lh);

		DialogFrame df (getScreenWidth()/2,getScreenHeight()/2, 
			*getstring((lh->playersinlevel > 1) ? 139 : 140), 
			lh->getColor(), color_black);
		if (nextlh) {
			df.addActionLine (*getstring (141)+" "+*(nextlh->longname.get()), nextlh->getColor(), ACTION_NEXTLEVEL);
		}
		df.addActionLine (*getstring (142), lh->getColor(), ACTION_RETURN);
		df.addActionLine (*getstring (143), lh->getColor(), ACTION_SAVEDEMO);

		int ret = df.doModal();
		if (ret != ACTION_NEXTLEVEL) {	nextlh=NULL; }
		if (ret == ACTION_SAVEDEMO) {
			charstring name;
			l->getWalkthroughName(-1,name);

			if (demoNameDialog (name, lh->getColor())) {
				if (!continuesuspended) g->setReplayFlag();
				int idx=-1;
				if (g->saveWalkthrough (idx, name)) {
					lh->extractLevel (l);
				}
			}
		}
	} else {
		// the player has been killed
		DialogFrame df (getScreenWidth()/2,getScreenHeight()/2, 
						*getstring(144), lh->getColor(), color_black);

		if(continuesuspended) {
			df.addActionLine (*getstring(137), lh->getColor(), ACTION_CONTINUESUSPENDED);
		}
		df.addActionLine (*getstring (131), lh->getColor(), ACTION_RESTART);
		df.addActionLine (*getstring (132), lh->getColor(), ACTION_RETURN);

		switch (df.doModal()) {
		case ACTION_RESTART: 
			nextlh=lh;
			break;
		case ACTION_CONTINUESUSPENDED: 
			nextlh=lh; 
			goto cleanup_againsuspended;
			break;
		}
	}

cleanup:
	if (nextlh) continuesuspended=false;
cleanup_againsuspended:

	delete sf;
	delete sf2;
	delete sp;
	delete gf;
	delete gf2;
	delete bcf;
	delete a;
	delete g;
	delete l;
	delete ih;
	delete ih2;

	if (nextlh) {
		lh = nextlh;
		goto doitagain;
	}
}
}


void playDemo(LevelHeader* lh, int walkthroughindex) 
{
	Level* l = NULL;
	Game* g = NULL;
	Artwork* a = NULL;
	BackgroundColorFrame* bcf = NULL;
	GameFrame* gf = NULL;
	GameFrame* gf2 = NULL;
	SoundPlayer* sp = NULL;
	StatusFrame* sf = NULL;
	StatusFrame* sf2 = NULL;
	VCRFrame* vf = NULL;
	ReplayFrame* rf = NULL;
	InputHandler* ih = NULL;
	InputHandler* ih2 = NULL;

	bool showeditmenu=false;
	bool didshoweditmenu=false;
	bool usedvcr=false;
	double finishedtime=0;

	enum { fastbackward=0, playbackward, slowbackward, 
		   stop, 
		   slowforward, playforward, fastforward,
		   record, recordsingle, recordtakeback };
	int recordermode,newrecordermode;
	int slowcounter;

	if (! (l = lh->load()) ) goto cleanup;
	if (walkthroughindex>=0) {
		g = new Game (l, computeStepsPerTurn(), walkthroughindex);
		recordermode = playforward;
	} else {
		g = new Game (l, computeStepsPerTurn());
		recordermode = record;
	}
	a = new Artwork;
	if (g->level->artwork != "") a->load(g->level->artwork,g->level->movieset,defaultshrinkfactor);
	else					     a->load(defaultartwork,g->level->movieset,defaultshrinkfactor);

	bcf = new BackgroundColorFrame (a->getBackgroundColor());

	gf = new GameFrame (0,0,getScreenWidth(),getScreenHeight(), 
		g, -1, a);

	sf = new StatusFrame1 (getScreenWidth(), getScreenHeight(), 
		g, thePanel);
	vf = new VCRFrame (0,0, g, &recordermode, theVCR, 9);
	if (g->hasReplayWalkthrough()) {
		rf = new ReplayFrame (0,vf->getBottom(), g, theVCR, computeStepsPerTurn());
	}

	ih = createInputHandler (0);
	g->setNeedCheckPoints(true);
	g->setInputHandler (0, ih);
	if (lh->playersinlevel>1) {
		ih2 = createInputHandler (1);
		g->setInputHandler (1, ih2);
		sf2 = new StatusFrame2 (0, getScreenHeight(), 
			g, thePanel);
	}

	if (defaultsoundwork!="") sp = new SoundPlayer (g, defaultsoundwork);
	
	lh->setKnown();
	startLevelMusic(l);

	newrecordermode = recordermode;
	slowcounter = 0;
	for (;;) {	
	  if (rf) rf->heartbeat();
	  gameTick();


	  // determine how fast the game logic should be computed
	  int s = getFrequencyDivide();
	  if (recordermode==fastbackward || recordermode==fastforward) {
		  s=1;
	  } else if (recordermode==playbackward	|| recordermode==slowbackward) {
		  if (s>4) s=4;
	  }

      for (; s>0; s--) {

		switch (recordermode) {
		case fastbackward:
			if (!g -> fastBackward()) newrecordermode = stop;
			break;
		case playbackward:
			if (!g -> microStepBackward()) newrecordermode = stop;
			break;
		case slowbackward:
			if ( (++slowcounter) >= SLOWMOTIONFACTOR ) {
				slowcounter=0;
				if (!g -> microStepBackward()) newrecordermode = stop;
			}
			break;
		case stop:
			break;
		case slowforward:
			if ( (++slowcounter) >= SLOWMOTIONFACTOR ) {
				slowcounter=0;
				if (!g -> microStepForward()) newrecordermode = stop;
				g->forgetSounds();
			}
		break;
		case playforward:
			if (!g -> microStepForward()) newrecordermode = stop;
			if (!usedvcr && g->endOfWalkthrough()) goto cleanup;
			break;
		case fastforward:
			if (!g -> fastForward()) newrecordermode = stop;
			break;
		case record:
			g -> microStepRecord();
			if (!usedvcr) {
				if (g->isDone() || g->isDead()) finishedtime+=computeTimePerStep();
				if (finishedtime > AFTERFINISHED && !didshoweditmenu) showeditmenu=true;
			}
			break;
		case recordsingle:
			g -> microStepRecordSingle();
			break;
		case recordtakeback:
			g -> microStepDelete();
			newrecordermode = recordsingle;
			break;
		}

		int cmdcode; 
		if ( getCommandEvent (cmdcode)) {
				switch (cmdcode) {
				case COMMAND_F9:
					toggleScreenMode (g, &gf, &gf2, a);
					break;
				case COMMAND_F8:
					toggleScreenCenter (g, &gf, &gf2);
					break;
				case COMMAND_ESCAPE: 
					showeditmenu=true;
					break;
				case COMMAND_F1:
					newrecordermode = fastbackward;
					break;
				case COMMAND_F3F1:
					g->reset();
					newrecordermode = stop;
					break;
				case COMMAND_F2:
					newrecordermode = playbackward;
					break;
				case COMMAND_F3F2:
					newrecordermode = slowbackward;
					break;
				case COMMAND_F3:
					newrecordermode = stop;
					break;
				case COMMAND_F4:
					newrecordermode = playforward;
					break;
				case COMMAND_F3F4:
					newrecordermode = slowforward;
					break;
				case COMMAND_F5:
					newrecordermode = fastforward;
					break;
				case COMMAND_F3F5:
					while (g->fastForward());
					newrecordermode = stop;
					break;
				case COMMAND_F6:
					newrecordermode = record;
					break;
				case COMMAND_F7:
					newrecordermode = recordsingle;
					break;

				case COMMAND_CONTINUE:
					if (recordermode == recordsingle) {
						g->insertRests();
					}
					break;

				case COMMAND_NO:
					if (recordermode == recordsingle || recordermode == record) {
						newrecordermode = recordtakeback;
					}
					break;
				}				

		}



		if (g->getMicroCounter() == 0) {
			if ( newrecordermode != recordermode ) {
				
				if (newrecordermode == record) {
					g -> cutWalkthrough();
				} else if (newrecordermode == recordsingle) {
					g -> setWriteCursor();
				} else if (newrecordermode == recordtakeback) {
					if (g -> deleteWriteBuffers()) {
						newrecordermode = recordsingle;
					}
				}

				recordermode = newrecordermode;
				usedvcr=true;
			}
		}



		if (showeditmenu) {
			showeditmenu=false;
			didshoweditmenu=true;

			int col = lh->getColor();

			DialogFrame df (getScreenWidth()/2,getScreenHeight()/2, 
				*getstring(150), col, color_black);

			df.addActionLine (*getstring(132), col, ACTION_RETURN);
			df.addBlankLine();

			if (walkthroughindex>=0) {
				charstring name;
				l->getWalkthroughName(walkthroughindex, name);
				df.addActionLine (*getstring(151)+" "+name, col, ACTION_SAVEDEMO);
				df.addActionLine (*getstring(152)+" "+name, col, ACTION_DELETEDEMO);
			}
			df.addActionLine (*getstring(153), col, ACTION_SAVENEWDEMO);

			df.addActionLine(*getstring(162), col, ACTION_VCR);
			if (lh->playersinlevel>1) {
				df.addBlankLine();
				df.addActionLine(*getstring(160), col, ACTION_SCREENCENTER);
				df.addActionLine(*getstring(161), col, ACTION_TOGGLESPLIT);
			}
			

			int r = df.doModal();

			switch (r) {
			case ACTION_RETURN: 
				goto cleanup;
			case ACTION_DELETEDEMO:
				if (walkthroughindex>=0) {
					l->deleteWalkthrough (walkthroughindex);
					if (l->save()) {
						lh->extractLevel (l);
					}
					goto cleanup;
				}
				break;

			case ACTION_SAVEDEMO:
			case ACTION_SAVENEWDEMO:
				{
					charstring name = "";
					int idx = (r==ACTION_SAVEDEMO) ? walkthroughindex : -1;
							
					l->getWalkthroughName(idx,name);

					if (demoNameDialog (name, col)) {

						if (g->saveWalkthrough (idx, name)) {
							walkthroughindex = idx;
							lh->extractLevel (l);
							goto cleanup;
						} else {
							DialogFrame ok(getScreenWidth()/2,getScreenHeight()/2,
								*getstring (154), color_menu, color_black);
							ok.addTextLine (*getstring(155), color_menu);
							ok.addBlankLine ();
							ok.addActionLine (*getstring(61), color_menu, 0);
							ok.doModal();
						}
					}
				}
				break;

			case ACTION_SCREENCENTER:
				addCommandEvent (COMMAND_F8,0);
				break;
			case ACTION_TOGGLESPLIT:
				addCommandEvent (COMMAND_F9,0);
				break;

			case ACTION_VCR:
				{
				DialogFrame d(getScreenWidth()/2,getScreenHeight()/2, 
					*getstring(260), color_neutral, color_black);
				d.addActionLine (*getstring(261), color_neutral, 1);
				d.addActionLine (*getstring(262), color_neutral, 2);
				d.addActionLine (*getstring(263), color_neutral, 3);
				d.addActionLine (*getstring(264), color_neutral, 4);
				d.addActionLine (*getstring(265), color_neutral, 5);
				d.addActionLine (*getstring(266), color_neutral, 6);
				d.addActionLine (*getstring(267), color_neutral, 7);
				d.addActionLine (*getstring(268), color_neutral, 8);
				d.addActionLine (*getstring(269), color_neutral, 9);
				d.addActionLine (*getstring(270), color_neutral, 10);
				d.addActionLine (*getstring(271), color_neutral, 11);
				switch (d.doModal()) {
				case 1:	 addCommandEvent (COMMAND_F1,0); break;
				case 2:	 addCommandEvent (COMMAND_F2,0); break;
				case 3:	 addCommandEvent (COMMAND_F3,0); break;
				case 4:	 addCommandEvent (COMMAND_F4,0); break;
				case 5:	 addCommandEvent (COMMAND_F5,0); break;
				case 6:	 addCommandEvent (COMMAND_F6,0); break;
				case 7:	 addCommandEvent (COMMAND_F7,0); break;
				case 8:  addCommandEvent (COMMAND_F3F1,0); break;
				case 9:  addCommandEvent (COMMAND_F3F2,0); break;
				case 10: addCommandEvent (COMMAND_F3F4,0); break;
				case 11: addCommandEvent (COMMAND_F3F5,0); break;
				}
				}
			}
		} // end switch

		if (sp) sp->run();
	  }
	}

cleanup:
	delete rf;
	delete vf;
	delete sf;
	delete sf2;
	delete sp;
	delete gf;
	delete gf2;
	delete bcf;
	delete a;
	delete g;
	delete l;
	delete ih;
	delete ih2;
}


bool demoNameDialog (charstring& name, int color)
{
	DialogFrame df (getScreenWidth()/2,getScreenHeight()/2, 
					*getstring(156), color, color_black);
	df.addEditLine( (*getstring(157)+" ").data() ,color, ACTION_OK,&name,20);
	df.addBlankLine();
	df.addActionLine (*getstring(158), color, ACTION_OK);
	df.addActionLine (*getstring(60), color, ACTION_CANCEL);

	return df.doModal() == ACTION_OK;
}

LevelHeader* startEditor(LevelHeader* lh)
{
	Level* l;
	if (lh==NULL) {
		l = new Level();

		if (editLevel (l)) {
			if (l->save()) {
				lh = new LevelHeader;
				lh->extractLevel (l);
				levellist.push_back (lh);
				DOLOG (2, "created level: %s", lh->longname.getdefault()->data());
			}
		}
		delete l;
		return lh;
	}

	if (! (l = lh->load()) ) return lh;

	if (editLevel (l)) {
		if (l->save()) {
			lh->extractLevel(l);
		}
	}
	delete l;
	return lh;
}


// ---------------- performance monitor object -----------------

PerformanceMonitor::PerformanceMonitor (int x, int y)
: Frame (x-letterwidth*4,y, x,y+3*letterheight, true)
{
	str = "    ";
	smoothcpu=0.5;
	nthmessure = 0;
	setAlwaysDirty();

	frontpopper.setFrame(this);
}

PerformanceMonitor::~PerformanceMonitor() 
{
};

void PerformanceMonitor::call()
{
	moveToFront();
}

void PerformanceMonitor::update (int currentpage, int x1, int y1, int x2, int y2)
{
	char ustr[10];
	double u = getCPUUsage();
	if (u>smoothcpu) {
		smoothcpu=u;
		nthmessure=100;
	}

	if ( (nthmessure--) < 1) {
		smoothcpu = 0;
		nthmessure = 0;
	}

	sprintf (ustr, "%3d%%", (int) (u*100));
	str = ustr;
	drawString (&theScreen, left,top, str,4, color_neutral, false,false, x1,y1,x2,y2);
	sprintf (ustr, "%3d%%", (int) (smoothcpu*100) );
	str = ustr;
	drawString (&theScreen, left,top+letterheight, str,4, color_neutral, false,false, x1,y1,x2,y2);
	sprintf (ustr, "%3df", getFrequencyDivide() );
	str = ustr;
	drawString (&theScreen, left,top+2*letterheight, str,4, color_neutral, false,false, x1,y1,x2,y2);
};


// ------------ Main menu frame object ------------------------

MainMenuFrame::MainMenuFrame(int l, int t, int r, int b)
	: BufferedTransparentFrame (l,t,r,b, theFont->getAlternativeTransparentColor() )
{
	currentcatindex=2;
	currentitemindex=-1;

	linespercolumn = (bottom-top)/(letterheight+levelspacing);
	columnsperscreen = ( (r-l)/letterwidth - catwidth )/columnwidth;
}


MainMenuFrame::~MainMenuFrame()
{
	for (int i=0; i<categories.size(); i++) delete categories[i];
}


void MainMenuFrame::addCategory (int index, const charstring& name, int color, int actionid)
{
	Category* c;

	if (categories.size()<=index) categories.resize(index+1);
	categories[index] = c = new Category;
	c->name = name;
	c->color = color;
	c->actionid = actionid;
}

charstring* MainMenuFrame::getCategoryName(int index)
{
	if (index>categories.size()) return NULL;
	return &(categories[index]->name);
}

void MainMenuFrame::addMenuItem (int catindex, int itemid, const charstring& name, int color)
{
	Category* c = categories[catindex];
	MenuItem* i = new MenuItem;
	c->items.push_back (i);
	i->itemid = itemid;
	i->name = name;	
	i->color = color;
}

	
void MainMenuFrame::selectItem (int itemid)
{
	for (currentcatindex=0; currentcatindex<categories.size(); currentcatindex++) {
		Category* c = categories[currentcatindex];
		for (currentitemindex=0; currentitemindex<c->items.size(); currentitemindex++) {
			if (c->items[currentitemindex]->itemid == itemid) {
				setAllDirty();
				return;
			}
		}
	}
	currentcatindex=0;
	currentitemindex=-1;

	setAllDirty();
}

void MainMenuFrame::selectCategory (int catindex)
{
	currentcatindex = catindex;
	currentitemindex=-1;
	setAllDirty();
}


int MainMenuFrame::getFirstColumnOnScreen()
{
	if (currentitemindex==-1) return 0;
	int col = currentitemindex / linespercolumn;
	if (col<columnsperscreen) return 0;
	return (col-columnsperscreen)+1;
}

int MainMenuFrame::columnsInCategory(Category* c)
{
	return (c->items.size() + linespercolumn-1) / linespercolumn;
}

bool MainMenuFrame::processSelection(int &selecteditem)
{
	int cmdcode;
	int parameter;
	while (getCommandEvent (cmdcode,parameter)) {

		int prevcatindex=currentcatindex;
		int previtemindex=currentitemindex;
		int prevfirstcolumn=getFirstColumnOnScreen();

		Category* c = categories[currentcatindex];

		switch (cmdcode) {
		case COMMAND_NO:
		case COMMAND_ESCAPE:
			selecteditem = ACTION_CANCEL;
			return true;

		case COMMAND_DOWN:
			if (currentitemindex==-1) {
				if (currentcatindex<categories.size()-1) {
					currentcatindex++;
				}
			} else {
				if (currentitemindex<c->items.size()-1
					&&  currentitemindex%linespercolumn != (linespercolumn-1)) {
					currentitemindex++;
				}
			}
			break;

		case COMMAND_UP:
			if (currentitemindex==-1) {
				if (currentcatindex>0) {
					currentcatindex--;
				}
			} else {
				if (currentitemindex % linespercolumn != 0) {
					currentitemindex--;
				}
			}
			break;

		case COMMAND_RIGHT:
			if (currentitemindex==-1) {
				currentitemindex = minimum(currentcatindex, c->items.size()-1);
			} else {
				if (columnsInCategory(c) > (currentitemindex/linespercolumn)+1) {
					currentitemindex = minimum (currentitemindex+linespercolumn,c->items.size()-1);
				}
			}
			break;
			
		case COMMAND_LEFT:
			if (currentitemindex!=-1) {
				if (currentitemindex>=linespercolumn) {
					currentitemindex-=linespercolumn;
				} else {
					currentitemindex=-1;
				}
			}
			break;

		case COMMAND_PRIOR:
			if (currentcatindex>0) {
				currentcatindex--;
				currentitemindex = minimum(currentitemindex,
						categories[currentcatindex]->items.size()-1);
			}
			break;

		case COMMAND_NEXT:
			if (currentcatindex<categories.size()-1) {
				currentcatindex++;
				currentitemindex = minimum(currentitemindex,
						categories[currentcatindex]->items.size()-1);
			}
			break;
	
		case COMMAND_HOME:
			if (c->items.size()>0 && currentitemindex!=0) {
				currentitemindex=0;
			}
			break;

		case COMMAND_END:
			if (c->items.size()>0 && currentitemindex!=c->items.size()-1) {
				currentitemindex=c->items.size()-1;
			}
			break;

		case COMMAND_YES:
			if (currentitemindex!=-1) {
				selecteditem = c->items[currentitemindex]->itemid;
				return true;
			} else {
				if (c->actionid!=ACTION_NONE) {
					selecteditem = c->actionid;
					return true;
				}
				currentitemindex = minimum(currentcatindex, c->items.size()-1);
			}
			break;
		}


		// check if we need an update of the screen
		if (currentcatindex!=prevcatindex 
		||	(currentitemindex==-1 && previtemindex!=-1)
		||  (currentitemindex!=-1 && previtemindex==-1)
		||	(prevfirstcolumn != getFirstColumnOnScreen())
		) {
			setAllDirty();
		} else {
			if (currentitemindex != previtemindex) {
				setItemDirty (prevfirstcolumn,previtemindex);
				setItemDirty (getFirstColumnOnScreen(),currentitemindex);
			}
		}

	}
	return false;
}


void MainMenuFrame::subtractFreeArea (RectangleList& usedarea)
{
	// area that is left blank beneath category column
	usedarea.subtractRect (left,top+categories.size()*(letterheight+categoryspacing)+categoryspacing,
						   left+catwidth*letterwidth,bottom);

	// get last item on screen
	Category* c = categories[currentcatindex];
	int first=getFirstColumnOnScreen();
	int lines=linespercolumn;
	int iidx=c->items.size();
	int x1=left+(catwidth*letterwidth) + (iidx/lines-first)*letterwidth*columnwidth;
	int y1=top+ (iidx%lines)*(letterheight+levelspacing);

	// subtract everything below that
	usedarea.subtractRect (x1,y1,right,bottom);

	// subtract everything that is farther to the right
	usedarea.subtractRect (x1+columnwidth*letterwidth, top,right,bottom);
}

void MainMenuFrame::updateBuffer (int x1, int y1, int x2, int y2)
{
	// clear background
	SurfacePainter bufferpainter(buffer);
	bufferpainter.fill (transparentcolor, x1-left,y1-top,x2-left,y2-top);

	// draw category column
	for (int i=0; i<categories.size(); i++) {
		drawString (&bufferpainter,
			0, 
			i*(letterheight+categoryspacing)+categoryspacing, 
			categories[i]->name, 13, categories[i]->color, 
			(i==currentcatindex), 
			(i==currentcatindex) && (currentitemindex==-1),
			x1-left,y1-top,x2-left,y2-top);
	}

	// draw contents of the category
	Category* c = categories[currentcatindex];
	int lines=linespercolumn;
	int first=getFirstColumnOnScreen();
	int last=first+columnsperscreen-1;
	int col = c->color;
	for (int iidx=first*lines; iidx<(last+1)*lines; iidx++) {
		if (iidx<c->items.size()) {
			MenuItem* item = c->items[iidx];
			txt = item->name;
			col = item->color;
		} else {
			txt = "";
		}
		if (txt.size()>columnwidth) txt[columnwidth-1] = LETTER_DOTS;
		txt.resize(columnwidth,' ');

		if (iidx==last*lines+lines-1
			&& c->items.size()>(last+1)*lines) {
			txt[columnwidth-1] = LETTER_RIGHTARROW;
		}

		drawString ( 
			&bufferpainter,
			(catwidth*letterwidth) + (iidx/lines-first)*letterwidth*columnwidth,
			(iidx%lines)*(letterheight+levelspacing),
			txt, columnwidth, col, false, iidx==currentitemindex,
			x1-left,y1-top, x2-left,y2-top );
	}
}

void MainMenuFrame::setItemDirty(int first, int iidx)
{
	int lines=linespercolumn;
	int x=left+(catwidth*letterwidth) + (iidx/lines-first)*letterwidth*columnwidth;
	int y=top+ (iidx%lines)*(letterheight+levelspacing);
	setDirty (x,y,x+columnwidth*letterwidth,y+letterheight);
}



// --------------- everything for DialogFrame ----------------------

void DialogFrame::computePosition()
{
	maxwidth=0;
	for (int i=0; i<lines.size(); i++) {
		int l = lines[i].text.size();
		if (l>maxwidth) maxwidth=l;

		if (lines[i].type == DialogLine::selectionline) {
			for (int j=0; j<lines[i].selectiontexts.size(); j++) {
				l = lines[i].selectiontexts[j].size();
				if (l>maxwidth) maxwidth = l;
			}
		} else if (lines[i].type == DialogLine::editline) {
			l = lines[i].text.size() + lines[i].editlen + 1;
			if (l>maxwidth) maxwidth = l;
		}
	}

	int columns = 1;
	int rows = lines.size();
	if (lines.size()>maxlines) {
		columns = (lines.size()+maxlines-1)/maxlines;
		rows = maxlines;
	}

	int w = maxwidth*letterwidth*columns + borderwidth*2 + hborderpad*2;
	int h = rows*letterheight + borderwidth*2 + vborderpad*2;

	resize (midx-w/2, midy-h/2, midx+w/2,midy+h/2);
}

DialogFrame::DialogLine* DialogFrame::addLine ()
{
	int s = lines.size();
	lines.resize(s+1);
	return &(lines[s]);
}

DialogFrame::DialogFrame (int _midx, int _midy, const charstring& _title, int _color, int _backgroundcolor)
	: Frame (_midx, _midy, _midx, _midy, false)
{
	midx = _midx;
	midy = _midy;
	title = _title;
	color = _color;
	backgroundcolor =_backgroundcolor;
	maxwidth = 0;
	maxlines=99;
	selectionline = -1;
	editcolumn = 99999;
	enterkeywashit = false;
	backspacewashit = false;

	if (_title!="") {
		addTextLine (_title, _color);
		addBlankLine ();
	}

	DOLOG (2, "dialog frame opened");
}

DialogFrame::~DialogFrame()
{
}


void DialogFrame::addLevelInfo (LevelHeader* h) 
{
	int col = h->getColor();
	vector<charstring> lines;

	h->getLevelInfo(lines);
	for (int l=0; l<lines.size(); l++) {
		addTextLine(lines[l],col);
	}
}

void DialogFrame::addBlankLine ()
{
	charstring s;
	addTextLine (s,0);
}

void DialogFrame::addTextLine (const charstring& txt, int color)
{
	int first=0;
	while (first<=txt.size()) {
		int last;
		for (last=first; last<txt.size() && txt[last]!='\n'; last++);

		DialogLine* l = addLine();
		l->type = DialogLine::textline;
		l->text = txt.substr(first,last-first);
		l->color = color;
		
		first = last+1; // skip the '\n'
	}

	computePosition();
}

void DialogFrame::addTextLine (char* txt)
{
	addTextLine (charstring(txt), color);
}

void DialogFrame::addActionLine (const charstring& txt, int color, int id)
{
	DialogLine* l = addLine();
	l->type = DialogLine::actionline;
	l->text = txt;
	l->color = color;
	l->id = id;
	computePosition();
}

void DialogFrame::addSelectionLine (const charstring& prompt, int color, int* selectvar)
{
	DialogLine* l = addLine();
	l->type = DialogLine::selectionline;
	l->text = prompt;
	l->color = color;
	l->selectvar = selectvar;
	computePosition();
}

void DialogFrame::addSelectionOption (const charstring& option)
{
	if (lines.size()>0) {
		DialogLine* l = &(lines[lines.size()-1]);
		charstring thistext = l->text + " " + option;
		l->selectiontexts.push_back (thistext);
	}
	computePosition();
}

void DialogFrame::addEditLine (const charstring& prompt, int color, int id, charstring* editvar, int editlen)
{
	DialogLine* l = addLine();
	l->type = DialogLine::editline;
	l->text = prompt;
	l->color = color;
	l->id = id;
	l->editvar = editvar;
	l->editlen = editlen;
	computePosition();
}


void DialogFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	// clear background
	theScreen.fill (backgroundcolor, x1,y1,x2,y2);

	// draw the border
	theScreen.drawBorder (color, left,top,right,bottom, borderwidth,  x1,y1,x2,y2);

	// draw the contents of the box
	int row=0;
	int col=0;
	for (int i=0; i<lines.size(); i++) {
		int ox=left+borderwidth+hborderpad+col*maxwidth*letterwidth;
		int oy=top+borderwidth+vborderpad + row*letterheight;

		DialogLine* l = &(lines[i]);
		switch (l->type) {
		case DialogLine::textline:
		case DialogLine::actionline:
			drawString (&theScreen, ox, oy,
				l->text, maxwidth, l->color, false, (i==selectionline), 
				x1,y1,x2,y2);
			break;
		case DialogLine::selectionline:
			if (*(l->selectvar) >= l->selectiontexts.size()) 
				*(l->selectvar) = 0;
			drawString (&theScreen, ox, oy,
				l->selectiontexts[*(l->selectvar)], 
				maxwidth, l->color, false, (i==selectionline), 
				x1,y1,x2,y2);
			break;
		case DialogLine::editline:
			drawString (&theScreen, ox, oy,
				l->text + *(l->editvar),
				maxwidth, l->color, false, (i==selectionline), 
				x1,y1,x2,y2);
			if (i==selectionline) {
				if (editcolumn>=0 && editcolumn<=l->editvar->size()) {
					int c = l->text.size() + editcolumn;
					theScreen.drawBorder(color_black, 
						ox+letterwidth*c,oy,
						ox+letterwidth*c+3,oy+letterheight,	1,
						x1,y1,x2,y2);
					theScreen.drawBorder(color_white, 
						ox+letterwidth*c+1,oy+1,
						ox+letterwidth*c+2,oy+letterheight-1, 1,
						x1,y1,x2,y2);
				}
			}
			break;
		}		
		
		row++;
		if (row>=maxlines) {
			col++;
			row=0;
		}
	}
}

int DialogFrame::doModal(int nowselected, int nowselectedcolumn,bool returnbackspace)
{
	moveToFront();

	int selectiondir=0;	
	selectionline=-1;

	// do to first selectable line
	for (int i=lines.size()-1; i>=0; i--) {
		if (lines[i].type!=DialogLine::textline) selectionline=i;
	}
	if (nowselected>=0 && nowselected<lines.size()
	&& lines[nowselected].type!=DialogLine::textline) {
		selectionline = nowselected;
	}

	editcolumn=nowselectedcolumn;
	if (lines[selectionline].type==DialogLine::editline) {
		editcolumn = minimum(editcolumn, lines[selectionline].editvar->size());
	}

	for (;;) {
		gameTick();

		int cmdcode,cmdparam;
		while (getCommandEvent (cmdcode,cmdparam)) {
			if (selectionline<0) continue;

			DialogLine* l = &(lines[selectionline]);

			switch (cmdcode) {
			case COMMAND_ESCAPE: 
				clearDeviceEvents();
				return ACTION_CANCEL;

			case COMMAND_UP:	
				selectiondir=-1;
				break;

			case COMMAND_DOWN:
				selectiondir=1;
				break;

			case COMMAND_RIGHT:
				if (l->type != DialogLine::editline) {
					selectiondir=+maxlines;
				} else {
					if (editcolumn<l->editvar->size()) editcolumn++;
					setDirty();
				}
				break;

			case COMMAND_LEFT:
				if (l->type != DialogLine::editline) {
					selectiondir=-maxlines;
				} else {
					if (editcolumn>0) editcolumn--;
					setDirty();
				}
				break;

			case COMMAND_HOME:
				if (l->type == DialogLine::editline) {
					editcolumn=0;
					setDirty();
				}
				break;
			case COMMAND_END:
				if (l->type == DialogLine::editline) {
					editcolumn=l->editvar->size();
					setDirty();
				}
				break;

			case COMMAND_ENTERKEY:
				if (l->type==DialogLine::editline) {
					enterkeywashit=true;
				}
				break;

			case COMMAND_YES:
				switch (l->type) {
				case DialogLine::actionline:
				case DialogLine::editline:
					clearDeviceEvents();
					return l->id;
				}

			case COMMAND_NEXT:
				switch (l->type) {
				case DialogLine::selectionline:
					*(l->selectvar) = (*(l->selectvar) + 1) % (l->selectiontexts.size());
					setDirty();
					break;
				}
				break;

			case COMMAND_PRIOR:
				switch (l->type) {
				case DialogLine::selectionline:
					*(l->selectvar) = (*(l->selectvar)+l->selectiontexts.size()- 1) % (l->selectiontexts.size());
					setDirty();
					break;
				}
				break;

			case COMMAND_BACKSPACE:
				if (l->type==DialogLine::editline && editcolumn==0 && returnbackspace) {
					backspacewashit=true;

					int dummy;
					getCommandEvent(dummy);  // remove the later following COMMAND_NO

					return l->id;
				}
				break;

			case COMMAND_NO:
				if (l->type != DialogLine::editline) break;

				if (editcolumn<=0) break;
				editcolumn--;

			case COMMAND_DELETE:
				if (l->type != DialogLine::editline) break;

				if (editcolumn<0) editcolumn=0;
				if (editcolumn>l->editvar->size()) editcolumn=l->editvar->size();

				if (editcolumn<l->editvar->size()) {
					charstring* s = l->editvar;
					for (int i=editcolumn; i<s->size()-1; i++) {
						(*s)[i] = (*s)[i+1];
					}
					s->resize(s->size()-1);
					setDirty();
				}
				break;

			case COMMAND_LETTER:
				if (l->type!=DialogLine::editline) break;

				if (editcolumn<0) editcolumn=0;
				if (editcolumn>l->editvar->size()) editcolumn=l->editvar->size();

				if ( cmdparam>=' ' && cmdparam<=255) {
					charstring* s = l->editvar;
					if (s->size()<l->editlen) {
						s->resize(s->size()+1,' ');
						for (int i=s->size()-2; i>=editcolumn; i--) {
							(*s)[i+1] = (*s)[i];
						}
						(*s)[editcolumn] = cmdparam;
						editcolumn++;
						setDirty();
					}
				}
				break;
			}

			// find next possible position for the selectionline
			if (selectiondir!=0) {
				int newline=selectionline+selectiondir;
				while ( newline>=0 && newline<lines.size() ) {
					if (lines[newline].type!=DialogLine::textline) {
						selectionline=newline;
						break;
					}
					newline+=selectiondir;
					if (selectiondir>1) selectiondir=1;
					if (selectiondir<-1) selectiondir=-1;
				}
				setDirty();

				DialogLine* l = &(lines[selectionline]);
				if (l->type==DialogLine::editline) {
					if (editcolumn > l->editvar->size()) editcolumn=l->editvar->size(); 
				}
			}
			selectiondir=0;
		}
	}
}

bool DialogFrame::getEnterKeyPosition(int &line, int &column)
{
	if (!enterkeywashit) return false;
	line = selectionline;
	column = editcolumn;
	return true;
}

bool DialogFrame::getBackspacePosition(int &line, int &column)
{
	if (!backspacewashit) return false;
	line = selectionline;
	column = editcolumn;
	return true;
}


TextFrame::TextFrame (int x, int y, charstring& _text, int _color)
: Frame (x-(_text.size()*letterwidth)/2,y,
		 x+(_text.size()*letterwidth)/2,y+letterheight, true)
{
	color = _color;
	text = _text;

	surface = createSurface(getWidth(),getHeight(), 
		theFont->getAlternativeTransparentColor());
	if (surface) surface->isdestroyed=true;
}

TextFrame::~TextFrame()
{
	delete surface;
}

void TextFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	if (!surface) return;

	if (surface->isdestroyed) {
		SurfacePainter p(surface);
		drawString (&p, 0,0, text, text.size(), color, false, false, 
			0,0, getWidth(), getHeight() );
		surface->isdestroyed=false;
	}

	theScreen.drawClipped (surface, 0,0, left,top,right,bottom, 
		x1,y1,x2,y2, true);
}



TutorManager::TutorManager(int _numplayer,
						   Frame* above)
{
	level = NULL;
	game = NULL;
	gf = NULL;
	sf = NULL;
	tf = NULL;

	numplayer = _numplayer;

	frameabove = above;

	gamecounter=0;
}

TutorManager::~TutorManager()
{
	closeContent();
}

void TutorManager::closeContent()
{
	delete gf;
	delete a;
	delete sf;
	delete sf2;
	delete tf;
	delete game;
	delete level;
	gf = NULL;
	a = NULL;
	sf = NULL;
	sf2 = NULL;
	tf = NULL;
	game = NULL;
	level = NULL;
}

void TutorManager::run()
{
	if (game 
	&& (game->endOfWalkthrough() || game->getPositionCounter()>lastposition ) ) {
		closeContent();
		return;
	}	

	if (!game) {
		if (tutorshowmode==2) return;

		DOLOG (2, "try to start tutor level");
		gamecounter++;

		vector<LevelHeader*> tutor;
		int demoidx;

		for (int i=0; i<levellist.size(); i++) {
			if (levellist[i]->playersinlevel == numplayer
			 && levellist[i]->hasBackgroundDemo(demoidx) ) {
				int d = levellist[i]->difficulty;
				
				bool usebig = (gamecounter%BIGTUTORLEVELINTERVAL)==0;
				if (tutorshowmode!=0) usebig=false;

				if ( (d==0) != usebig) {
					tutor.push_back(levellist[i]);
				}
			}
		}
		if (tutor.size()<1) return;

		LevelHeader* lh = tutor[randomnumber(tutor.size())];
		lh->hasBackgroundDemo (demoidx);

		level=lh->load();
		if (level) {
			game = new Game (level, computeStepsPerTurn(), demoidx);

			a = new Artwork();
			if (game->level->artwork != "") a->load(game->level->artwork,game->level->movieset,defaultshrinkfactor);
			else					        a->load(defaultartwork,game->level->movieset,defaultshrinkfactor);
			
			gf = new GameFrame (0,0,getScreenWidth(),getScreenHeight(),
				game, -1, a, 0.5, 
				((double) (frameabove->getTop()+frameabove->getBottom())/2)/getScreenHeight()
				);
			gf->moveUnder(frameabove);

			tf = new TextFrame ( 
				getScreenWidth() - (letterwidth*(lh->longname.get()->size()+2))/2 - 10,
				getScreenHeight()-letterheight-40, 
				charstring("(")+*(lh->longname.get())+")",
				lh->getColor() );
			tf->moveUnder(frameabove);

			sf = new StatusFrame1 (getScreenWidth(),getScreenHeight(),
				game, thePanel);
			sf->moveUnder(frameabove);
			if (numplayer>=2) {
				sf2 = new StatusFrame2 (0,getScreenHeight(),
					game, thePanel);
				sf2->moveUnder(frameabove);
			}

			int len = game->getWalkthroughLength();
			if (len<=MAXIMUMTUTORRUN) {
				lastposition = len;
			} else {
				int firstpos = randomnumber(len+MAXIMUMTUTORRUN) - MAXIMUMTUTORRUN;
				if (firstpos<0) firstpos = 0;
				lastposition=firstpos+MAXIMUMTUTORRUN;
				if (lastposition>len) lastposition=len;

				for (int i=0; i<firstpos; i++) {
					game->fastForward();
				}
			}
		}	

		return;
	}

	for (int s=getFrequencyDivide(); s>0; s--) {
		game->microStepForward();
	}
}

void TutorManager::restart()
{
	closeContent();
}

// ------------------- everything for the level list ------------------

LevelHeader* addLevel(const char*t, LevelHeader* notload)
{
	Level* l = new Level;
	// try to load level
	if (!l->load ( charstring(t), false )) { delete l; return NULL; }

	// do not load the startup-level a second time 
	if (notload && (*l->longname.getdefault() == *notload->longname.getdefault()) )
	{ 
		delete l; 
		return NULL; 
	}

	LevelHeader* h = new LevelHeader;
	h->extractLevel (l);
	delete l;

	levellist.push_back (h);
	DOLOG (3, "loaded level: %s", h->longname.getdefault()->data());
	return h;
}


void loadLevelDirectory (char* path, LevelHeader* notload)
{
	findhandle h;
	char txt[1000];
	char *n;

	DOLOG (5,"loading levels from directory: %s", path);
	sprintf (txt, "%s\\*", path);

	n = findfirstfile (&h, txt);
	while (n!=NULL) {
		sprintf (txt, "%s\\%s", path, n);
        DOLOG (5,txt);
//		if (n[0] != '.') {   // only consider files and directories not beginning with '.'
//			if (isdirectory (txt)) {
		if (! stringcontains(n, '.')) {
				loadLevelDirectory (txt, notload);
			} else {
				// only load files with a ".LE?" extension
				int l = strlen(txt);
				if (l>3 && txt[l-4] == '.' 
					&& (txt[l-3] == 'l' || txt[l-3] == 'L')
					&& (txt[l-2] == 'e' || txt[l-2] == 'E') ) {
					addLevel (txt, notload);
				}
//			}
		}
		n = findfile (&h);
	}
    DOLOG (5, "stopping scanning directory");
	stopfindfile (&h);
    DOLOG (5, "stopped scanning directory");
}

void deleteLevelList()
{
	for (int id=0; id<levellist.size(); id++) {
		delete (levellist[id]);
	}
	levellist.clear();
}

LevelHeader* findLevelHeader (const char* name)
{
	for (int i=0; i<levellist.size(); i++) {
		if (*(levellist[i]->longname.getdefault()) == name) return levellist[i];
	}
	return NULL;
}

int findLevelHeaderIndex (LevelHeader* h)
{
	for (int i=0; i<levellist.size(); i++) {
		if (levellist[i] == h) return i;
	}
	return -1;
}

LevelHeader* findNextLevelHeader (LevelHeader* lh)
{
	for (int idx = findLevelHeaderIndex(lh)+1; idx<levellist.size(); idx++) {
		LevelHeader* next = levellist[idx];
		if (next->playersinlevel == lh->playersinlevel) return next;
	}
	return lh;
}

bool levelsortok (LevelHeader* l1, LevelHeader* l2)
{
	if (l1->difficulty < l2->difficulty) return true;
	if (l1->difficulty > l2->difficulty) return false;

	if ( l1->nextlevel == *(l2->longname.getdefault()) ) return true;
	if ( l2->nextlevel == *(l1->longname.getdefault()) ) return false;

	return *(l1->longname.get()) <= *(l2->longname.get());
}

void sortLevels()
{
	int i,j;
	for (i=0; i<levellist.size(); i++) {
		for (j=i+1; j<levellist.size(); j++) {
			if (! levelsortok (levellist[i], levellist[j]) ) {
				LevelHeader* d = levellist[i];
				levellist[i] = levellist[j];
				levellist[j] = d;
			}
		}
	}
}


int computeRanking(int numplayer)
{
	for (int ranking=9; ranking>=2; ranking--) {
		int shouldsolve=0;
		int didsolve=0;
		for (int i=0; i<levellist.size(); i++) {
			LevelHeader* h = levellist[i];

			if (h->playersinlevel != numplayer) continue;
			if (h->difficulty<1 || h->difficulty>9) continue;
			
			if (h->difficulty <= ranking) shouldsolve++;
			if (h->isfinished) didsolve++;
		}

		if (didsolve > shouldsolve*NECESSARYFORRANKING) return ranking;
	}
	return 1;
}


LevelHeader::LevelHeader()
{
	difficulty = 2;
	category = 0;
	playersinlevel = 1;
	isknown = false;
	isfinished = false;
	demoimpossible = false;
}

void LevelHeader::extractLevel (Level* l)
{
	filename = l->getFilename();
	longname = *(l->getLongname());
	difficulty = l->getDifficulty();
	category = l->getCategory();
	playersinlevel = l->differentPlayersInLevel();
	infolines = *(l->getInfoLines());
	authorname = l->getAuthorName();
	firstfinisher = l->getFirstFinisher();
	nextlevel = l->getNextLevel();

	walkthroughnames.clear();
	walkthroughflags.clear();
	for (int i=0; i<l->walkthroughs.size(); i++) {
		Walkthrough* w = &(l->walkthroughs[i]);
		walkthroughnames.push_back (w->name);
		walkthroughflags.push_back (w->flags);
	}
}


Level* LevelHeader::load()
{
	Level* l = new Level();
	if (!l->load (filename)) {
		delete l;
		return NULL;
	}
	return l;
}

bool LevelHeader::hasAllowedDemos()
{
	for (int i=0; i<walkthroughflags.size(); i++) {
		if (mayViewDemo (i)) return true;
	}
	return false;
}

bool LevelHeader::hasBackgroundDemo(int& idx)
{
	for (idx=0; idx<walkthroughflags.size(); idx++) {
		if (mayViewBackgroundDemo (idx)) return true;
	}
	return false;
}

bool LevelHeader::hasSuspendGame()
{
	for (int i=0; i<walkthroughflags.size(); i++) {
		int f = walkthroughflags[i];
		if (f & PLAYBACKFLAG_SUSPENDED) return true;
	}
	return false;

}


bool LevelHeader::hasImpossibleDemo()
{
	return demoimpossible;
}


int LevelHeader::getColor()
{
	if (difficulty>=0 && difficulty<DIFFICULTIES) return color_diff[difficulty];
	return color_neutral;
}

void LevelHeader::setKnown()
{
	if (isknown) return;
	isknown = true;
	saveConfigurationParameter();
}

void LevelHeader::setFinished()
{
	if (isfinished) return;
	isfinished = true;
	saveConfigurationParameter();
}

bool LevelHeader::mayViewDemo (int idx)
{
	if (idx<0 || idx>=walkthroughflags.size()) return false;
	if (walkthroughflags[idx] & PLAYBACKFLAG_SUSPENDED) return false;
	if (walkthroughflags[idx] & PLAYBACKFLAG_SECRETDEMO && !isRegistered() ) return false;

	return true;
}

bool LevelHeader::mayViewBackgroundDemo (int idx)
{
	if (!mayViewDemo(idx)) return false;
	if (walkthroughflags[idx] & PLAYBACKFLAG_BACKGROUNDDEMO) return true;
	if (difficulty==0) return true;
	return false;
}

void LevelHeader::getLevelInfo(vector<charstring> &lines) 
{
	lines.push_back(*(longname.get()) );
	lines.push_back(charstring(""));
	vector<charstring>* v = infolines.getlist();
	for (int i=0; i<v->size(); i++) {
		lines.push_back((*v)[i]);
	}
	lines.push_back( charstring(""));
	lines.push_back( (*getstring(280)) + *getstring(281+category));
	if (authorname!="") {
		lines.push_back((*getstring(84))+authorname );
	}
	if (firstfinisher!="") {
		lines.push_back( (*getstring(89))+firstfinisher);
	}
}



void checkDemos ()
{
	int oldprogress=-1;

	for (int i=0; i<levellist.size(); i++) {
		int progress = (i*100)/levellist.size();
		if (progress != oldprogress) {
			oldprogress = progress;

			char buffer [200];
			sprintf (buffer, "%s (%2d%%)", getstringdata(74), progress);
				
			DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
							*getstring(73), color_menu, color_black);
			d.addTextLine (buffer, color_menu);
			d.moveToFront();
			drawFrames();
		}


		LevelHeader* h = levellist[i];

		Level* l = h->load();
		if (l) {
			h->demoimpossible = ! (l->allDemosOK());
			delete l;
		}
	}
}

// ---------------------- configuration parameter --------------------------

void loadFundamentalConfigurationParameter()
{
	char line[500];
	char *value;
	FILE* f;
	int i;
	int freq;

	// set up default values for all options
	maxxresolution = 1024;
	maxyresolution = 768;
	defaultshrinkfactor = 1;
	defaultfont = 0;
	defaultartwork   = charstring ("default");
	defaultsoundwork = charstring ("standard");

	freq = getScreenFrequency ();
	setDefaultFrequencyDivide ( (freq / 40) >= 1 ? (freq/40) : 1);

	usedtitlemusic = "";
	usedbackgroundmusic = "";
	trailermusic = "";
	for (i=0; i<MAXCATEGORIES; i++) defaultbackgroundmusic[i]="";

	p1control = CONTROLLER_KEY1;
	p2control = CONTROLLER_KEY2;

	// load options from the files 
	for (int fnum=0; fnum<2; fnum++) {
		if (fnum==0) f = fopen ("locale.ini", "r");        // first read default setttings
		if (fnum==1) f = openinifile ("sapphire.ini","r"); // second read user settings
		if (!f) continue;

		while (!feof(f)) {
			fgets (line, 500, f);
			for (i=0; line[i] >= ' ' && line[i] != '='; i++) {
				if (line[i] >= 'A' && line[i] <= 'Z') line[i] += ('a' - 'A');
			}
			if (line[i] == '=') {
				int l;
				value = line+i+1;
				line[i] = '\0';

				l = strlen (value);
				while (l>0 && value[l-1] < ' ') value[--l] = '\0';
	
				if (_stricmp (line, "maxxresolution") == 0) {
					sscanf (value, "%d", &maxxresolution);
				} else if (_stricmp (line, "maxyresolution") == 0) {
					sscanf (value, "%d", &maxyresolution);
				} else if (_stricmp (line, "shrinkfactor") == 0) {
					sscanf (value, "%d", &defaultshrinkfactor);
				} else if (_stricmp (line, "font") == 0) {
					sscanf (value, "%d", &defaultfont);
				} else if (_stricmp (line, "language") == 0) {
					setcurrentlanguage(charstring(value));
				} else if (_stricmp (line, "defaultartwork") == 0) {
					defaultartwork = value;
				} else if (_stricmp (line, "defaultsoundset") == 0) {
					defaultsoundwork = value;
				} else if (_stricmp (line, "frequencydivide") == 0) {
					int div;
					sscanf (value, "%d", &div);
					setDefaultFrequencyDivide(div);
				} else if (strcmp (line, "backgroundmusic") == 0) {
					usedbackgroundmusic = value;
				} else if (strcmp (line, "titlemusic") == 0) {
					usedtitlemusic = value;
				} else if (strcmp (line, "tutorshowmode") == 0) {
					sscanf (value, "%d", &tutorshowmode);
				} else if (strcmp (line, "p1control") == 0) {
					sscanf (value, "%d", &p1control);
				} else if (strcmp (line, "p2control") == 0) {
					sscanf (value, "%d", &p2control);

				} else if (_stricmp(line,"defaultbackgroundmusic0")==0) {
					defaultbackgroundmusic[0] = value;
				} else if (_stricmp(line,"defaultbackgroundmusic1")==0) {
					defaultbackgroundmusic[1] = value;
				} else if (_stricmp(line,"defaultbackgroundmusic2")==0) {
					defaultbackgroundmusic[2] = value;
				} else if (_stricmp(line,"defaultbackgroundmusic3")==0) {
					defaultbackgroundmusic[3] = value;
				} else if (_stricmp(line,"defaultbackgroundmusic4")==0) {
					defaultbackgroundmusic[4] = value;
				} else if (_stricmp(line,"defaultbackgroundmusic5")==0) {
					defaultbackgroundmusic[5] = value;
				} else if (_stricmp(line,"defaultbackgroundmusic6")==0) {
					defaultbackgroundmusic[6] = value;
				} else if (_stricmp(line,"defaultbackgroundmusic7")==0) {
					defaultbackgroundmusic[7] = value;

				} else if (_stricmp(line,"trailermusic")==0) {
					trailermusic = value;
				}
			}
		}
		fclose (f);
	}
}

void loadLevelKnownInfo()
{
	char line[500];
	char *value;
	FILE* f;
	int i;

	additionalknown.clear();
	additionalfinished.clear();

	// load options from the file
	f = openinifile ("sapphire.ini","r");
	if (!f) return;

	while (!feof(f)) {
		fgets (line, 500, f);
		for (i=0; line[i] >= ' ' && line[i] != '='; i++) {
			if (line[i] >= 'A' && line[i] <= 'Z') line[i] += ('a' - 'A');
		}
		if (line[i] == '=') {
			int l;
			value = line+i+1;
			line[i] = '\0';

			l = strlen (value);
			while (l>0 && value[l-1] < ' ') value[--l] = '\0';
	
			if (_stricmp (line, "known") == 0) {
				LevelHeader* lh = findLevelHeader (value);
				if (lh) {
					lh->isknown = true;
				} else {
					additionalknown.push_back(charstring(value));
				}
			} else if (_stricmp (line, "finished") == 0) {
				LevelHeader* lh = findLevelHeader (value);
				if (lh) {
					lh->isfinished = true;
				} else {
					additionalfinished.push_back(charstring(value));
				}
			}
		}
	}

	fclose (f);
}


void saveConfigurationParameter()
{	
	FILE* f = openinifile ("sapphire.ini","w");
	if (!f) return;

	fprintf (f, "maxxresolution=%d\n", maxxresolution);
	fprintf (f, "maxyresolution=%d\n", maxyresolution);
	fprintf (f, "shrinkfactor=%d\n", defaultshrinkfactor);
	fprintf (f, "font=%d\n", defaultfont);
	fprintf (f, "language=%s\n", getcurrentlanguage()->data());

	fprintf (f, "frequencydivide=%d\n", getDefaultFrequencyDivide() );
	fprintf (f, "backgroundmusic=%s\n", usedbackgroundmusic.data() );
	fprintf (f, "titlemusic=%s\n", usedtitlemusic.data());	
	fprintf (f,	"defaultartwork=%s\n", defaultartwork.data());
	fprintf (f, "defaultsoundset=%s\n", defaultsoundwork.data());
	fprintf (f, "tutorshowmode=%d\n", tutorshowmode);

	fprintf (f, "p1control=%d\n", p1control);
	fprintf (f, "p2control=%d\n", p2control);

	for (int i=0; i<levellist.size(); i++) {
		LevelHeader* lh = levellist[i];
		if (lh->isknown) fprintf (f, "known=%s\n", lh->longname.getdefault()->data());
		if (lh->isfinished) fprintf (f, "finished=%s\n", lh->longname.getdefault()->data());
	}

	list<charstring>::iterator cit;
	for (cit=additionalknown.begin(); cit!=additionalknown.end(); cit++) {
		fprintf (f, "known=%s\n", (*cit).data() );
	}
	for (cit=additionalfinished.begin(); cit!=additionalfinished.end(); cit++) {
		fprintf (f, "finished=%s\n", (*cit).data() );
	}

	fclose (f);
}


double computeTimePerStep()
{
	return 1 / getScreenFrequency();
}

int computeStepsPerTurn()
{
    int possible[] = {1,2,3,4,5,6,8,10,12,15,20,24,30,60};
    double f;
    int i;
    int rate,bestrate;
	double tps,besttpsdiff;

    // determine speed of game
	f = 1.0 / computeTimePerStep();

	bestrate = 15;
	besttpsdiff = 1.0e+10;
    for (i=0; i<(sizeof(possible)/sizeof(int)); i++) {
        rate = possible[i];

		tps = f / ((double)rate);
		double tpsdiff = tps - BESTTURNSPERSECOND;
		if (tpsdiff<0) tpsdiff=-tpsdiff;
		if (tpsdiff < besttpsdiff) {
			besttpsdiff = tpsdiff;
			bestrate = rate;
		}
    }
    return bestrate;
}

void startLevelMusic(Level *l)
{
	if (usedbackgroundmusic=="") {
		stopMIDI();
		return;
	}
	
	charstring fname = charstring("songs\\")+l->songname+".mid";

	if (l->songname != "" && fileexists (fname.data()) ) {
		playMIDI (fname, l->songplaystart);
	} else {
		int c = l->category;
		if (c>=0	&&  c<MAXCATEGORIES	&& defaultbackgroundmusic[c]!="") {
			playMIDI (charstring("songs\\")+defaultbackgroundmusic[c]+".mid",0);
		} else {
			playMIDI (charstring("songs\\")+usedbackgroundmusic+".mid",0);
		}
	}
}


void toggleScreenMode (Game* g, GameFrame** gf1, GameFrame** gf2, Artwork* a)
{

	if (g->players.size()<2) return;


	if (*gf2!=NULL) {
		Frame* above=(*gf2)->getFrameAbove();
		
		delete *gf1;
		delete *gf2;
		
		*gf1 = new GameFrame (0,0,getScreenWidth(),getScreenHeight(), 
				g,-1, a);
		(*gf1)->moveUnder(above);

		*gf2 = NULL;
	} else {
		Frame* above=(*gf1)->getFrameAbove();

		delete *gf1;
				
		*gf1 = new GameFrame (
			getScreenWidth()/2+1,0, getScreenWidth()/2-1,getScreenHeight(), 
				g,0, a);
		(*gf1)->moveUnder(above);
		
		*gf2 = new GameFrame (
			0,0,getScreenWidth()/2-1,getScreenHeight(), 
			g,1, a);
		(*gf2)->moveUnder(above);
	}
}

void toggleScreenCenter (Game* g, GameFrame** gf1, GameFrame** gf2)
{
	if (g->players.size()<2) return;
	if (*gf2!=NULL) return;

	switch ((*gf1)->getMainPlayer()) {
	case 0: (*gf1)->setMainPlayer(1); break;
	case 1: (*gf1)->setMainPlayer(-1); break;
	default: (*gf1)->setMainPlayer(0); break;
	}
}


BackgroundContainer::BackgroundContainer (int menu)
{
	Image* i=NULL;
	if (menu) i = theMenuBackground;

	if (!i) {
		frame = new ColorFrame(0,0,
				getScreenWidth(),getScreenHeight(),color_black);
	} else {
		frame = new TileFrame (0,0,
				getScreenWidth(),getScreenHeight(),false, i);
	}
	frame->moveToBack();
}

BackgroundContainer::~BackgroundContainer ()
{
	delete frame;
}



ScrollTextFrame::ScrollTextFrame (int l, int t, int r, int b)
: Frame (l,t,r,b, false)
{
	lowestline = 0;

	buffer = createSurface(getWidth(), getHeight(), color_black);
	setAlwaysDirty();
}

ScrollTextFrame::~ScrollTextFrame()
{
	delete buffer;
	buffer=NULL;
}

void ScrollTextFrame::addLine (charstring& line, int pixelrow, int color)
{
	lowestline++;
	if (lowestline>=getHeight()) lowestline=0;

	if (buffer) {
		SurfacePainter bufferpainter(buffer);

		bufferpainter.fill(color_black, 0,lowestline, 
			 buffer->getWidth(), lowestline+1);

		drawString (&bufferpainter, 0,lowestline-pixelrow, line, line.size(),
				color, false,false, 
				0,lowestline, buffer->getWidth(),lowestline+1);
	}
}

void ScrollTextFrame::update (int currentpage, int x1, int y1, int x2, int y2)
{
	if (buffer) {
		int h1=lowestline+1;
		int h2=buffer->getHeight()-h1;

		theScreen.drawClipped (buffer, 0,h1, 
					left,top,right,top+h2,
					x1,y1,x2,y2, false);

		theScreen.drawClipped (buffer, 0,0, 
					left,top+h2,right,top+h1+h2,
					x1,y1,x2,y2, false);
	}
}



void drawString (Painter* painter,
				int l, int t, const charstring& str, int maxlen,
				int color, bool framed, bool inverted,
				int x1,int y1,int x2, int y2)
{
	enum { BORDERWIDTH=2};

	int dx1=l;
	int dy1=t;
	int dx2=l+maxlen*letterwidth;
	int dy2=t+letterheight;
	int sx=0;
	int sy=0;


	if (inverted) {
		if (maxlen>str.size()) {
			painter->fillClipped (color, dx1+str.size()*letterwidth,dy1,dx2,dy2,  x1,y1,x2,y2);
		}
	}

	if (clip (sx,sy, dx1,dy1,dx2,dy2, x1,y1,x2,y2)) {

		if (inverted) theFont->activateAlternativeTransparent();
		
		for (int i=0; i<maxlen && i<str.size(); i++) {
			drawLetter (painter, l+letterwidth*i, t, str.at(i), color, x1,y1,x2,y2);
		}

		if (inverted) theFont->activateStandardTransparent();
	}

	if (framed) {
		painter->drawBorder (color, dx1 /* -BORDERWIDTH */ , dy1-BORDERWIDTH,
			dx2+BORDERWIDTH, dy2+BORDERWIDTH, BORDERWIDTH,
			x1,y1,x2,y2);
	}
}

void drawLetter (Painter* painter,
				int l, int t, char letter, int color, 
				int x1, int y1, int x2, int y2)
{
	if ( ((unsigned char)letter)>=1*16 && ((unsigned char)letter)<16*16) {
		int dx1=l; 
		int dy1=t;
		int dx2=l+letterwidth;
		int dy2=t+letterheight;
		int sx=( ((unsigned char) letter) %16) * letterwidth;
		int sy=(( ((unsigned char) letter) /16)-1) * letterheight;

		if (clip (sx,sy, dx1,dy1,dx2,dy2, x1,y1,x2,y2) ) {
			painter->fill (color, dx1,dy1,dx2,dy2);
			painter->draw (theFont, sx,sy, dx1,dy1,dx2,dy2, true);
		}
	}
}


void setActiveFont (int fontidx)
{
	if (allFonts[fontidx]==NULL) fontidx=0;

	theFont = allFonts[fontidx];
	letterwidth = theFont->getWidth()/16;
	letterheight = theFont->getHeight()/15;
}


void showTrailer()
{
	// do quick check, if all necessary resources are still available
	if (!screenIsOpen()) return;
	if (!theFont) return;

	// create background frame
	ColorFrame bw (0,0, getScreenWidth(), getScreenHeight(), color_black);
	bw.moveToBack();
	// create scrolltext frame
	ScrollTextFrame stf (getScreenWidth()/2-320, 0, 
			getScreenWidth()/2+320, getScreenHeight() );

	// read the text from the file
	vector<charstring> text;
	char fname[100];
	sprintf (fname, "c%s.txt", getcurrentlanguage()->data());
	FILE* txtfile = fopen (fname, "r");
	if (txtfile) {
		char txtbuffer[200];
		while (fgets(txtbuffer,200,txtfile)) {
			text.push_back(charstring(txtbuffer));
		}
		fclose (txtfile);
	}

	// variables we need for text scrolling
	int col=findColor(255,255,255);
	int nextline=0;
	int nextpixelrow=0;
	int enddelay=SCROLLTEXTENDDELAY;
	enum { scrollcounterunit=60 };
	int possiblespeeds[] = { 120,90,60,30,20,15 };
	int scrollcounter=0;
	int scrollspeed=60;

	// compute best speed to use for scrolling
	double bestdiff=999999;
	for (int i=0; i<sizeof(possiblespeeds)/sizeof(int); i++) {
		double speed = ( ((double) possiblespeeds[i]) / scrollcounterunit) * getScreenFrequency();
		double diff = speed - BESTTEXTSCROLLSPEED;
		if (diff<0) diff=-diff;
		if (diff<bestdiff) {
			bestdiff=diff;
			scrollspeed = possiblespeeds[i];
		}
	}

	// start music for trailer
	if (usedtitlemusic!="") {
		playMIDI(charstring("songs\\")+trailermusic+".mid",0);
	}

	// loop for text output
	charstring thisline = "";
	nextpixelrow = letterwidth-1;
	while (enddelay>0) {
		int event;
		if (getCommandEvent (event)) {
			if (event == COMMAND_YES
			|| event == COMMAND_NO
			|| event == COMMAND_ESCAPE) break;
		}

		gameTick();

		for (int i=getFrequencyDivide(); i>0; i--) {

			// do the microcounter manipulation
			scrollcounter+=scrollspeed;
			while (scrollcounter>=scrollcounterunit) {
				scrollcounter -= scrollcounterunit;

				// scroll one pixel line
				if (nextline>=text.size()) {
					enddelay--;
				} else {

					stf.addLine (thisline, (nextpixelrow>0) ? nextpixelrow : 0, col);
					nextpixelrow++;

					if (nextpixelrow>=letterheight) {
						nextpixelrow=0;

						while (nextline<text.size()) {
							thisline = text[nextline];
							nextline++;

							if (thisline.at(0)=='<') {
								if (thisline.at(1)=='c') {
									int r=255;
									int g=255;
									int b=255;
									sscanf (thisline.data()+2,"%d %d %d",&r,&g,&b);
									col = findColor(r,g,b);
									continue;
								}
								if (thisline.at(1)=='f') {
									int fidx=0;
									sscanf (thisline.data()+2,"%d", &fidx);
									if (fidx>=0 && fidx<=1) setActiveFont(fidx);
									continue;
								}
								if (thisline.at(1)=='d') {
									sscanf (thisline.data()+2, "%d", &enddelay);
									continue;
								}
								if (thisline.at(1)=='p') {
									int percent=0;
									int minuslines=0;
									sscanf (thisline.data()+2, "%d %d", &percent,&minuslines);
									nextpixelrow = -( (getScreenHeight()*percent)/100 - 
													  minuslines*letterheight ); 
									if (nextpixelrow>0) nextpixelrow=0;
									thisline = "";
									break;
								}
							}
							break;
						}
					}
				}
			}
		}
	}
}


InputHandler* createInputHandler(int player)
{
	int control = (player==0) ? p1control : p2control;
	return new KeyboardInputHandler(control);
}


void fillScreen(int col)
{
	ColorFrame cf(0,0,getScreenWidth(),getScreenHeight(),col);
	gameTick();
}

Image* loadArtworkImage (char* file, charstring* artwork)
{
	char fname[200];
	Image *i;

	if (artwork==NULL) artwork = &defaultartwork;

	sprintf (fname, "art\\%s.zip#%s.bmp", artwork->data(), file);
	if (i=loadImage (charstring(fname), 1) ) return i;

	sprintf (fname, "art\\%s\\%s.bmp", artwork->data(), file);
	if (i=loadImage (charstring(fname), 1) ) return i;

	sprintf (fname, "art\\default.zip#%s.bmp", file);
	if (i=loadImage (charstring(fname), 1) ) return i;

	sprintf (fname, "art\\default\\%s.bmp", file);
	if (i=loadImage (charstring(fname), 1) ) return i;
	
	return NULL;
}
