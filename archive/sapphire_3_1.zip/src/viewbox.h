#ifndef _VIEWBOX_H
#define _VIEWBOX_H

// ============== everything for displaying graphical contents ==============

#define DIRECTDRAW_VERSION 0x0300
#include <ddraw.h>
#include "types.h"

// global viewbox functions
bool initViewBox (HWND hwnd);
void closeViewBox ();
bool reloadViewBox ();

// ------------ functions that directly concern the screen ------------------

typedef int twoint[2]; 
int getPossibleScreenModes(twoint* modes, int buffersize);

bool openScreen (int bestwidth, int bestheight, int minimumwidth, int minimumheight);
void closeScreen();
bool screenIsOpen();
bool loadPalette (charstring& filename);
int findColor (int r, int g, int b);

void printScreen(charstring& filename);

void invalidateArea(int l, int t, int r, int b);
void invalidateScreen();
double drawFrames();

int getDefaultFrequencyDivide();
void setDefaultFrequencyDivide(int dfd);
void resetFrequencyDivide();
int getFrequencyDivide();
int getScreenWidth();
int getScreenHeight();
double getScreenFrequency();
double getCPUUsage();

class Frame* findFrameAtPosition(int x, int y, Frame* notconsider=NULL);


// ----------------- object declarations ----------------------------------

class PaintSource {
public:
	int width;
	int height;
	int transparentcolor;
	LPDIRECTDRAWSURFACE lpDDS;
	bool forcesystemmemory;

public:
	PaintSource();
	virtual ~PaintSource();
	
	bool buildBuffer ();
	bool isBufferLost();

	int getWidth() { return width; };
	int getHeight() { return height; };
	int getTransparentColor () { return transparentcolor; }

	void activateStandardTransparent();
};

class Surface : public PaintSource {
public:
	bool isdestroyed;

public:
	Surface(int w,int h, int transparent);
	virtual ~Surface();
};

class Image : public PaintSource {
public:
	charstring filename;
	int  shrinkfactor;
	int alternativetransparentcolor;

public:
	Image(charstring& fname, int shrink, bool forcesysmem);
	virtual ~Image();

	unsigned char extractPixelBits (unsigned char* readbuffer,int bits,int sourcex);
	void extractFileBits (unsigned char* surfacedata, int width,
				 			 unsigned char* readbuffer, int bits, int shrinkfactor,
							 unsigned char* mapping);
	bool reload();
	int getAlternativeTransparentColor () { return alternativetransparentcolor; };
	void activateAlternativeTransparent();
};


class Painter {
public:
	Painter();
	virtual ~Painter();

	virtual void draw (PaintSource* ps, int sourcex, int sourcey, int destx1, int desty1,
					  int destx2, int desty2, bool transparent=false) = 0;
	virtual void fill (int color, int dx1, int dy1, int dx2, int dy2) = 0;

	void drawClipped (PaintSource* ps, int sourcex, int sourcey, int destx1, int desty1,
					  int destx2, int desty2, 
					  int x1, int y1, int x2, int y2, bool transparent=false);
	void drawTile (PaintSource* ps, int x1,int y1,int x2,int y2);
	void drawTileClipped (PaintSource* ps, int dx1, int dy1, int dx2, int dy2, int x1,int y1,int x2,int y2);

	void fillClipped (int color, int dx1, int dy1, int dx2, int dy2, int x1, int y1, int x2, int y2);
	void drawBorder (int color, int dx1, int dy1, int dx2, int dy2, int thickness, int x1, int y1, int x2, int y2);
};

class ScreenPainter : public Painter {
public:
	ScreenPainter();
	virtual ~ScreenPainter();

	virtual void draw (PaintSource* ps, int sourcex, int sourcey, int destx1, int desty1,
					  int destx2, int desty2, bool transparent=false);
	virtual void fill (int color, int dx1, int dy1, int dx2, int dy2);
};

class SurfacePainter : public Painter {
protected:
	Surface* surface;

public:
	SurfacePainter (Surface* s);
	virtual ~SurfacePainter();

	virtual void draw (PaintSource* ps, int sourcex, int sourcey, int destx1, int desty1,
					  int destx2, int desty2, bool transparent=false);
	virtual void fill (int color, int dx1, int dy1, int dx2, int dy2);
};


struct rectangle {
	int left;
	int top;
	int right;
	int bottom;
};

class RectangleList {
public:
	enum { MAXRECT = 100 };
	int maxleft,maxtop,maxright,maxbottom;

	int rectnum;
	struct rectangle rect[MAXRECT];

	RectangleList ();
	~RectangleList ();

	void subtractRect (int l, int t, int r, int b);
	void subtract (RectangleList& list);
	void init ();
	void init (int l, int t, int r, int b);
	void init (RectangleList& list);
	void init (RectangleList& l1, int l, int t, int r, int b);  // copy with clipping
};


class Frame {
public:
	int left;
	int top;
	int right;
	int bottom;
	bool transparency;

	RectangleList valid[2];

	int dirty;
	bool alwaysdirty;

	// temporary for screen drawing
	RectangleList visible;


	Frame (int l, int t, int r, int b, bool transp);
	virtual ~Frame ();

	void invalidateLower (int currentpage, list<Frame*>::reverse_iterator& revit,
		int l, int t, int r, int b);
	void invalidateHigher (int currentpage, list<Frame*>::iterator& it,
		int l, int t, int r, int b);

	virtual void computeChanges (int currentpage, list<Frame*>::reverse_iterator& revit);
	virtual void drawChanges (int currentpage, list<Frame*>::iterator& it);
	virtual void updateInvalid (int currentpage, list<Frame*>::iterator& it, RectangleList& invalid);

	virtual void call();

	void setDirty();
	void setAlwaysDirty();
	virtual void update (int currentpage, int l, int t, int r, int b);
	
	void resize(int _left, int _top, int _right, int _bottom);
	void moveOffset(int dx, int dy);
	void moveToFront();
	void moveToBack();
	void moveUnder(Frame* other);
	Frame* getFrameAbove();

	int getTop() { return top; };
	int getLeft() { return left; };
	int getRight() { return right; };
	int getBottom() { return bottom; };
	int getWidth() { return right-left; };
	int getHeight() { return bottom-top; }
};

// -------------------- object factory functions -------------------------

Image*   loadImage (charstring& filename, int shrinkfactor=1, bool forcesystemmemory=false);
Surface* createSurface(int w, int h, int transparentcolor);


// ------------------------- support functions -----------------------

bool clip (int& sx, int& sy, int& dx1,int& dy1,int& dx2,int& dy2,int x1,int y1,int x2,int y2);
bool clip (int& dx1,int& dy1,int& dx2,int& dy2,int x1,int y1,int x2,int y2);
bool clip (int& dx1,int& dy1,int& dx2,int& dy2, Frame *f);

// --------------- exported global variables ---------------------------

extern ScreenPainter theScreen;



#endif

