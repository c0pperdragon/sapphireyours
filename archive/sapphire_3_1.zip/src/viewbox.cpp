
#include "framework.h"
#include "viewbox.h"
#include "toolbox.h"
#include "dataread.h"


// global viewbox variables (windows dependent)
static LPDIRECTDRAW lpDD = NULL;
static HWND viewBoxMasterWindow = NULL;

// global variables concerning the screen
LPDIRECTDRAWSURFACE lpDDSPrimary = NULL;
LPDIRECTDRAWSURFACE lpDDSBack = NULL;
LPDIRECTDRAWSURFACE lpDDSDrawTarget;
LPDIRECTDRAWPALETTE lpDDPalette = NULL;

PALETTEENTRY palette[256];

double screenfrequency;
int scanlines;

int screenwidth;
int screenheight;

int currentpage;
int defaultfrequencydivide;
int frequencydivide;
int numberofunderloads;
int numberofoverloads;
double cpuusage;

// global variables for object management
std::list<Frame*>  allframes;
list<Image*>       allimages;
list<Surface*>     allsurfaces;

ScreenPainter theScreen;

// heuristic values for the automatic frequency adaptor
#define SLOWDOWNDELAY 2
#define SPEEDUPDELAY  30


// ----------------- global init and closedown functions ----------------------

bool initViewBox (HWND hwnd)
{
	viewBoxMasterWindow = hwnd;

	doLog (1, "opening DirectDraw");
	lpDD = NULL;
    if ( FAILED( DirectDrawCreate( NULL, &lpDD, NULL ) ) )
	{
        doLog (0, "Could not open the DirectDraw library.");
		return false;
    }
	doLog (2, "DirectDraw successfully opened");

	return true;
}

void closeViewBox ()
{
	doLog (1, "close down DirectDraw");
	if (lpDD) {
		lpDD->Release();
		lpDD=NULL;
	}
}

bool reloadViewBox ()
{
	lpDDSPrimary->Restore();
	invalidateScreen();

	for (list<Image*>::iterator it = allimages.begin(); it!=allimages.end(); it++) {
		Image* i = *it;
		if (i->isBufferLost()) {
			if (!i->reload()) return false;
		}
	}

	for (list<Surface*>::iterator sit = allsurfaces.begin(); 
    sit!=allsurfaces.end(); sit++) {
		Surface* s = *sit;
		if (s->isBufferLost()) {
			if (!s->buildBuffer()) return false;
			s->isdestroyed = true;
		}
	}

	return true;
}


// ------------------------ screen mode query --------------------------------

static int possiblescreenmodesnum;
static int maximumscreenmodesnum;

long WINAPI enumDisplayModes (LPDDSURFACEDESC desc, LPVOID lpContext)
{
	// find suitable available screen resolution
	if (possiblescreenmodesnum>=maximumscreenmodesnum) return DDENUMRET_OK;
	// we need a 8-bit - Screen
	if (desc->ddpfPixelFormat.dwRGBBitCount != 8) return DDENUMRET_OK;

	twoint *s = (twoint*) lpContext;
	s[possiblescreenmodesnum][0] = desc->dwWidth;
	s[possiblescreenmodesnum][1] = desc->dwHeight;
	possiblescreenmodesnum++;
		
	return DDENUMRET_OK;
}

static void sortDisplayModes(twoint *s)
{
	BOOL keepgoing;
	do {
		keepgoing = FALSE;
		for (int i=0; i<possiblescreenmodesnum-1; i++) {
			if ( s[i][0]<s[i+1][0] 
			  || (s[i][0]==s[i+1][0]  && s[i][1]<s[i+1][1]) ) {
				int dummy = s[i][0];
				s[i][0] = s[i+1][0];
				s[i+1][0] = dummy;
				dummy = s[i][1];
				s[i][1] = s[i+1][1];
				s[i+1][1] = dummy;
				keepgoing=TRUE;
			}
		}
	} while (keepgoing);

	for (int i=0; i<possiblescreenmodesnum; i++) {
		doLog (2, "found display mode: %dx%dx8", s[i][0], s[i][1]);
	}
}

int getPossibleScreenModes(twoint* modes, int buffersize)
{
	HRESULT hr;

	if (!lpDD) return 0;

	// enumerate and sort screen modes (in descending order)
	doLog (2, "enumerating screen modes");
	possiblescreenmodesnum = 0;
	maximumscreenmodesnum = buffersize;
	if ( FAILED( hr=lpDD->EnumDisplayModes (0, NULL, (void*) modes, enumDisplayModes ) )) {
		doLog (0,"Could not enumerate screen modes (0x%X)",hr);
		return 0;
	}
	doLog (3, "sorting display modes");
	sortDisplayModes(modes);

	return possiblescreenmodesnum;
}


// ----------------- all screen functions ------------------------------

bool openScreen (int bestwidth, int bestheight, int minimumwidth, int minimumheight)
{
	HRESULT hr;
	enum {MAXMODES=500};
	int possiblesize[MAXMODES][2];
	int possiblemodesnum;

	// check for all asserts
	if (!lpDD) return false;
	if (allframes.size()!=0) { 
		doLog(0, "frames existing upon screen open"); 
		return false; 
	}
	if (allimages.size()!=0) { 
		doLog(0, "images existing upon screen open"); 
		return false; 
	}
	if (allsurfaces.size()!=0) { 
		doLog(0, "surfaces existing upon screen open"); 
		return false; 
	}

    // Get exclusive mode.
	doLog (1, "try to set exclusive mode");
    if ( FAILED( hr = lpDD->SetCooperativeLevel( viewBoxMasterWindow, 
		DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN ) ) )
	{
		doLog (0, "Could not set exclusive mode in DirectDraw (0x%X)",hr);
		return false;
    }
	doLog (2, "successfully set exclusive mode");

	// enumerate and sort screen modes (in descending order)
	possiblemodesnum = getPossibleScreenModes (possiblesize,MAXMODES);

	doLog (3, "try to alloc a screen");
	// try to alloc a screen (do it in a loop to check all possibilities)
	for (int i=0; i<possiblemodesnum; i++) {
		int width = possiblesize[i][0];
		int height = possiblesize[i][1];

		// only use a screen mode that suits our requirements
		if (width<minimumwidth || width>bestwidth
		 || height<minimumheight || height>bestheight)  continue;

		// try to set a screen mode
		doLog (2, "try screen mode: %dx%dx%d", width,height,8);
		if ( FAILED( hr=lpDD->SetDisplayMode(width, height, 8) ) )  {
			doLog (1, "could not set this screen mode (0x%X)",hr);
			continue;
		}

		// Create the primary surface with 1 back buffer
		DDSURFACEDESC       ddsd;
	    ddsd.dwSize = sizeof( ddsd );
		ddsd.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | 
			                    DDSCAPS_FLIP | 
				                DDSCAPS_COMPLEX /* |
					            DDSCAPS_VIDEOMEMORY */ ;
		ddsd.dwBackBufferCount = 1;

		doLog (2, "try to alloc a primary buffer with attached back buffer");
		if (FAILED( hr = lpDD->CreateSurface(&ddsd, &lpDDSPrimary, NULL ) ) ) {
			doLog (1, "could not create primary buffer (0x%X)",hr);
			continue;
		}

	    // Get a pointer to the back buffer.
	    DDSCAPS ddscaps;
		ddscaps.dwCaps = DDSCAPS_BACKBUFFER;
	    if ( FAILED( hr = lpDDSPrimary->GetAttachedSurface(&ddscaps, &lpDDSBack ) ) )
		{
			doLog (1, "We could not find the back buffer (0x%X)",hr);
			lpDDSPrimary->Release();
			continue;
		}
	
		// success! - we now have a surface
		doLog (1, "screen %dx%dx%d successfully opened", width, height, 8);

		// clear color palette
		for (int i=0; i<256; i++) {
			palette[i].peRed   = 0;
			palette[i].peGreen = 0;
			palette[i].peBlue  = 0;
			palette[i].peFlags = 0;
		}

		// determine monitor frequency
		DWORD freq=0;
		if ( FAILED ( lpDD->GetMonitorFrequency (&freq) ) ) freq=0;

		if (freq>=30 && freq<=300) {
			screenfrequency = freq;
		} else {
			doLog (2, "could not determine frequency directly. try to measure");
			for (int j=0; j<2; j++) {
				lpDDSDrawTarget = lpDDSPrimary;
				theScreen.fill(0, 0,0,width,height);
				lpDDSPrimary->Flip(NULL, DDFLIP_WAIT);
			}
			lpDDSPrimary->Flip(NULL, DDFLIP_WAIT);
			lpDDSPrimary->Flip(NULL, DDFLIP_WAIT);
			getTimer();
			for (int i=0; i<10; i++) {
				lpDDSPrimary->Flip(NULL, DDFLIP_WAIT);
			}
			screenfrequency = 10.0 / getTimer();
		}
		doLog (2, "monitor frequency: %f", screenfrequency);
	
		// determine number of scanlines in the screen (including vertical blanking)
		scanlines = 0;
		DWORD sc=0;
		do {
			if (FAILED(lpDD->GetScanLine(&sc))) break;
			if (sc>scanlines) scanlines=sc;
		} while (sc>=scanlines);


		// initialize all necessary global variables
		screenwidth = width;
		screenheight = height;
		currentpage = 0;
		defaultfrequencydivide = 1;
		frequencydivide = 1;
		numberofunderloads = 0;
		numberofoverloads = 0;
	
		cpuusage = 0.0;
		getTimer();
		
		return true;
	}

	doLog (0, "Could not open a DirectDraw screen");
	return NULL;
}

void closeScreen()
{
	if (lpDDSPrimary) {
		lpDDSPrimary->Release();
		lpDDSPrimary = NULL;
		lpDDSBack = NULL;
	}
	if (lpDDPalette) {
		lpDDPalette->Release();
		lpDDPalette=NULL;
	}
}

bool screenIsOpen()
{
	return lpDDSPrimary != NULL;
}

bool loadPalette (charstring& filename)
{
	FILE* f;
	char dummy[100];
	struct filergbvalue {
		unsigned char b;
		unsigned char g;
		unsigned char r;
		unsigned char reserved;
	} filergbvalues[256];
	LPDIRECTDRAWPALETTE lpDDPalette = NULL;

	// check if screen is opened
	if (!lpDDSPrimary) return false;

	// remove any existing palette
	if (lpDDPalette) {
		lpDDPalette->Release();
		lpDDPalette=NULL;
	}

	// read the stuff in bmp-format
	doLog (3, "reading palette from file: %s", filename.data());
	f = fopen (filename.data(), "rb");
	if (!f) {
		doLog (0, "can not open palette file: %s", filename.data());
		return false;
	}
	fread (dummy, 1,54, f);
	fread (filergbvalues, 4,256,f);
	fclose (f);

	// convert to DirectDraw palette entries
	for (int i=0; i<256; i++) {
		palette[i].peRed   = filergbvalues[i].r;
		palette[i].peGreen = filergbvalues[i].g;
		palette[i].peBlue  = filergbvalues[i].b;
		palette[i].peFlags = 0;
	}

	// now create a DirectDraw palette object
	if ( FAILED (lpDD->CreatePalette 
			(DDPCAPS_8BIT | DDPCAPS_ALLOW256, palette, &lpDDPalette, NULL) )) {
		doLog (0, "Could not create a DirectDraw palette");
		return false;
	}

	// set palette for the screen
	lpDDSPrimary->SetPalette (lpDDPalette);

	return true;
}

#define ABS(x)  ((x)>0 ? (x) : -(x))
int findColor (int r, int g, int b)
{
	int c;
	int col=0;
	int mindiff=1<<14;

	for (c=0; c<256; c++) {
		int diff = ABS (r - palette[c].peRed)
			 + ABS (g - palette[c].peGreen)
			 + ABS (b - palette[c].peBlue);
		if (diff<mindiff) {
			mindiff = diff;
			col=c;
		}
	}
	return col;
}


void printScreen(charstring& filename)
{
	int x,y,i,c;
	byte dummy[1000];

	if (!lpDDSPrimary) return;

	doLog (2, "screenshot to file: %s", filename.data());
	FILE* out = fopen(filename.data(), "wb");
	if (!out) return;

	// compute some sizes
	int imagebytes=0;
	for (y=screenheight-1; y>=0; y--) {
		for (x=0;x<screenwidth;x++) {
			imagebytes++;
		}
		while ( (x%4) != 0) { 
			imagebytes++; 
			x++; 
		}
	}
	int offset = 54+256*4;
	int filesize = imagebytes + 54 + 256*4;
	int biinfosize = 40;
	int planes = 1;
	int bits = 8;
	int pixpermeter = 4000;
	int compression=0;

	for (i=0; i<1000;i++) dummy[i]=0;

	fwrite ("BM", 1,2, out);
	fwrite (&filesize, 4,1, out);
	fwrite (dummy, 1,4, out);
	fwrite (&offset, 4,1,out);

	fwrite (&biinfosize, 4,1,out);
	fwrite (&screenwidth, 4,1, out);
	fwrite (&screenheight, 4,1, out);
	fwrite (&planes, 2,1,out);
	fwrite (&bits, 1,2, out);
	fwrite (&compression, 1,4, out);
	fwrite (&imagebytes, 4,1, out);
	fwrite (&pixpermeter, 4,1, out);
	fwrite (&pixpermeter, 4,1, out);
	fwrite (dummy, 8,1, out);

	// write palette to file
	for (c=0; c < 256; c++) {
		fwrite (&(palette[c].peBlue), 1,1, out);
		fwrite (&(palette[c].peGreen), 1,1, out);
		fwrite (&(palette[c].peRed), 1,1, out);
		fwrite (dummy, 1,1, out);
	}

	// write image data to file
	DDSURFACEDESC ddsd;
	ddsd.dwSize = sizeof(ddsd);

	if (SUCCEEDED (lpDDSPrimary->Lock(NULL, &ddsd, 
		DDLOCK_WAIT | DDLOCK_READONLY, NULL))) {

		int pitch = ddsd.lPitch;
		unsigned char* mem = ((unsigned char*) ddsd.lpSurface) + pitch * (screenheight-1);

		for (y=screenheight-1; y>=0; y--) {
			for (x=0;x<screenwidth;x++) {
				fwrite (&(mem[x]), 1,1, out);
			}
			while ( (x%4) != 0) { 
				fwrite (dummy, 1,1,out); 
				x++; 
			}
			mem -= pitch;
		}
		
		lpDDSPrimary->Unlock (NULL);
	}

	// close file after operation
	fclose(out);
}


void invalidateArea(int l, int t, int r, int b)
{
	for (list<Frame*>::iterator it=allframes.begin(); it!=allframes.end(); it++) {
		Frame* f = *it;
		f->valid[0].subtractRect(l,t,r,b);
		f->valid[1].subtractRect(l,t,r,b);
	}
}

void invalidateScreen()
{	
	invalidateArea(0,0,screenwidth,screenheight);
}


double drawFrames () 
{	
	// determine new speed of display 
	if (defaultfrequencydivide > frequencydivide) {
		frequencydivide = defaultfrequencydivide;
	}
	if (cpuusage > 0.95*frequencydivide) {
		numberofoverloads++;
		numberofunderloads=0;
		if (numberofoverloads >= SLOWDOWNDELAY) {
			frequencydivide++;
		}
	} else if (frequencydivide>defaultfrequencydivide 
		&& cpuusage < 0.95*(frequencydivide-1) ) {
		numberofoverloads=0;
		numberofunderloads++;
		if (numberofunderloads >= SPEEDUPDELAY/frequencydivide
		&& frequencydivide > 1) {
			frequencydivide--;
		}
	} else {
		numberofoverloads=0;
		numberofunderloads=0;
	}

	bool superfast = (frequencydivide==1 && defaultfrequencydivide==0);

	// do time measurement
	double beforewait = getTimer();

	// wait for begin of screen
	if (superfast) {

		// strange mode  (doing flip before draw)
		lpDDSDrawTarget = lpDDSPrimary;

		// immediately set up the follow up screen pointer
		lpDDSPrimary->Flip(NULL, DDFLIP_WAIT );

	} else {

		// normal mode (doing flip after draw)
		lpDDSDrawTarget = lpDDSBack;
		
		while (FAILED(lpDDSBack->GetBltStatus(DDGBS_CANBLT))); 
	}
	double whilewait = getTimer();


	// ------------------ draw all frames in the screen ---------------------
	list<Frame*>::iterator fi;

	// compute visible area of every frame
	for (fi = allframes.begin(); fi!=allframes.end(); fi++) {
		Frame* f = *fi;

		int x1=f->left;
		int y1=f->top;
		int x2=f->right;
		int y2=f->bottom;
		if (! clip(x1,y1,x2,y2, 0,0,screenwidth,screenheight) ) {
			f->visible.init();
			f->valid[currentpage].init();
		} else {
			f->visible.init(x1,y1,x2,y2);
		}

		list<Frame*>::iterator otherit = fi; 
		otherit++;
		for (; otherit!=allframes.end(); otherit++) {
			Frame* other = *otherit;
			if (!other->transparency) {

				f->visible.subtractRect (other->left,other->top,
						other->right, other->bottom);

				f->valid[currentpage].subtractRect (other->left,other->top,
						other->right, other->bottom);
			}
		}
	}

	// do down-propagation of all changes in transparent frames
	for (list<Frame*>::reverse_iterator revit=allframes.rbegin();
			revit!=allframes.rend(); revit++) {
		Frame* f = *revit;
		if (f->transparency) {
			f->computeChanges (currentpage, revit);
		}
	}

	// do bottom-up order drawing
	for (fi=allframes.begin(); fi!=allframes.end(); fi++) {
		Frame* f = *fi;

		// draw the changes that occur in each frame itself
		f->drawChanges(currentpage, fi);

		// update destroyed areas of the frame
		RectangleList invalidvisible;
		invalidvisible.init (f->visible);
		invalidvisible.subtract (f->valid[currentpage]);

		f -> updateInvalid (currentpage, fi, invalidvisible);

		// remember the new visible areas
		f -> valid[currentpage].init (f->visible);
	}

	// ---------------------- end of drawing ------------------------------


	// do time measurement and synchronisation with nth frame
	double whiledraw = getTimer();

	// do addition waiting for slower refresh rate
	if (!superfast) {
		if (frequencydivide>1) {
			double minimumwait = ( ((double) frequencydivide) - 0.3) / screenfrequency;
			// if we were too fast, we just sleep the necessary time
			if (whiledraw < minimumwait) {
				Sleep ( (DWORD) ((minimumwait - whiledraw ) * 1000) );
			}
		}

		lpDDSPrimary->Flip(NULL, DDFLIP_WAIT );
	}

	// do time measurement for additional wait
	double whilewait2 = getTimer();

	// compute cpu usage
	cpuusage = ((beforewait + whiledraw ) * screenfrequency );

	// keep track of page that is currently in front 
	currentpage = 1 - currentpage;

	// give the elapsed time back to the caller
	return beforewait+whilewait+whiledraw+whilewait2;
}



int getDefaultFrequencyDivide()
{
	return defaultfrequencydivide;
}

void setDefaultFrequencyDivide(int dfd)
{
	defaultfrequencydivide = dfd;
	resetFrequencyDivide();
}

void resetFrequencyDivide()
{
	frequencydivide=defaultfrequencydivide;
	numberofunderloads=0;
	numberofoverloads=0;
}

int getFrequencyDivide()
{
	return (frequencydivide>=1) ? frequencydivide : 1;
}

int getScreenWidth()
{ 
	return screenwidth; 
}
int getScreenHeight()
{ 
	return screenheight;
}
double getScreenFrequency()
{ 
	return screenfrequency;
}
double getCPUUsage()
{
	return cpuusage;
};

class Frame* findFrameAtPosition(int x, int y, Frame* notconsider)
{
	for (list<Frame*>::reverse_iterator it=allframes.rbegin(); it!=allframes.rend(); it++) {
		Frame* f = *it;
		if (f==notconsider) continue;
		if (f->left<=x && f->top<=y && f->right>x && f->bottom>y) return f;
	}
	return NULL;
}


// -------------- member functions: PaintSource -------------------

PaintSource::PaintSource()
{
	lpDDS = NULL;
	width = 0;
	height = 0;
	transparentcolor = 0;
	forcesystemmemory = false;
}

PaintSource::~PaintSource()
{
	if (lpDDS) {
		lpDDS->Release();
		lpDDS=NULL;
	}
}

bool PaintSource::buildBuffer ()
{
	DDSURFACEDESC ddsd;

	// delete any previously opened surface
	if (lpDDS) {
		lpDDS->Release();
		lpDDS = NULL;
	}

	// create new surface
	ddsd.dwSize = sizeof(ddsd);
	ddsd.dwFlags = DDSD_CAPS | DDSD_HEIGHT | DDSD_WIDTH | DDSD_CKSRCBLT;
	ddsd.dwWidth = width;
	ddsd.dwHeight = height;
	ddsd.ddckCKSrcBlt.dwColorSpaceLowValue = transparentcolor;
	ddsd.ddckCKSrcBlt.dwColorSpaceHighValue = transparentcolor;

	if (! forcesystemmemory) {
		// try to create a surface in video memory first
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN 
			| DDSCAPS_VIDEOMEMORY | DDSCAPS_SYSTEMMEMORY;
		lpDD->CreateSurface (&ddsd, &lpDDS, NULL);
	}

	if (!lpDDS) {
		// creating a surface in video memory failed
		// so try it for system memory
		ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_SYSTEMMEMORY;
		if (FAILED(lpDD->CreateSurface (&ddsd, &lpDDS, NULL))) {
			doLog (1, "could not create surface for image");
			return false;
		}
	}

	// clear surface with standard transparent color
	RECT	dest;
	DDBLTFX fx;
    dest.left = 0;
    dest.top = 0;     
    dest.right = width;
    dest.bottom = height;
	fx.dwSize = sizeof(fx);
	fx.dwFillColor = transparentcolor;

	lpDDS->Blt(&dest, NULL, NULL, 
		DDBLT_COLORFILL | DDBLT_WAIT, &fx);


	activateStandardTransparent();
	return true;
}

bool PaintSource::isBufferLost()
{
	if ( FAILED( lpDDS->IsLost() )) return true;
	return false;
}

void PaintSource::activateStandardTransparent()
{
	if (!lpDDS) return;
	DDCOLORKEY colkey;
	colkey.dwColorSpaceHighValue = transparentcolor;
	colkey.dwColorSpaceLowValue = transparentcolor;
	lpDDS->SetColorKey (DDCKEY_SRCBLT, &colkey);
}

// -------------- member functions: Surface -----------------------

Surface::Surface(int w,int h, int transparent)
{
	width = w;
	height = h;
	transparentcolor = transparent;

	isdestroyed = false;

	allsurfaces.push_back(this);
}

Surface::~Surface()
{
	allsurfaces.remove(this);
}

// -------------- member functions: Image -------------------------

Image::Image(charstring& fname, int shrink, bool forcesysmem)
{
	filename = fname;
	shrinkfactor = shrink;
	alternativetransparentcolor = 0;
	forcesystemmemory = forcesysmem;

	allimages.push_back(this);
}	

Image::~Image () 
{
	allimages.remove (this);
}


unsigned char Image::extractPixelBits (unsigned char* readbuffer,int bits,int sourcex)
{
	int bitpos = sourcex*bits;
	unsigned char b = readbuffer[bitpos/8];

	switch (bits) {
	case 1: return (b >> (7 - ( bitpos % 8))) & 1;
	case 4: return (b >> (4 - ( bitpos % 8))) & 15;
	case 8: return b;
	default: return 0;
	}
}

void Image::extractFileBits (unsigned char* surfacedata,int width,
				 			 unsigned char* readbuffer,int bits,int shrinkfactor,
							 unsigned char* mapping)
{
	 // fastest possible shortcut
	if (bits==8 && shrinkfactor==1) { 
		for (int x=0; x<width; x++) surfacedata[x] = mapping[readbuffer[x]];
		return;
	}
	// complicated algorithm for different packaging formats
	int sx=0;
	for (int x=0; x<width; x++) {
		surfacedata[x] = mapping[extractPixelBits (readbuffer,bits,sx)];
		sx += shrinkfactor;
	}
}

bool Image::reload () 
{
	doLog (2, "try to load image %s from file", filename.data());
	// release previously loaded image (if any exists)
	if (lpDDS) {
		lpDDS->Release();
		lpDDS = NULL;
	}

	DataReader* f;
	unsigned char mapping[256];
	int bits,compression;
	int c,y,bfoffbits,colorused;
	int bmpwidth,bmpheight;

	// open file to load
	f = openDataReader (filename);
	if (!f) {
		doLog (3,"can not open file: %s", filename.data());
		return false;
	}

	// read header
	f->skipBytes(10);
	bfoffbits = f->readInt32();

	// bitmapinfoheader
	f->readInt32();
	bmpwidth = f->readInt32();
	bmpheight = f->readInt32();
	f->readInt16();
	bits = f->readInt16();
	compression = f->readInt32();
	f->readInt32();
	f->readInt32();
	f->readInt32();
	colorused = f->readInt32();
	f->readInt32();

	// compute width and height according to the shrink factor
	width = (bmpwidth+shrinkfactor-1) / shrinkfactor;    // divide with rounding up
	height = (bmpheight+shrinkfactor-1) / shrinkfactor;

	// check, if we can handle the format
	if ( (bits!=1 && bits!=4 && bits!=8) ) {
		doLog (1, "invalid color depth");
		delete f;
		return false;
	}
	if ( compression != 0) {
		doLog (1, "invalid compression");
		delete f;
		return false;
	}
	if (colorused==0) colorused = 1 << bits;

	// read the palette and compute a mapping
	for (c=0; c < colorused; c++) {
		struct filergbvalue {
			unsigned char b;
			unsigned char g;
			unsigned char r;
			unsigned char reserved;
		} v;
		f->readBytes ((unsigned char*)&v, 4);
		mapping[c] = findColor (v.r, v.g, v.b);
	}

	// create the buffer for the surface
	if (!buildBuffer()) {
		doLog (1, "could not allocate surface");
		delete f;
		return false;
	}

	// try to lock the surface for direct manipulation
	DDSURFACEDESC ddsd;
	ddsd.dwSize = sizeof(ddsd);
	if (FAILED(lpDDS->Lock(NULL, &ddsd, DDLOCK_WAIT, NULL))) {
		delete f;
		return false;
	}
	unsigned char* data = (unsigned char*) ddsd.lpSurface;
	int pitch = ddsd.lPitch;

	// read the bitmap data
	unsigned char readbuffer[2000]; // I hope we get no bigger bitmaps than this
	int bytesread = ((bmpwidth*bits + 31) / 32) * 4;  // read with 32bit - padding
	for (y=bmpheight-1; y>=0; y--) {
		f->readBytes (readbuffer,bytesread);

		if ( (y%shrinkfactor)==0) {
			extractFileBits (data+(y/shrinkfactor)*pitch,width,
				 			 readbuffer,bits,shrinkfactor, mapping);
		}
		if (y==0) transparentcolor			  = mapping[extractPixelBits (readbuffer,bits,bmpwidth-1)];
		if (y==1) alternativetransparentcolor = mapping[extractPixelBits (readbuffer,bits,bmpwidth-1)];
	}

	// release the lock on the surface and activate standard transparent color
	lpDDS->Unlock (NULL);
	activateStandardTransparent();

	// close file after reading everything
	delete f;

	return true;
}

void Image::activateAlternativeTransparent()
{
	if (!lpDDS) return;
	DDCOLORKEY colkey;
	colkey.dwColorSpaceHighValue = alternativetransparentcolor;
	colkey.dwColorSpaceLowValue = alternativetransparentcolor;
	lpDDS->SetColorKey (DDCKEY_SRCBLT, &colkey);
}



// ---------------- member functions: Painter ----------------------------

Painter::Painter()
{
}

Painter::~Painter()
{
}

void Painter::drawClipped (PaintSource* ps, int sourcex, int sourcey, int destx1, int desty1,
					  int destx2, int desty2, 
					  int x1, int y1, int x2, int y2, bool transparent /* = false */)
{
	if (clip (sourcex, sourcey, destx1,desty1,destx2,desty2, x1,y1,x2,y2)) {
		draw (ps, sourcex,sourcey, destx1,desty1,destx2,desty2, transparent);
	}
}

void Painter::drawTile (PaintSource* ps, int x1,int y1,int x2,int y2)
{
	int w=ps->getWidth();
	int h=ps->getHeight();

	for (int x=(x1/w)*w; x<x2; x+=w) {
		for (int y=(y1/h)*h; y<y2; y+=h) {
			drawClipped (ps, 0,0, x,y,x+w,y+h,  x1,y1,x2,y2);
		}
	}
}

void Painter::drawTileClipped (PaintSource* ps, int dx1, int dy1, int dx2, int dy2, int x1,int y1,int x2,int y2)
{
	if (clip(dx1,dy1,dx2,dy2, x1,y1,x2,y2)) {
		drawTile (ps, dx1,dy1,dx2,dy2);
	}
}

void Painter::fillClipped (int color, int dx1, int dy1, int dx2, int dy2, int x1, int y1, int x2, int y2)
{
	if (clip (dx1,dy1,dx2,dy2, x1,y1,x2,y2)) {
		fill (color, dx1,dy1,dx2,dy2);
	}
}

void Painter::drawBorder (int color, int dx1, int dy1, int dx2, int dy2, int thickness, int x1, int y1, int x2, int y2)
{
	fillClipped (color, dx1,dy1, dx2,dy1+thickness,   x1,y1,x2,y2);
	fillClipped (color, dx1,dy2-thickness, dx2,dy2,   x1,y1,x2,y2);
	fillClipped (color, dx1,dy1+thickness, dx1+thickness,dy2-thickness,  x1,y1,x2,y2);
	fillClipped (color, dx2-thickness,dy1+thickness,dx2,dy2-thickness,   x1,y1,x2,y2);
}


// ---------------- member functions: ScreenPainter -------------------

ScreenPainter::ScreenPainter()
{
}

ScreenPainter::~ScreenPainter()
{
}

void ScreenPainter::draw (PaintSource* ps, int sourcex, int sourcey, 
					  int destx1, int desty1,
					  int destx2, int desty2, bool transparent /* = false */ )
{
	RECT	source;
	source.left = sourcex;
	source.top =  sourcey;
	source.right = sourcex + (destx2-destx1);
	source.bottom = sourcey + (desty2-desty1);

	lpDDSDrawTarget->BltFast(destx1, desty1,
		ps->lpDDS, &source, 
		transparent ? (DDBLTFAST_SRCCOLORKEY| DDBLTFAST_WAIT) : DDBLTFAST_WAIT);
}

void ScreenPainter::fill (int color, int x1, int y1, int x2, int y2)
{
	RECT	dest;
	DDBLTFX fx;

    dest.left = x1;   
    dest.top = y1;     
    dest.right = x2;
    dest.bottom = y2;

	fx.dwSize = sizeof(fx);
	fx.dwFillColor = color;

	lpDDSDrawTarget->Blt(&dest, NULL, NULL, 
		DDBLT_COLORFILL | DDBLT_WAIT, &fx);
}


// ---------------- member functions: SurfacePainter ------------------------

SurfacePainter::SurfacePainter(Surface* s)
{
	surface = s;
}

SurfacePainter::~SurfacePainter()
{
}

void SurfacePainter::draw (PaintSource* ps, int sourcex,int sourcey, 
					   int destx1,int desty1, int destx2, int desty2, bool transparent)
{
	RECT	source;
	
	source.left = sourcex;
	source.top =  sourcey;
	source.right = sourcex + (destx2-destx1);
	source.bottom = sourcey + (desty2-desty1);

	if (FAILED( surface->lpDDS->BltFast(destx1, desty1,
		ps->lpDDS, &source, 
		transparent ? (DDBLTFAST_SRCCOLORKEY| DDBLTFAST_WAIT) : DDBLTFAST_WAIT)
	)) {
		RECT    dest;
		dest.left = destx1;
		dest.top = desty1;
		dest.right = destx2;
		dest.bottom = desty2;
	
		surface->lpDDS->Blt(&dest,ps->lpDDS,&source,
		transparent ? (DDBLT_WAIT | DDBLT_KEYSRC) : DDBLT_WAIT, 
		NULL);
	}
}

void SurfacePainter::fill (int color, int dx1, int dy1, int dx2, int dy2)
{
	RECT	dest;
	DDBLTFX fx;

    dest.left = dx1;
    dest.top = dy1;     
    dest.right = dx2;
    dest.bottom = dy2;

	fx.dwSize = sizeof(fx);
	fx.dwFillColor = color;

	surface->lpDDS->Blt(&dest, NULL, NULL, 
		DDBLT_COLORFILL | DDBLT_WAIT, &fx);
}

// ----------------- member functions: RectangleList ------------------

RectangleList::RectangleList ()
{
	init();
}

RectangleList::~RectangleList () 
{
}

#define ADDRECTANGLE(l,t,r,b) { \
	if (!didoverwrite) { \
		rect[current].left = l; \
		rect[current].top = t; \
		rect[current].right = r; \
		rect[current].bottom = b; \
		didoverwrite=true; \
	} else { \
		if (rectnum<MAXRECT) { \
			rect[rectnum].left = l; \
			rect[rectnum].top = t; \
			rect[rectnum].right = r; \
			rect[rectnum].bottom = b; \
			rectnum++; \
		} else { \
			doLog (1, "Out of slots in rectangle list calculation"); \
		} \
	} \
}

void RectangleList::subtractRect (int l, int t, int r, int b)
{
	// do fast check, if the other rectangle is total outside the maximum areas
	if (r<=maxleft || b<=maxtop || l>=maxright || t>=maxbottom) return;

	int oldnum = rectnum;
	int current = 0;

	// go through all rectangles that did already exist 
	while (current < oldnum) {
		int ol = rect[current].left;
		int ot = rect[current].top;
		int or = rect[current].right;
		int ob = rect[current].bottom;

		// check, if this rectangle is somehow affected
		if (b<=ot || t>=ob || r<=ol || l>=or) {
			current++;   // not affected, so skip unchanged
			continue;
		}

		// now add the necessary parts of the old rectangle to the list
		bool didoverwrite=false;
		if (t > ot) ADDRECTANGLE (ol,ot,or,t);
		if (b < ob) ADDRECTANGLE (ol,b,or,ob);
		if (l > ol) ADDRECTANGLE (ol,(t>ot)?t:ot,l,(b<ob)?b:ob);
		if (r < or) ADDRECTANGLE (r,(t>ot)?t:ot,or,(b<ob)?b:ob);

		if (didoverwrite) {  // if we had at least one remaining rectangle, the old
			current++;       // slot has been filled
		} else {
			// nothing as been filled into the old slot, so we must transfer another 
			// rectangle to this position (and shorten the list)
			if (rectnum > oldnum) {  // if we can use one of the freshly created rects
				rect[current] = rect[rectnum-1];
				rectnum--;
				current++;  // continue with next rectangle
			} else { // if no freshly created rectangles are in the list
				rect[current] = rect[rectnum-1];
				rectnum--;
				oldnum--;  // do not continue with the next, since we did not process this one
			}
		}
	}
}

void RectangleList::subtract (RectangleList& other)
{
	for (int r=0; r<other.rectnum; r++) {
		subtractRect (other.rect[r].left, other.rect[r].top, 
					  other.rect[r].right, other.rect[r].bottom);
	}
}


void RectangleList::init ()
{
	maxleft=maxtop=maxright=maxbottom=0;
	rectnum=0;
}

void RectangleList::init (int l, int t, int r, int b)
{
	rectnum=1;
	rect[0].left	= maxleft = l;
	rect[0].top		= maxtop = t;
	rect[0].right	= maxright = r;
	rect[0].bottom	= maxbottom = b;
}

void RectangleList::init (RectangleList& other)
{
	maxleft = other.maxleft;
	maxtop = other.maxtop;
	maxright = other.maxright;
	maxbottom = other.maxbottom;
	rectnum=other.rectnum;
	for (int r=0; r<other.rectnum; r++) {
		rect[r].left = other.rect[r].left;
		rect[r].top = other.rect[r].top;
		rect[r].right = other.rect[r].right;
		rect[r].bottom = other.rect[r].bottom;
	}
}

void RectangleList::init (RectangleList& l1, int l, int t, int r, int b)
{
	maxleft		= l;
	maxtop		= t;
	maxright	= r;
	maxbottom	= b;
	int i2=0;
	for (int i1=0; i1<l1.rectnum; i1++) {
		rect[i2].left	= l1.rect[i1].left;
		rect[i2].top	= l1.rect[i1].top;
		rect[i2].right	= l1.rect[i1].right;
		rect[i2].bottom	= l1.rect[i1].bottom;
		if (clip(rect[i2].left,rect[i2].top,rect[i2].right,rect[i2].bottom, l,t,r,b) ) {
			i2++;
		}
	}
	rectnum=i2;
}



// --------------- member functions: Frame ---------------------------

Frame::Frame (int l, int t, int r, int b, bool transp)
{
	left = l;
	top = t;
	right = r;
	bottom = b;
	transparency = transp;

	valid[0].init();
	valid[1].init();

	dirty=0;
	alwaysdirty=false;

	invalidateArea (left,top,right,bottom);
	allframes.push_back(this);
}

Frame::~Frame () 
{
	allframes.remove(this);
	invalidateArea (left,top,right,bottom);
}

void Frame::invalidateLower (int currentpage, list<Frame*>::reverse_iterator& revit,
	int l, int t, int r, int b)
{
	list<Frame*>::reverse_iterator it2=revit;
	it2++;
	for (;it2!=allframes.rend();it2++) {
		(*it2)->valid[currentpage].subtractRect(l,t,r,b);
	}
}

void Frame::invalidateHigher (int currentpage, list<Frame*>::iterator& it,
	int l, int t, int r, int b)
{
	list<Frame*>::iterator it2=it;
	it2++;
	for (;it2!=allframes.end();it2++) {
		(*it2)->valid[currentpage].subtractRect(l,t,r,b);
	}
}

void Frame::computeChanges (int currentpage, list<Frame*>::reverse_iterator& revit)
{
	if (alwaysdirty || dirty>0) {
		RectangleList* rl = &valid[currentpage];
		for (int r=0; r<rl->rectnum; r++) {
			invalidateLower (currentpage, revit, 
				rl->rect[r].left,rl->rect[r].top,rl->rect[r].right,rl->rect[r].bottom);
		}
	}
}

void Frame::drawChanges (int currentpage, list<Frame*>::iterator& it)
{
	if (alwaysdirty || dirty>0) {
		RectangleList* rl = &valid[currentpage];
		for (int r=0; r<rl->rectnum; r++) {
			update (currentpage, rl->rect[r].left,rl->rect[r].top,rl->rect[r].right,rl->rect[r].bottom);

			invalidateHigher (currentpage, it, 
				rl->rect[r].left,rl->rect[r].top,rl->rect[r].right,rl->rect[r].bottom);
		}
		
		if (!alwaysdirty) dirty--;
	}
}

void Frame::updateInvalid (int currentpage, list<Frame*>::iterator& it, RectangleList& invalid)
{
	for (int r=0; r<invalid.rectnum; r++) {
		update (currentpage, invalid.rect[r].left, invalid.rect[r].top,
							 invalid.rect[r].right, invalid.rect[r].bottom);
		
		invalidateHigher (currentpage, it, invalid.rect[r].left, invalid.rect[r].top,
									invalid.rect[r].right, invalid.rect[r].bottom);
	}
}

void Frame::call()
{
}

void Frame::setDirty()
{
	dirty=2;
}

void Frame::setAlwaysDirty()
{
	alwaysdirty=true;
}

void Frame::update (int currentpage, int l, int t, int r, int b)
{
	static int col=0;
	theScreen.fill(col, l,t,r,b);
	col++; if (col>255) col=0;
}

void Frame::resize(int _left, int _top, int _right, int _bottom)
{
	invalidateArea(left,top,right,bottom);

	left = _left;
	top = _top;
	right = _right;
	bottom = _bottom;

	invalidateArea(left,top,right,bottom);
}

void Frame::moveOffset(int dx, int dy)
{
	resize (left+dx,top+dy,right+dx,bottom+dy);
}

void Frame::moveToFront()
{
	allframes.remove (this);
	allframes.push_back (this);
}

void Frame::moveToBack()
{
	allframes.remove(this);
	allframes.push_front(this);
}

void Frame::moveUnder(Frame* other)
{
	allframes.remove(this);
	for (list<Frame*>::iterator it=allframes.begin(); it!=allframes.end(); it++) {
		if (*it == other) {
			allframes.insert(it, this);
			return;
		}
	}
	allframes.push_back(this);
}

Frame* Frame::getFrameAbove()
{
	Frame* above=NULL;
	for (list<Frame*>::reverse_iterator it=allframes.rbegin(); it!=allframes.rend(); it++) {
		if (*it == this) return above;
		above = *it;
	}
	return NULL;
}

// ----------------- global object factories ---------------------------

Image* loadImage (charstring& filename, int shrinkfactor, bool forcesystemmemory)
{
	doLog (2, "load image: %s, shrink by %d", filename.data(), shrinkfactor);
	Image* img = new Image (filename, shrinkfactor, forcesystemmemory);
	if (! img->reload () ) {
		doLog (2, "could not open image: %s", filename.data());
		delete img;
		return NULL;
	}

	doLog (4, "image successfully loaded");
	return img;
}

Surface* createSurface(int w, int h, int transparentcolor)
{
	doLog (2, "create surface: %d*%d", w,h);
	Surface* s = new Surface(w,h,transparentcolor);
	if (!s->buildBuffer()) {
		doLog (1, "could not create surface: %d*%d",w,h);
		delete s;
		return NULL;
	}
	return s;
}

// -------------------- support functions -----------------------------

bool clip (int& sx, int& sy, int& dx1,int& dy1,int& dx2,int& dy2,int x1,int y1,int x2,int y2)
{
	if (dx1<x1) { sx += x1-dx1; dx1=x1; }
	if (dy1<y1) { sy += y1-dy1; dy1=y1; }
	if (dx2>x2) { dx2 = x2; }
	if (dy2>y2) { dy2 = y2; }
	return dx2>dx1 && dy2>dy1;
}

bool clip (int& dx1,int& dy1,int& dx2,int& dy2,int x1,int y1,int x2,int y2)
{
	if (dx1<x1) { dx1=x1; }
	if (dy1<y1) { dy1=y1; }
	if (dx2>x2) { dx2 = x2; }
	if (dy2>y2) { dy2 = y2; }
	return dx2>dx1 && dy2>dy1;
}

bool clip (int& dx1,int& dy1,int& dx2,int& dy2, Frame* f)
{
	if (dx1<f->left) dx1=f->left;
	if (dy1<f->top) dy1=f->top;
	if (dx2>f->right) dx2=f->right;
	if (dy2>f->bottom) dy2=f->bottom;
	return dx2>dx1 && dy2>dy1;
}

