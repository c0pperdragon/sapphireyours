#include "editor.h"
#include "viewextension.h"
#include "gamemain.h"
#include "toolbox.h"

#define MAXNAMESIZE     30
#define MAXINFOTEXTSIZE 35
#define MAXIMUMBORDER 2

#define ACTION_OPTIONS		(-10)
#define ACTION_SAVE			(-11)
#define ACTION_DISCARD		(-12)
#define ACTION_KEEPGOING    (-13)
#define ACTION_APPLY        (-14)
#define ACTION_DIFFICULTY   (-15)
#define ACTION_INFO 		(-16)
#define ACTION_SONG         (-17)
#define ACTION_LANGUAGE     (-18)
#define ACTION_MOVE         (-19)
#define ACTION_ADDBORDER    (-20)

void inttostring(charstring& str, int value)
{
	char line[20];
	sprintf (line,"%d", value);
	str = line;
}

int stringtoint(charstring& str, int minvalue, int maxvalue, int defaultvalue)
{
	int value;
	if (sscanf (str.data(), "%d", &value) != 1) {
		return defaultvalue;
	}
	if (value<minvalue) value=minvalue;
	if (value>maxvalue) value=maxvalue;
	return value;
}

void stripBlankLines(vector<charstring>& lines)
{
	while (lines.size()>0 && lines[lines.size()-1] == "") {
		lines.resize(lines.size()-1);
	}
}

bool insertLineBreak(vector<charstring>& lines, int line, int column)
{
	if (line<0 || line>=lines.size()) return false;
	if (column<0 || column>lines[line].size()) return false;
	
	int lnum=lines.size();
	lines.resize(lnum+1);
	for (int i=lnum-1; i>=line; i--) lines[i+1] = lines[i];
	lines[line].resize(column);
	lines[line+1].erase(0,column);
	return true;
}

bool removeLineBreak(vector<charstring>& lines, int line, int& prevlinelength)
{
	if (line<=0 || line>=lines.size()) return false;

	prevlinelength = lines[line-1].size();
	lines[line-1] += lines[line];

	int lnum=lines.size();
	for (int i=line; i<lnum-1; i++) lines[i]=lines[i+1];
	lines.resize(lnum-1);

	return true;
}

void editLevelOptions(Level* level)
{
	charstring widthstr;
	charstring heightstr;
	charstring emeraldsneededstr;
	charstring emeraldsdestructablestr;
	charstring availabletimestr;
	charstring availablemovesstr;
	charstring swampratestr;
	charstring pushprobstr;
	charstring dispenserspeedstr;
	charstring elevatorspeedstr;
	charstring wheelturntimestr;
	charstring robotspeedstr;
	charstring yamyamnumstr;
	int silentyamyamint;
	int silentlaserint;

	// initialize dialog items
	inttostring (widthstr, level->width-2);
	inttostring (heightstr, level->height-2);
	inttostring (emeraldsneededstr, level->emeraldsneeded);
	if (level->emeraldsdestructable>=0) {
		inttostring(emeraldsdestructablestr,level->emeraldsdestructable);
	} else {
		emeraldsdestructablestr = "";
	}
	if (level->availabletime>=0) {
		inttostring(availabletimestr,level->availabletime);
	} else {
		availabletimestr = "";
	}
	if (level->availablemoves>=0) {
		inttostring(availablemovesstr,level->availablemoves);
	} else {
		availablemovesstr = "";
	}
	inttostring (swampratestr, level->swamprate);
	inttostring (pushprobstr, level->pushprob);
	inttostring (dispenserspeedstr, level->dispenserspeed);
	inttostring (elevatorspeedstr, level->elevatorspeed);
	inttostring (wheelturntimestr, level->wheelturntime);
	inttostring (robotspeedstr, level->robotspeed);
	inttostring (yamyamnumstr, level->yamyaminfo.size());
	silentyamyamint = level->silentyamyam ? 1 : 0;
	silentlaserint = level->silentlaser ? 1 : 0;

	// do dialog
	for (;;) {
		int col = color_diff[level->difficulty];

		DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
			*getstring(200), col, color_black);

		d.addEditLine(*getstring(201),col, ACTION_KEEPGOING, &widthstr, 3);
		d.addEditLine(*getstring(202),col, ACTION_KEEPGOING, &heightstr, 3);
		d.addBlankLine();
		d.addEditLine(*getstring(203), col, ACTION_KEEPGOING, &emeraldsneededstr, 5);
		d.addEditLine(*getstring(204), col, ACTION_KEEPGOING, &emeraldsdestructablestr, 5);
		d.addEditLine(*getstring(205), col, ACTION_KEEPGOING, &availabletimestr, 5);
		d.addEditLine(*getstring(217), col, ACTION_KEEPGOING, &availablemovesstr, 5);
		d.addEditLine(*getstring(206), col, ACTION_KEEPGOING, &swampratestr, 5);
		d.addEditLine(*getstring(207), col, ACTION_KEEPGOING, &pushprobstr, 5);
		d.addEditLine(*getstring(208), col, ACTION_KEEPGOING, &dispenserspeedstr, 5);
		d.addEditLine(*getstring(216), col, ACTION_KEEPGOING, &elevatorspeedstr, 5);
		d.addEditLine(*getstring(209), col, ACTION_KEEPGOING, &wheelturntimestr, 5);
		d.addEditLine(*getstring(210), col, ACTION_KEEPGOING, &robotspeedstr, 5);
		d.addEditLine(*getstring(211), col, ACTION_KEEPGOING, &yamyamnumstr, 5);
		d.addSelectionLine (*getstring(212), col, &silentyamyamint);
		d.addSelectionOption (*getstring(213));
		d.addSelectionOption (*getstring(214));
		d.addSelectionLine (*getstring(215), col, &silentlaserint);
		d.addSelectionOption (*getstring(213));
		d.addSelectionOption (*getstring(214));
		d.addBlankLine();
		d.addActionLine (*getstring(62),col, ACTION_APPLY);
		d.addActionLine (*getstring(60),col, ACTION_CANCEL);

		int	act = d.doModal();
		switch (act) {
		case ACTION_APPLY:
			// read all values from the dialog items
			level->width = stringtoint(widthstr, 1,maxlevelwidth-2, level->width-2) + 2;
			level->height = stringtoint(heightstr, 1,maxlevelheight-2, level->height-2) + 2;
			level->emeraldsneeded = stringtoint(emeraldsneededstr, 0,99999, level->countEmeralds());
			level->emeraldsdestructable = stringtoint(emeraldsdestructablestr, 0,99999, -1);
			level->availabletime = stringtoint(availabletimestr, 0,99999,-1);
			level->availablemoves = stringtoint(availablemovesstr, 0,99999,-1);
			level->swamprate = stringtoint(swampratestr, 0,99999, DEFAULTSWAMPRATE);
			level->pushprob = stringtoint(pushprobstr, 0,99999, DEFAULTPUSHPROB);
			level->dispenserspeed = stringtoint(dispenserspeedstr, 0,99999, DEFAULTDISPENSERSPEED);
			level->elevatorspeed = stringtoint(elevatorspeedstr, 0,99999, DEFAULTELEVATORSPEED);
			level->wheelturntime = stringtoint(wheelturntimestr, 0,99999, DEFAULTWHEELTURNTIME);
			level->robotspeed = stringtoint(robotspeedstr, 0,99999, DEFAULTROBOTSPEED);
			level->yamyaminfo.resize(stringtoint(yamyamnumstr, 0,maxyamyamnum, 0));
			level->silentyamyam = silentyamyamint!=0;
			level->silentlaser = silentlaserint!=0;

			return;


		case ACTION_CANCEL:
			return;
		}
	}
}


bool editLevelInfo(Level* level)
{
	bool newart;
	int i;
	charstring* strptr;
	int firstselect=0;
	int firstselectcolumn=9999;

	int difficultyint;
	int categoryint;
	vector<charstring> artworklist;
	int artworkidx;
	vector<charstring> moviesetlist;
	int moviesetidx;
	vector<charstring> soundworklist;
	int soundworkidx;
	charstring songnamestr;
	int songplaystart;
	charstring nextlevelstr;
	charstring authornamestr;
	charstring firstfinisherstr;

	vector<charstring> languagelist;
	int languageidx;
	charstring longnamestr;
	mlangstring longname;
	vector<charstring> infolinesstr;
	mlangstringlist infolines;

	// determine available languages
	languageidx = getavailablelanguages(languagelist);

	// init dialog items
	difficultyint = level->difficulty;
	categoryint = level->category;
	// determine available artworks
	readsubdirectorylist(artworklist, "art\\");
	artworkidx = artworklist.size();
	for (int aidx=0; aidx<artworklist.size(); aidx++) {
		if (_stricmp (artworklist[aidx].data(), level->artwork.data()) == 0) {
			artworkidx = aidx;
		}
	}
	// determine available movie sets
	readsubdirectorylist(moviesetlist, "movie\\");
	moviesetidx = moviesetlist.size();
	for (int midx=0; midx<moviesetlist.size(); midx++) {
		if (_stricmp (moviesetlist[midx].data(), level->movieset.data()) == 0) {
			moviesetidx = midx;
		}
	}
	// determine available soundworks
	readsubdirectorylist(soundworklist, "sound\\");
	soundworkidx = soundworklist.size();
	for (int sidx=0; sidx<soundworklist.size(); sidx++) {
		if (_stricmp (soundworklist[sidx].data(), level->soundwork.data()) == 0) {
			soundworkidx = sidx;
		}
	}
	songnamestr = level->songname;
	songplaystart = level->songplaystart;
	nextlevelstr = level->nextlevel;
	authornamestr = level->authorname;
	firstfinisherstr = level->firstfinisher;

	longname.copy(level->longname);
	infolines.copy(level->infolines);

	// do dialog
	for (;;) {
		strptr = longname.get(languagelist[languageidx]);
		longnamestr = strptr ? *strptr : "";
		vector<charstring>* strlinesptr = infolines.getlist(languagelist[languageidx] );
		if (strlinesptr) infolinesstr = *strlinesptr;
		else {
			infolinesstr.clear();
		}
		if (infolinesstr.size()==0) infolinesstr.push_back(charstring(""));

		int col = color_diff[difficultyint];

		DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
			*getstring(220), col, color_black);

		charstring langcap = languagelist[languageidx];
		doCapitalize(langcap);
		d.addActionLine(*getstring(221)+langcap,col,ACTION_LANGUAGE);

		d.addEditLine(*getstring(222),col,ACTION_KEEPGOING,&longnamestr,MAXNAMESIZE);
		for (vector<charstring>::iterator it=infolinesstr.begin(); it!=infolinesstr.end();it++) {
			d.addEditLine(*getstring(223),col,ACTION_KEEPGOING,&(*it),MAXINFOTEXTSIZE);
		}
		d.addBlankLine();
		d.addActionLine(*getstring(224)+getstringdata(10+difficultyint), col, ACTION_DIFFICULTY);

		d.addSelectionLine(*getstring(233), col, &categoryint);
		for (i=0; i<MAXCATEGORIES; i++) d.addSelectionOption(*getstring(281+i));

		d.addSelectionLine (*getstring(225), col, &artworkidx);
		for (i=0; i<artworklist.size();i++) {
			charstring s = artworklist[i];
			doCapitalize(s);
			d.addSelectionOption(s);
		}
		d.addSelectionOption(*getstring(226));

		d.addSelectionLine (*getstring(234), col, &moviesetidx);
		for (i=0; i<moviesetlist.size();i++) {
			charstring s = moviesetlist[i];
			doCapitalize(s);
			d.addSelectionOption(s);
		}
		d.addSelectionOption(*getstring(226));

		d.addSelectionLine (*getstring(227), col, &soundworkidx);
		for (i=0; i<soundworklist.size();i++) {
			charstring s = soundworklist[i];
			doCapitalize(s);
			d.addSelectionOption(s);
		}
		d.addSelectionOption(*getstring(226));

		d.addActionLine(*getstring(228)+
			(songnamestr=="" ? *getstring(226) : songnamestr), col, ACTION_SONG);
		d.addEditLine (*getstring(229),col,ACTION_KEEPGOING,&nextlevelstr,
			MAXNAMESIZE);
		d.addEditLine (*getstring(230),col,ACTION_KEEPGOING,&authornamestr,
			MAXNAMESIZE);
		d.addEditLine (*getstring(231),col,ACTION_KEEPGOING,&firstfinisherstr,
			MAXNAMESIZE);
		d.addBlankLine();
		d.addActionLine (*getstring(62),col, ACTION_APPLY);
		d.addActionLine (*getstring(60),col, ACTION_CANCEL);


		int	act = d.doModal(firstselect,firstselectcolumn,true);
		firstselect=0;
		firstselectcolumn=9999;

		switch (act) {
		case ACTION_APPLY:
			newart = false;

			// read all values from the dialog items
			level->difficulty = difficultyint;
			level->category = categoryint;

			{
				charstring old = level->artwork;
				if (artworkidx < artworklist.size()) {
					level->artwork = artworklist[artworkidx];
				} else {
					level->artwork = "";
				}
				if (old != level->artwork) newart=true;

				old = level->movieset;
				if (moviesetidx < moviesetlist.size()) {
					level->movieset = moviesetlist[moviesetidx];
				} else {
					level->movieset = "";
				}
				if (old != level->movieset) newart=true;
			}

			if (soundworkidx < soundworklist.size()) {
				level->soundwork = soundworklist[soundworkidx];
			} else {
				level->soundwork = "";
			}
			level->songname = songnamestr;
			level->songplaystart = songplaystart;
			level->nextlevel = nextlevelstr;
			level->authorname = authornamestr;
			level->firstfinisher = firstfinisherstr;

			longname.setstring(languagelist[languageidx],longnamestr);
			stripBlankLines(infolinesstr);
			infolines.setlist(languagelist[languageidx],infolinesstr);
			level->longname.copy (longname);
			level->infolines.copy (infolines);

			return newart;

		case ACTION_DIFFICULTY:
			difficultyint++;
			if (difficultyint>=DIFFICULTIES) difficultyint=0;

			firstselect = 5+infolinesstr.size();
			goto storeinfo;

		case ACTION_SONG:
			selectmusic (getstringdata(232), songnamestr);
			songplaystart = 0;
			goto storeinfo;

		case ACTION_KEEPGOING:
		storeinfo:
			{	int line;
				int column;
				if (d.getEnterKeyPosition(line,column)) {
					if (insertLineBreak(infolinesstr, line-4,column)) {
						firstselect=line+1;
						firstselectcolumn=0;
					}
				} else if (d.getBackspacePosition(line,column)) {
					if (removeLineBreak(infolinesstr,line-4,  firstselectcolumn)) {
						firstselect=line-1;
					} else {
						firstselect=line;
						firstselectcolumn=column;
					}
				} 
			}

		case ACTION_LANGUAGE:
			longname.setstring(languagelist[languageidx],longnamestr);
			infolines.setlist(languagelist[languageidx],infolinesstr);

			if (act == ACTION_LANGUAGE) {
				languageidx++;
				if (languageidx>=languagelist.size()) languageidx=0;
			}
			break;

		case ACTION_CANCEL:
			return false;
		}
	}
}

static void moveLevelContents(Level* level)
{
	charstring rightstr="";
	charstring downstr="";

	if (level->height<=2 || level->width<=2) return;

	int col = color_neutral;
	DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
		*getstring(250), col, color_black);

	d.addEditLine(*getstring(251),col,ACTION_APPLY,&rightstr,4);
	d.addEditLine(*getstring(252),col,ACTION_APPLY,&downstr,4);
	d.addBlankLine();
	d.addActionLine (*getstring(62),col, ACTION_APPLY);
	d.addActionLine (*getstring(60),col, ACTION_CANCEL);

	if (d.doModal()==ACTION_APPLY) {
		int right = stringtoint(rightstr, -999,999, 0);
		int down = stringtoint(downstr, -999,999, 0);
	
		int x1=1; int x2=level->width-1; int dx=1;
		if (right>0) {
			x1=level->width-2;
			x2=0;
			dx=-1;
		}
		int y1=1; int y2=level->height-1; int dy=1;
		if (down>0) {
			y1=level->height-2;
			y2=0;
			dy=-1;
		}
		for (int x=x1; x!=x2; x+=dx) {
			for (int y=y1; y!=y2; y+=dy) {
				int sx=x-right;
				int sy=y-down;
				if (sx>0 && sx<level->width-1 && sy>0 && sy<level->height-1) {
					level->piece[x][y] = level->piece[sx][sy];	
				} else {
					level->piece[x][y] = air;
				}
			}
		}
	}
}

static void addBorder(Level* level)
{
	if (level->width <= maxlevelwidth-4
	&&  level->height <= maxlevelheight-4) {
		int x,y;
		for (x=level->width-2; x>=1; x--) {
			for (y=level->height-2; y>=1; y--) {
				level->piece[x+1][y+1] = level->piece[x][y];
			}
		}
		level->width+=2;
		level->height+=2;

		for (x=1; x<level->width-1; x++) {
			level->piece[x][1] = level->piece[x][level->height-2] = wall;
		}
		for (y=1; y<level->height-1; y++) {
			level->piece[1][y] = level->piece[level->width-2][y] = wall;
		}
	}
}


static piecetype toolboxtopiece(int col, int row)
{
	switch (row*0x10+col) {
	case 0x00: return man1;
	case 0x01: return man2;
	case 0x02: return air;
	case 0x03: return earth;
	case 0x04: return stone;

	case 0x10: return sand;
	case 0x11: return sand_full;
	case 0x12: return glasswall;
	case 0x13: return invisiblewall;
	case 0x14: return bag;

	case 0x20: return wall;
	case 0x21: return stonewall;
	case 0x22: return roundwall;
	case 0x23: return wheel;
	case 0x24: return bomb;

	case 0x30: return converter;
	case 0x31: return dispenser;
	case 0x32: return acid;
	case 0x33: return door;
	case 0x34: return swamp;

	case 0x40: return wallemerald;
	case 0x41: return emerald;
	case 0x42: return sapphire;
	case 0x43: return ruby;
	case 0x44: return drop;

	case 0x50: return box;
	case 0x51: return cushion;
	case 0x52: return elevator;
	case 0x53: return robot;
	case 0x54: return timebomb;

	case 0x60: return doorblue;
	case 0x61: return doorred;
	case 0x62: return doorgreen;
	case 0x63: return dooryellow;
	case 0x64: return activebomb5;

	case 0x70: return keyblue;
	case 0x71: return keyred;
	case 0x72: return keygreen;
	case 0x73: return keyyellow;
	case 0x74: return timebomb10;

	case 0x80: return bugleft;
	case 0x81: return bugup;
	case 0x82: return bugright;
	case 0x83: return bugdown;
	case 0x84: return pusherleft;

	case 0x90: return lorryleft;
	case 0x91: return lorryup;
	case 0x92: return lorryright;
	case 0x93: return lorrydown;
	case 0x94: return pusherright;

	case 0xA0: return yamyamleft;
	case 0xA1: return yamyamup;
	case 0xA2: return yamyamright;
	case 0xA3: return yamyamdown;

	case 0xB0: return movie0;
	case 0xB1: return movie1;
	case 0xB2: return movie2;
	case 0xB3: return movie3;
	case 0xB4: return movie4;
	case 0xC0: return movie5;
	case 0xC1: return movie6;
	case 0xC2: return movie7;
	case 0xC3: return movie8;
	case 0xC4: return movie9;
	case 0xD0: return movie10;
	case 0xD1: return movie11;
	case 0xD2: return movie12;
	case 0xD3: return movie13;
	case 0xD4: return movie14;
	case 0xE0: return movie15;
	case 0xE1: return movie16;
	case 0xE2: return movie17;
	case 0xE3: return movie18;
	case 0xE4: return movie19;

	default: return air;
	}
}

bool editLevel(Level* level)
{
	bool dosave=false;
	bool dragtoolbar=false;
	int dragprevx=0;
	int dragprevy=0;

	// before edit, clear all unused space in the level 
	int y;
	for (y=level->height; y<maxlevelheight; y++) {
		for (int x=0; x<maxlevelwidth; x++) level->piece[x][y] = air;
	}
	for (y=0; y<maxlevelheight; y++) {
		for (int x=level->width; x<maxlevelwidth; x++) level->piece[x][y] = air;
	}

    Image* toolbar = NULL;
	Image* background = NULL;
	Image* mousecursor = NULL;
	Image* arrowdigits = NULL;

	// loop where all frames are re-opened in each iteration
	for (;;) {
	  delete toolbar; toolbar=NULL;
	  delete background; background=NULL;
	  delete mousecursor; mousecursor=NULL;
	  delete arrowdigits; arrowdigits=NULL;

	  startLevelMusic(level);

	  Artwork artwork;
	  if (level->artwork != "") {
		  artwork.load(level->artwork,level->movieset,defaultshrinkfactor);
		  toolbar = loadArtworkImage ("toolbar", &(level->artwork) );
		  background = loadArtworkImage ("editgrnd", &(level->artwork) );
	  } else {
		  artwork.load(defaultartwork,level->movieset,defaultshrinkfactor);
		  toolbar = loadArtworkImage ("toolbar");
		  background = loadArtworkImage ("editgrnd");
	  }
	  mousecursor = loadImage(charstring("art\\arrow.bmp"));
	  arrowdigits = loadImage(charstring("art\\arrowdgt.bmp"));
	  if (!toolbar) goto cleanup;
	  if (!mousecursor) goto cleanup;
	  if (!background) goto cleanup;
	  if (!arrowdigits) goto cleanup;


	  LevelFrame lf(level, 0,0,getScreenWidth(),getScreenHeight(), &artwork, background);
	  ToolbarFrame tbf(getScreenWidth()-10-toolbar->getWidth(),
						getScreenHeight()-10-toolbar->getHeight(), toolbar,
						5,15,30, 4,15, color_red,color_green);
	  MouseCursor mouse(getScreenWidth()/2,getScreenHeight()/2, 
		  mousecursor, arrowdigits, 0,0);

	  for (;;) {
		int cmd,parameter;
		while (getCommandEvent(cmd,parameter)) {
			if (cmd==COMMAND_LETTER && parameter=='L') {
				level->lockDemos();
			}
			if (cmd==COMMAND_ESCAPE) {
				int act;
				{
				DialogFrame d (getScreenWidth()/2, getScreenHeight()/2,
					*getstring(240), color_neutral, color_black);
				d.addActionLine (*getstring(242), color_neutral, ACTION_INFO);
				d.addActionLine (*getstring(241), color_neutral, ACTION_OPTIONS);
				d.addActionLine (*getstring(245), color_neutral, ACTION_MOVE);
				d.addActionLine (*getstring(246), color_neutral, ACTION_ADDBORDER);
				d.addBlankLine();
				d.addActionLine (*getstring(243), color_neutral, ACTION_SAVE);
				d.addActionLine (*getstring(244), color_neutral, ACTION_DISCARD);

				mouse.enable(false);
				act = d.doModal();
				mouse.enable(true);
				}

				switch(act) {
				case ACTION_OPTIONS:
					mouse.enable(false);
					editLevelOptions(level);
					mouse.enable(true);
					mouse.forgetButton(0);
					mouse.forgetButton(1);
					break;
				case ACTION_INFO:
					{
						mouse.enable(false);
						bool newart = editLevelInfo(level);
						mouse.enable(true);
						mouse.forgetButton(0);
						mouse.forgetButton(1);
						if (newart) goto newartwork;
					}
					startLevelMusic(level);
					break;
				case ACTION_SAVE:
					dosave=true;
				case ACTION_DISCARD:
					goto cleanup;				

				case ACTION_MOVE:
					mouse.enable(false);
					moveLevelContents(level);
					mouse.enable(true);
					mouse.forgetButton(0);
					mouse.forgetButton(1);
					break;

				case ACTION_ADDBORDER:
					addBorder(level);
					mouse.forgetButton(0);
					mouse.forgetButton(1);
					break;
				}
			}
		}

		// check, if user scrolls the main window by pushing against the border
		int dx=mouse.getBorderPushX();
		int dy=mouse.getBorderPushY();
		mouse.resetBorderPush();
		lf.scroll(dx,dy);

		// determine window beneath mouse cursor
		int mx = mouse.getMouseX();
		int my = mouse.getMouseY();

		// check, if we continue dragging the toolbar
		if (dragtoolbar && mouse.isButtonDown(0)) {
			tbf.moveOffset(mx-dragprevx,my-dragprevy);
			dragprevx = mx;
			dragprevy = my;
		} else {
			dragtoolbar=false;
		// otherwise, we check for different possibilities
			Frame *thisw = findFrameAtPosition(mx,my, mouse.getFrame());

			// actions with the toolbox frame
			if (thisw==&tbf) {
				// check for mouse-clicks
				if (mouse.isButtonNew(0)) {
					// check if user hit an icon
					if (!tbf.selectIcon(0,mx,my)) {
					// otherwise start dragging
						dragtoolbar = true;
						dragprevx = mx;
						dragprevy = my;
					}
				}
				if (mouse.isButtonNew(1)) {
					tbf.selectIcon(1,mx,my);
				}
			}

			// actions with the level frame
			if (thisw==&lf) {
				tiletype paint = tile_invalid;

				if (mouse.isButtonDown(0)) {
					paint = toolboxtopiece(tbf.getColumn(0),tbf.getRow(0));
				} 
				if (mouse.isButtonDown(1)) {
					paint = toolboxtopiece(tbf.getColumn(1),tbf.getRow(1));
				}

				if (paint != tile_invalid) {
					int bnum,lx,ly;
					if (lf.screenToLevelCoords(mx,my, lx,ly)) {
						level->piece[lx][ly] = paint;
					} else if (lf.screenToYamYamCoords(mx,my, bnum,lx,ly)) {
						level->yamyaminfo[bnum].piece[lx][ly] = paint;
					}
				}
			}
		}

		// try to compute correct coordinates
		{
			int lx; int ly;
			if (lf.screenToLevelCoords(mx,my, lx,ly)) {
				mouse.setDisplayedCoordinates(lx,ly);
			} else {
				mouse.setDisplayedCoordinates(-1,-1);
			}
		}

		// remove the new-information for all mouse buttons
		mouse.isButtonNew(0);
		mouse.isButtonNew(1);
		mouse.isButtonNew(2);

		// next step
		gameTick();
	  }

	  newartwork: 1;
	}

cleanup:
	// re-build level outline border after operation
	if (level) {
		for (int x=0; x<level->width; x++) {
			level->piece[x][0] = outlineborder;
			level->piece[x][level->height-1] = outlineborder;
		}
		for (int y=0; y<level->height; y++) {
			level->piece[0][y] = outlineborder;
			level->piece[level->width-1][y] = outlineborder;
		}
	}

	if (level->filename=="") {
		doLog (2, "invent new filename for level");
		int seqnum=1;
		char buffer[10];
		do {
			level->filename = charstring("levels\\custom\\") + 
				*(level->longname.getdefault()) + 
				itoa(seqnum,buffer,9) + ".lev";
			seqnum++;
		} while (fileexists(level->filename.data()));
	}
	if ( *(level->longname.getdefault()) == "") {
		level->longname.setstring(charstring(DEFAULTLANGUAGE), level->filename);
	}


	delete toolbar;
	delete background;
	delete mousecursor;
	delete arrowdigits;

	return dosave;
}




LevelFrame::LevelFrame(Level* lev, int l, int t, int r, int b, Artwork* a, Image* bckgrnd)
: Frame(l,t,r,b, false)
{
	updater.setFrame(this);

	level = lev;
	artwork = a;
	background = bckgrnd;

	levelwidth = level->width+4;
	levelheight = maximum (level->height, level->yamyaminfo.size()*4+1);
	oldyamyamnum = level->yamyaminfo.size();

	int x,y,bnum;
	for (x=0; x<levelwidth; x++) {
		for (y=0; y<levelheight; y++) {
			tiles[x][y] = tile_invalid;
		}
	}
	for (x=1; x<level->width-1; x++) {
		for (y=1; y<level->height-1; y++) {
			tiles[x][y] = level->getTile(x,y);
		}
	}
	for (bnum=0;bnum<level->yamyaminfo.size();bnum++) {
		for (x=0; x<3; x++) {
			for (y=0; y<3; y++) {
				tiles[level->width+x][1+bnum*4+y] = level->getYamYamTile(bnum,x,y);
			}
		}
	}

	scrollx = 0;
	scrolly = 0;

	recenter();
}

LevelFrame::~LevelFrame()
{
}

void LevelFrame::recenter()
{	
	int ts = artwork->tilesize;

	if (scrollx>(levelwidth)*ts-getWidth()) 
		scrollx=(levelwidth)*ts-getWidth();
	if (scrolly>(levelheight)*ts-getHeight()) 
		scrolly=(levelheight)*ts-getHeight();
	if (scrollx<0) scrollx=0;
	if (scrolly<0) scrolly=0;
}

void LevelFrame::scroll(int dx, int dy)
{
	int oldx=scrollx;
	int oldy=scrolly;

	scrollx-=dx;
	scrolly-=dy;
	recenter();

	if (oldx!=scrollx || oldy!=scrolly) {
		invalidateArea(left,top,right,bottom);
	}
}

bool LevelFrame::screenToLevelCoords(int sx,int sy, int& lx, int& ly)
{
	sx = sx-left+scrollx;
	sy = sy-top+scrolly;
	int ts=artwork->tilesize;
	if (sx<ts || sy<ts || sx>=level->width*ts-ts || sy>=level->height*ts-ts) return false;
	lx = sx/ts;
	ly = sy/ts;
	return true;
}

bool LevelFrame::screenToYamYamCoords(int sx,int sy, int &bnum, int& lx, int& ly)
{
	sx = sx-left+scrollx;
	sy = sy-top+scrolly;
	int ts=artwork->tilesize;
	if (sx<ts*level->width || sy<0) return false;

	lx = sx/ts - level->width;
	ly = sy/ts - 1;
	bnum = ly/4;
	ly = ly%4;
	
	if (bnum>=0 && bnum<level->yamyaminfo.size() && lx>=0 && lx<=2 && ly>=0 && ly<=2) return true;
	return false;
}

void LevelFrame::call()
{
	int ts = artwork->tilesize;

	// check for all changes that could have happend in the meantime
	if (levelwidth != level->width+4
	||  levelheight != maximum (level->height, level->yamyaminfo.size()*4+1)
	||  oldyamyamnum != level->yamyaminfo.size()) {

		oldyamyamnum = level->yamyaminfo.size();
		
		levelwidth = level->width+4;
		levelheight = maximum (level->height, level->yamyaminfo.size()*4+1);
		invalidateArea (left,top,right,bottom);

		for (int x=0;x<levelwidth;x++) {
			for (int y=0;y<levelheight;y++) {
				tiles[x][y] = tile_invalid;
			}
		}
	}

	int b,x,y;
	for (x=1; x<level->width-1; x++) {
		for (y=1; y<level->height-1; y++) {
			if (tiles[x][y] != level->getTile(x,y)) {
				tiles[x][y] = level->getTile(x,y);
				invalidateArea (left-scrollx+x*ts, top-scrolly+y*ts,
								left-scrollx+x*ts+ts, top-scrolly+y*ts+ts);
			}
		}
	}
	for (b=0; b<level->yamyaminfo.size();b++) {
		for (x=0; x<3; x++) {
			for (y=0; y<3; y++) {
				if (tiles[level->width+x][1+y+b*4] != level->getYamYamTile(b,x,y)) {
					tiles[level->width+x][1+y+b*4] = level->getYamYamTile(b,x,y);
					invalidateArea (left-scrollx+(level->width+x)*ts, top-scrolly+(1+y+b*4)*ts,
									left-scrollx+(level->width+x)*ts+ts, top-scrolly+(1+y+b*4)*ts+ts);
				}
			}
		}
	}
}

void LevelFrame::update (int currentpage, int l, int t, int r, int b)
{
	int ts = artwork->tilesize;

	int x1 = (l-left+scrollx)/ts;
	int x2 = (r-left+scrollx)/ts;
	int y1 = (t-top+scrolly)/ts;
	int y2 = (b-top+scrolly)/ts;

	// draw tiles 
	for (int y=y1; y<=y2; y++) {
		for (int x=x1; x<=x2; x++) {
			tiletype ti = tile_invalid;
			Image* img;
			int sourcex;

			if (x>=1 && x<levelwidth-1 && y>=1 && y<levelheight-1) {
				ti = tiles[x][y];
			}

			if (ti==tile_invalid) {
				if (background) {
					theScreen.drawTileClipped (background,
						left-scrollx+x*ts, top-scrolly+y*ts,
						left-scrollx+x*ts+ts, top-scrolly+y*ts+ts,
						l,t,r,b);
				}
				continue;
			}

			img = artwork->getImageForTile (ti, sourcex);
			if (img) {
				theScreen.drawClipped (img, sourcex,0, 
					left-scrollx+x*ts, top-scrolly+y*ts,
					left-scrollx+x*ts+ts, top-scrolly+y*ts+ts,
					l,t,r,b );

				img = artwork->getImage2ForTile (ti, sourcex);
				if (img) {
					theScreen.drawClipped (img, sourcex,0, 
						left-scrollx+x*ts, top-scrolly+y*ts,
						left-scrollx+x*ts+ts, top-scrolly+y*ts+ts,
						l,t,r,b, true );
				}
			} else {
				theScreen.fillClipped (artwork->getBackgroundColor(), 
					left-scrollx+x*ts, top-scrolly+y*ts,
					left-scrollx+x*ts+ts, top-scrolly+y*ts+ts,
					l,t,r,b);
			}
		}
	}
	// draw area outside the level itself 
	int bx1=left-scrollx+ts;
	int by1=top-scrolly+ts;
	int bx2=left-scrollx+levelwidth*ts-ts;
	int by2=top-scrolly+levelheight*ts-ts;
	if (background) {
		theScreen.drawTileClipped(background, -30000,-30000,30000, by1, l,t,r,b);
		theScreen.drawTileClipped(background, -30000,by2, 30000,30000,  l,t,r,b);
		theScreen.drawTileClipped(background, -30000,by1, bx1,by2,		l,t,r,b);
		theScreen.drawTileClipped(background, bx2,by1, 30000,by2,		l,t,r,b);
	}
}
